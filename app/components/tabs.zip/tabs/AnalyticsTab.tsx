'use client';
import React from 'react';
import { IconChart, IconRefresh, IconTrendingUp, IconSearch, IconDownload, IconBriefcase, IconScroll, IconMail, IconPhone, IconUsers, IconCheck } from './Icons';

const primaryColor = '#693fe9';
const primaryGradient = 'linear-gradient(135deg, #693fe9 0%, #7c4dff 100%)';

export default function AnalyticsTab() {
    const cardStyle: React.CSSProperties = { background: 'white', borderRadius: '12px', padding: '12px', marginBottom: '12px', boxShadow: '0 2px 8px rgba(0,0,0,0.06)' };
    const inputStyle: React.CSSProperties = { width: '100%', padding: '6px 8px', fontSize: '11px', border: '2px solid #e0e0e0', borderRadius: '6px' };

    return (
        <div style={{ padding: '12px', background: '#f5f7fa' }}>
            {/* Live Status Log Bar */}
            <div style={{ background: primaryGradient, color: 'white', padding: '10px 15px', borderRadius: '10px', marginBottom: '12px', fontSize: '12px', display: 'flex', alignItems: 'center', gap: '10px', boxShadow: '0 2px 8px rgba(102, 126, 234, 0.3)' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flex: 1 }}>
                    <IconChart size={16} color="white" />
                    <span style={{ fontWeight: '500' }}>Analytics synced - Last updated just now</span>
                </div>
                <div style={{ fontSize: '11px', opacity: 0.8 }}>Auto-refresh: ON</div>
            </div>
            
            {/* Compact Analytics Header with Period Selector */}
            <div style={cardStyle}>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '10px' }}>
                    <h4 style={{ margin: 0, fontSize: '13px', fontWeight: '600', color: primaryColor, display: 'flex', alignItems: 'center', gap: '6px' }}>
                        <IconChart size={14} color={primaryColor} /> Engagement Analytics
                    </h4>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                        <select defaultValue="Last 7 Days" style={{ padding: '5px 8px', fontSize: '11px', border: '1.5px solid #e0e0e0', borderRadius: '4px', minWidth: '100px' }}>
                            <option>Last 7 Days</option>
                            <option>Last 30 Days</option>
                            <option>Last 90 Days</option>
                        </select>
                        <button style={{ padding: '5px 10px', fontSize: '10px', background: primaryGradient, color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '3px' }}>
                            <IconRefresh size={10} color="white" /> Refresh
                        </button>
                    </div>
                </div>
            </div>
            
            {/* Total Engagements */}
            <div style={cardStyle}>
                <h4 style={{ margin: '0 0 10px 0', fontSize: '12px', fontWeight: '600', color: primaryColor, display: 'flex', alignItems: 'center', gap: '6px' }}>
                    <IconTrendingUp size={14} color={primaryColor} /> Total Engagements
                </h4>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '8px' }}>
                    {[
                        { label: 'Comments', value: '127', bg: primaryGradient },
                        { label: 'Likes', value: '342', bg: 'linear-gradient(135deg, #EC4899, #DB2777)' },
                        { label: 'Shares', value: '58', bg: 'linear-gradient(135deg, #06B6D4, #0891B2)' },
                        { label: 'Posts', value: '24', bg: 'linear-gradient(135deg, #F59E0B, #D97706)' }
                    ].map((stat, i) => (
                        <div key={i} style={{ background: stat.bg, padding: '10px', borderRadius: '10px', textAlign: 'center', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}>
                            <span style={{ fontSize: '18px', fontWeight: '700', color: 'white', display: 'block' }}>{stat.value}</span>
                            <span style={{ fontSize: '9px', color: 'rgba(255,255,255,0.9)', textTransform: 'uppercase', fontWeight: '600' }}>{stat.label}</span>
                        </div>
                    ))}
                </div>
            </div>
            
            {/* Leads Database */}
            <div style={cardStyle}>
                <h4 style={{ margin: '0 0 8px 0', fontSize: '12px', fontWeight: '600', display: 'flex', alignItems: 'center', gap: '6px' }}><IconBriefcase size={14} color={primaryColor} /> Leads Database</h4>
                <p style={{ margin: '0 0 8px 0', fontSize: '10px', color: '#666' }}>Leads collected from People Search automation, organized by search query</p>
                
                <div style={{ marginBottom: '8px' }}>
                    <input type="text" placeholder="🔍 Search leads by name, headline, or location..." style={inputStyle} />
                </div>
                
                <div style={{ display: 'flex', gap: '8px', marginBottom: '8px', flexWrap: 'wrap' }}>
                    <button style={{ padding: '5px 10px', fontSize: '10px', background: primaryGradient, color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '3px' }}><IconRefresh size={10} color="white" /> Refresh</button>
                    <select style={{ flex: 1, padding: '5px', fontSize: '10px', border: '1px solid #e0e0e0', borderRadius: '4px' }}>
                        <option>All Search Queries</option>
                    </select>
                    <button style={{ padding: '5px 10px', fontSize: '10px', background: '#f1f5f9', color: '#64748b', border: 'none', borderRadius: '4px', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '3px' }}><IconDownload size={10} color="#64748b" /> Export CSV</button>
                </div>
                
                <div style={{ display: 'flex', gap: '12px', marginBottom: '8px', fontSize: '10px', color: '#6c757d' }}>
                    <span>Total Leads: <strong>156</strong></span>
                    <span>With Email: <strong>42</strong></span>
                    <span>With Phone: <strong>18</strong></span>
                    <span>Connected: <strong>89</strong></span>
                </div>
                
                <div style={{ maxHeight: '200px', overflowY: 'auto', border: '1px solid #dee2e6', borderRadius: '5px' }}>
                    <table style={{ width: '100%', fontSize: '10px', borderCollapse: 'collapse' }}>
                        <thead style={{ background: '#f8f9fa', position: 'sticky', top: 0 }}>
                            <tr>
                                <th style={{ padding: '6px', textAlign: 'left', borderBottom: '2px solid #dee2e6' }}>Name</th>
                                <th style={{ padding: '6px', textAlign: 'left', borderBottom: '2px solid #dee2e6' }}>Headline</th>
                                <th style={{ padding: '6px', textAlign: 'left', borderBottom: '2px solid #dee2e6' }}>Location</th>
                                <th style={{ padding: '6px', textAlign: 'left', borderBottom: '2px solid #dee2e6' }}>Email</th>
                                <th style={{ padding: '6px', textAlign: 'left', borderBottom: '2px solid #dee2e6' }}>Query</th>
                                <th style={{ padding: '6px', textAlign: 'left', borderBottom: '2px solid #dee2e6' }}>Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            {[
                                { name: 'Sarah Johnson', headline: 'VP of Marketing at TechCorp', location: 'San Francisco, CA', email: 's.johnson@email.com', query: 'VP Marketing', date: 'Dec 3' },
                                { name: 'Michael Chen', headline: 'Senior Developer at StartupXYZ', location: 'New York, NY', email: '-', query: 'Senior Developer', date: 'Dec 3' },
                                { name: 'Emily Davis', headline: 'Product Manager at InnovateCo', location: 'Austin, TX', email: 'emily.d@email.com', query: 'Product Manager', date: 'Dec 2' },
                                { name: 'James Wilson', headline: 'CTO at FutureTech', location: 'Seattle, WA', email: '-', query: 'CTO', date: 'Dec 2' },
                                { name: 'Lisa Anderson', headline: 'Growth Lead at ScaleUp', location: 'Los Angeles, CA', email: 'lisa@scaleup.io', query: 'Growth Lead', date: 'Dec 1' }
                            ].map((lead, i) => (
                                <tr key={i} style={{ borderBottom: '1px solid #eee' }}>
                                    <td style={{ padding: '6px', color: primaryColor, fontWeight: '500' }}>{lead.name}</td>
                                    <td style={{ padding: '6px', maxWidth: '150px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{lead.headline}</td>
                                    <td style={{ padding: '6px' }}>{lead.location}</td>
                                    <td style={{ padding: '6px', color: lead.email !== '-' ? '#10B981' : '#999' }}>{lead.email}</td>
                                    <td style={{ padding: '6px' }}>{lead.query}</td>
                                    <td style={{ padding: '6px' }}>{lead.date}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
            
            {/* Processing History Section */}
            <div style={cardStyle}>
                <h4 style={{ margin: '0 0 8px 0', fontSize: '12px', fontWeight: '600', display: 'flex', alignItems: 'center', gap: '6px' }}><IconScroll size={14} color={primaryColor} /> Processing History</h4>
                <p style={{ margin: '0 0 8px 0', fontSize: '10px', color: '#666' }}>Complete history of all Automation and Networking processing sessions</p>
                
                <div style={{ display: 'flex', gap: '6px', marginBottom: '8px', alignItems: 'center', flexWrap: 'wrap' }}>
                    <select style={{ padding: '5px 10px', fontSize: '10px', minWidth: '100px', border: '1px solid #e0e0e0', borderRadius: '4px' }}>
                        <option>All Sessions</option>
                        <option>Automation Only</option>
                        <option>Networking Only</option>
                    </select>
                    <select style={{ padding: '5px 10px', fontSize: '10px', minWidth: '100px', border: '1px solid #e0e0e0', borderRadius: '4px' }}>
                        <option>All Status</option>
                        <option>Completed</option>
                        <option>Stopped</option>
                        <option>Failed</option>
                    </select>
                    <button style={{ padding: '5px 10px', fontSize: '10px', background: primaryGradient, color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '3px' }}><IconRefresh size={10} color="white" /> Refresh</button>
                    <button style={{ padding: '5px 10px', fontSize: '10px', background: '#f1f5f9', color: '#64748b', border: 'none', borderRadius: '4px', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '3px' }}><IconDownload size={10} color="#64748b" /> Export CSV</button>
                    <button style={{ padding: '5px 10px', fontSize: '10px', background: '#f1f5f9', color: '#64748b', border: 'none', borderRadius: '4px', cursor: 'pointer' }}>🗑️ Clear History</button>
                </div>
                
                <div style={{ display: 'flex', gap: '12px', marginBottom: '8px', fontSize: '10px', color: '#6c757d' }}>
                    <span>Total Sessions: <strong>47</strong></span>
                    <span>Automation: <strong>28</strong></span>
                    <span>Networking: <strong>19</strong></span>
                    <span>Success Rate: <strong>94%</strong></span>
                </div>
                
                <div style={{ maxHeight: '200px', overflowY: 'auto', border: '1px solid #dee2e6', borderRadius: '5px' }}>
                    <table style={{ width: '100%', fontSize: '10px', borderCollapse: 'collapse' }}>
                        <thead style={{ background: '#f8f9fa', position: 'sticky', top: 0 }}>
                            <tr>
                                <th style={{ padding: '6px', textAlign: 'left', borderBottom: '2px solid #dee2e6' }}>Type</th>
                                <th style={{ padding: '6px', textAlign: 'left', borderBottom: '2px solid #dee2e6' }}>Keywords/Query</th>
                                <th style={{ padding: '6px', textAlign: 'center', borderBottom: '2px solid #dee2e6' }}>Target</th>
                                <th style={{ padding: '6px', textAlign: 'center', borderBottom: '2px solid #dee2e6' }}>Found</th>
                                <th style={{ padding: '6px', textAlign: 'center', borderBottom: '2px solid #dee2e6' }}>Status</th>
                                <th style={{ padding: '6px', textAlign: 'left', borderBottom: '2px solid #dee2e6' }}>Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            {[
                                { type: 'Automation', query: 'AI, Machine Learning', target: 10, found: 8, status: 'Completed', date: 'Dec 3, 2:45 PM' },
                                { type: 'Networking', query: 'VP Sales', target: 15, found: 12, status: 'Completed', date: 'Dec 3, 11:20 AM' },
                                { type: 'Automation', query: 'Web Development', target: 8, found: 8, status: 'Completed', date: 'Dec 2, 4:30 PM' },
                                { type: 'Networking', query: 'Product Manager', target: 20, found: 18, status: 'Completed', date: 'Dec 2, 10:15 AM' },
                                { type: 'Automation', query: 'Startup, Entrepreneur', target: 12, found: 5, status: 'Stopped', date: 'Dec 1, 3:00 PM' }
                            ].map((session, i) => (
                                <tr key={i} style={{ borderBottom: '1px solid #eee' }}>
                                    <td style={{ padding: '6px' }}>
                                        <span style={{ padding: '2px 6px', borderRadius: '4px', fontSize: '9px', fontWeight: '600', background: session.type === 'Automation' ? '#E0E7FF' : '#FEF3C7', color: session.type === 'Automation' ? primaryColor : '#D97706' }}>
                                            {session.type === 'Automation' ? 'Auto' : 'Net'}
                                        </span>
                                    </td>
                                    <td style={{ padding: '6px', maxWidth: '120px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{session.query}</td>
                                    <td style={{ padding: '6px', textAlign: 'center' }}>{session.target}</td>
                                    <td style={{ padding: '6px', textAlign: 'center', fontWeight: '600', color: primaryColor }}>{session.found}</td>
                                    <td style={{ padding: '6px', textAlign: 'center' }}>
                                        <span style={{ padding: '2px 6px', borderRadius: '4px', fontSize: '9px', fontWeight: '600', background: session.status === 'Completed' ? '#D1FAE5' : '#FEE2E2', color: session.status === 'Completed' ? '#059669' : '#DC2626' }}>
                                            {session.status === 'Completed' ? '✓' : '⏹'}
                                        </span>
                                    </td>
                                    <td style={{ padding: '6px', fontSize: '9px' }}>{session.date}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
            
            {/* Export & Clear Buttons */}
            <div style={cardStyle}>
                <div style={{ display: 'flex', gap: '10px' }}>
                    <button style={{ flex: 1, padding: '10px', fontSize: '11px', background: primaryGradient, color: 'white', border: 'none', borderRadius: '6px', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '4px' }}><IconDownload size={12} color="white" /> Export Statistics</button>
                    <button style={{ flex: 1, padding: '10px', fontSize: '11px', background: '#f1f5f9', color: '#64748b', border: 'none', borderRadius: '6px', cursor: 'pointer' }}>🗑️ Clear All Data</button>
                </div>
            </div>
        </div>
    );
}
