'use client';
import React from 'react';
import { IconCalendar, IconClock, IconBot, IconTarget, IconZap, IconRocket, IconSettings, IconMessage, IconThumbsUp, IconShare, IconPlus, IconTrash, IconSliders } from './Icons';

const primaryColor = '#693fe9';
const primaryGradient = 'linear-gradient(135deg, #693fe9 0%, #7c4dff 100%)';

export default function AutomationTab() {
    const cardStyle: React.CSSProperties = { background: 'white', borderRadius: '12px', padding: '12px', marginBottom: '12px', boxShadow: '0 2px 8px rgba(0,0,0,0.06)' };
    const inputStyle: React.CSSProperties = { width: '100%', padding: '6px 8px', fontSize: '11px', border: '2px solid #e0e0e0', borderRadius: '6px' };

    return (
        <div style={{ padding: '12px', background: '#f5f7fa' }}>
            {/* Live Status Log Bar */}
            <div style={{ background: primaryGradient, color: 'white', padding: '10px 15px', borderRadius: '10px', marginBottom: '12px', fontSize: '12px', display: 'flex', alignItems: 'center', gap: '10px', boxShadow: '0 2px 8px rgba(102, 126, 234, 0.3)' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flex: 1 }}>
                    <IconClock size={16} color="white" />
                    <span style={{ fontWeight: '500' }}>Automation ready - Configure keywords to start</span>
                </div>
                <div style={{ fontSize: '11px', opacity: 0.8, fontFamily: 'monospace' }}>00:00:00</div>
            </div>
            
            {/* Main Card */}
            <div style={{ ...cardStyle, background: 'linear-gradient(135deg, #f8f9fa 0%, #ffffff 100%)' }}>
                {/* Header */}
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '12px', paddingBottom: '10px', borderBottom: '2px solid #e0e0e0' }}>
                    <div>
                        <h4 style={{ margin: '0 0 3px 0', fontSize: '13px', fontWeight: '600', display: 'flex', alignItems: 'center', gap: '6px' }}><IconCalendar size={14} color={primaryColor} /> Bulk Keyword Processing</h4>
                        <small style={{ color: '#666', fontSize: '10px' }}>AI-powered keyword generation and bulk engagement</small>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '5px', fontSize: '10px', color: '#666' }}>
                        <span style={{ display: 'flex', alignItems: 'center', gap: '4px' }}><IconClock size={12} color="#666" /> Auto-Schedule</span>
                        <div style={{ width: '32px', height: '18px', background: '#e2e8f0', borderRadius: '9px', position: 'relative', cursor: 'pointer' }}>
                            <div style={{ width: '14px', height: '14px', background: 'white', borderRadius: '50%', position: 'absolute', top: '2px', left: '2px', boxShadow: '0 1px 3px rgba(0,0,0,0.2)' }}></div>
                        </div>
                    </div>
                </div>

                {/* Scheduled Times Section */}
                <div style={{ background: '#f0f8ff', padding: '10px', borderRadius: '6px', marginBottom: '10px', fontSize: '10px' }}>
                    <div style={{ marginBottom: '5px', fontWeight: '600', color: primaryColor, display: 'flex', alignItems: 'center', gap: '4px' }}><IconCalendar size={12} color={primaryColor} /> Scheduled Times:</div>
                    <div style={{ color: '#999', marginBottom: '6px' }}>No schedules. Add time below.</div>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', paddingTop: '6px', borderTop: '1px solid #d0e8ff' }}>
                        <span style={{ display: 'flex', alignItems: 'center', gap: '4px' }}><IconClock size={10} color="#666" /> Next: <strong>9:00 AM</strong></span>
                        <span><strong>02:15:30</strong></span>
                    </div>
                </div>

                {/* AI Keyword Generation */}
                <div style={{ background: 'white', padding: '10px', borderRadius: '8px', marginBottom: '10px', border: '2px solid #e0e0e0' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '6px', marginBottom: '8px' }}>
                        <IconBot size={14} color={primaryColor} />
                        <strong style={{ color: primaryColor, fontSize: '12px' }}>AI Keyword Generation</strong>
                    </div>
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px', marginBottom: '8px' }}>
                        <div>
                            <label style={{ display: 'block', marginBottom: '3px', fontSize: '10px', color: '#666', fontWeight: '600' }}>Target Audience:</label>
                            <textarea rows={3} placeholder="e.g., tech entrepreneurs interested in AI & ML" style={{ ...inputStyle, resize: 'vertical' }}></textarea>
                        </div>
                        <div>
                            <label style={{ display: 'block', marginBottom: '3px', fontSize: '10px', color: '#666', fontWeight: '600' }}>Keywords (one per line):</label>
                            <textarea rows={3} placeholder="AI&#10;machine learning&#10;web development" style={{ ...inputStyle, resize: 'none' }}></textarea>
                        </div>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '6px', marginBottom: '8px', flexWrap: 'wrap' }}>
                        <label style={{ display: 'flex', alignItems: 'center', gap: '4px', fontSize: '10px', whiteSpace: 'nowrap' }}>
                            Count:
                            <input type="range" min="1" max="10" defaultValue="5" style={{ width: '50px' }} />
                            <strong style={{ color: primaryColor }}>5</strong>
                        </label>
                        <button style={{ padding: '5px 8px', fontSize: '10px', background: primaryColor, color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '3px' }}><IconBot size={10} color="white" /> Generate Keywords</button>
                        <button style={{ padding: '5px 6px', fontSize: '10px', border: '2px solid #dc3545', background: 'white', color: '#dc3545', borderRadius: '4px', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '3px' }}><IconTrash size={10} color="#dc3545" /> Clear</button>
                        <input type="time" style={{ padding: '5px', fontSize: '10px', width: '75px', border: '2px solid #e0e0e0', borderRadius: '4px' }} />
                        <button style={{ padding: '5px 8px', fontSize: '10px', background: primaryColor, color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '3px' }}><IconPlus size={10} color="white" /> Add Schedule</button>
                    </div>
                    <button style={{ width: '100%', padding: '10px', fontSize: '12px', fontWeight: '600', background: primaryGradient, color: 'white', border: 'none', borderRadius: '8px', cursor: 'pointer', boxShadow: '0 4px 12px rgba(105, 63, 233, 0.3)' }}>
                        <span style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px' }}><IconRocket size={14} color="white" /> Start Bulk Processing (Business Hours Safe)</span>
                    </button>
                </div>

                {/* 2-Column Layout: Actions + Settings */}
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px', marginBottom: '10px' }}>
                    {/* Actions Checkboxes */}
                    <div style={{ background: 'white', padding: '10px', borderRadius: '8px', border: '2px solid #e0e0e0' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '6px', marginBottom: '8px' }}>
                            <IconZap size={14} color={primaryColor} />
                            <strong style={{ color: primaryColor, fontSize: '11px' }}>Actions to Perform</strong>
                        </div>
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '6px', fontSize: '11px' }}>
                            {[
                                { label: '👍 Like Posts', checked: true },
                                { label: '💬 Comment on Posts', checked: true },
                                { label: '🔀 Like OR Comment', checked: false },
                                { label: '🔄 Share Posts', checked: false },
                                { label: '➕ Follow Authors', checked: false }
                            ].map((action, i) => (
                                <label key={i} style={{ display: 'flex', alignItems: 'center', gap: '5px', cursor: 'pointer' }}>
                                    <input type="checkbox" defaultChecked={action.checked} style={{ width: '14px', height: '14px', accentColor: primaryColor }} />
                                    <span>{action.label}</span>
                                </label>
                            ))}
                        </div>
                        <small style={{ display: 'block', color: '#999', marginTop: '6px', fontSize: '9px' }}>
                            💡 "Like OR Comment" randomly chooses one action per post
                        </small>
                    </div>

                    {/* Processing Settings + Post Qualification */}
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                        <div style={{ background: 'white', padding: '10px', borderRadius: '8px', border: '2px solid #e0e0e0' }}>
                            <div style={{ display: 'flex', alignItems: 'center', gap: '6px', marginBottom: '8px' }}>
                                <span style={{ fontSize: '14px' }}>⚙️</span>
                                <strong style={{ color: primaryColor, fontSize: '11px' }}>Processing Settings</strong>
                            </div>
                            <div>
                                <label style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '3px', fontSize: '10px' }}>
                                    <span>Total Posts:</span>
                                    <strong style={{ color: primaryColor }}>20</strong>
                                </label>
                                <input type="range" min="1" max="100" defaultValue="20" style={{ width: '100%' }} />
                                <small style={{ display: 'block', marginTop: '2px', color: '#999', fontSize: '9px' }}>Scrapes posts until quota reached</small>
                            </div>
                        </div>

                        <div style={{ background: 'white', padding: '10px', borderRadius: '8px', border: '2px solid #e0e0e0' }}>
                            <div style={{ display: 'flex', alignItems: 'center', gap: '6px', marginBottom: '8px' }}>
                                <span style={{ fontSize: '14px' }}>📊</span>
                                <strong style={{ color: primaryColor, fontSize: '11px' }}>Post Qualification</strong>
                            </div>
                            <div style={{ marginBottom: '5px' }}>
                                <label style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '2px', fontSize: '10px' }}>
                                    <span>Min Likes:</span>
                                    <strong style={{ color: primaryColor }}>100</strong>
                                </label>
                                <input type="range" min="0" max="100" defaultValue="10" style={{ width: '100%' }} />
                            </div>
                            <div>
                                <label style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '2px', fontSize: '10px' }}>
                                    <span>Min Comments:</span>
                                    <strong style={{ color: primaryColor }}>100</strong>
                                </label>
                                <input type="range" min="0" max="100" defaultValue="10" style={{ width: '100%' }} />
                            </div>
                            <small style={{ display: 'block', color: '#999', fontSize: '9px' }}>0 = no minimum</small>
                        </div>
                    </div>
                </div>

                {/* Business Hours Info */}
                <div style={{ background: '#f0f8ff', padding: '8px', borderRadius: '6px', borderLeft: `4px solid ${primaryColor}` }}>
                    <small style={{ color: primaryColor, fontSize: '10px' }}>
                        <strong>⚙️ Business Hours:</strong> Configure business hours and active days in the <strong>Settings</strong> tab.
                    </small>
                </div>
            </div>

            {/* AI Comment Settings (2-Column Grid) */}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px', marginBottom: '10px' }}>
                {[
                    { title: '🎯 Comment Goal', options: ['Add Value - Pure contribution, helpful insight', 'Share Experience - Personal story/perspective', 'Ask Question - Deepen discussion', 'Different Perspective - Add nuance', 'Build Relationship - Warm, supportive', 'Subtle Pitch - Strategic positioning'] },
                    { title: '🎭 Tone of Voice', options: ['Professional - Polished, business-appropriate', 'Friendly - Warm, conversational', 'Thought-Provoking - Intellectual, deep', 'Supportive - Encouraging, positive', 'Contrarian - Respectfully challenges', 'Humorous - Light, witty, entertaining'] },
                    { title: '📏 Comment Length', options: ['Short - 300 characters max', 'Mid - 600 characters max', 'Long - 900 characters max'] },
                    { title: '💼 Your Expertise/Niche', isInput: true, placeholder: 'e.g., SaaS Marketing, AI Development, Leadership Coach' },
                    { title: '📜 Your Background (Optional)', isTextarea: true, placeholder: 'e.g., Scaled 3 startups to $10M ARR, 15 years in B2B sales' },
                    { title: '🚀 AI Button Behavior', options: ['Auto-Post - Generate and submit automatically', 'Manual Review - Generate, paste, and wait for me to post'] }
                ].map((item, i) => (
                    <div key={i} style={cardStyle}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '6px', marginBottom: '8px' }}>
                            <strong style={{ color: primaryColor, fontSize: '11px' }}>{item.title}</strong>
                        </div>
                        {item.isInput ? (
                            <input type="text" placeholder={item.placeholder} style={{ ...inputStyle }} />
                        ) : item.isTextarea ? (
                            <textarea rows={2} placeholder={item.placeholder} style={{ ...inputStyle, resize: 'vertical' }}></textarea>
                        ) : (
                            <select style={{ ...inputStyle }}>
                                {item.options?.map((opt, j) => <option key={j}>{opt}</option>)}
                            </select>
                        )}
                        <small style={{ display: 'block', color: '#999', marginTop: '4px', fontSize: '9px' }}>
                            {item.isInput ? 'Your role, industry, or what you\'re known for' : item.isTextarea ? 'Specific experience, credentials, or results' : ''}
                        </small>
                    </div>
                ))}
            </div>

            {/* Window Preferences */}
            <div style={cardStyle}>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                    <div>
                        <strong style={{ fontSize: '12px', color: primaryColor }}>🪟 Window & Tab Preferences</strong>
                        <small style={{ display: 'block', color: '#666', marginTop: '2px', fontSize: '9px' }}>
                            Open search pages in new window or background tabs
                        </small>
                    </div>
                    <label style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '11px', cursor: 'pointer' }}>
                        <input type="checkbox" defaultChecked style={{ width: '16px', height: '16px', accentColor: primaryColor }} />
                        <span>New Window</span>
                    </label>
                </div>
            </div>

            {/* Bottom Start Button */}
            <button style={{ width: '100%', padding: '12px', fontSize: '13px', fontWeight: '600', background: primaryGradient, color: 'white', border: 'none', borderRadius: '10px', cursor: 'pointer', boxShadow: '0 4px 12px rgba(105, 63, 233, 0.3)' }}>
                🚀 Start Bulk Processing (Business Hours Safe)
            </button>
        </div>
    );
}
