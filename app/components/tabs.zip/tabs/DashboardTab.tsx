'use client';
import React from 'react';
import { IconChart, IconMessage, IconThumbsUp, IconShare, IconPlus, IconUserPlus, IconZap, IconEdit, IconUsers, IconDownload, IconRefresh, IconBot, IconSparkles, IconLightbulb, IconStop } from './Icons';

const primaryColor = '#693fe9';
const primaryGradient = 'linear-gradient(135deg, #693fe9 0%, #7c4dff 100%)';

export default function DashboardTab() {
    const cardStyle: React.CSSProperties = { background: 'white', borderRadius: '12px', padding: '15px', marginBottom: '12px', boxShadow: '0 2px 8px rgba(0,0,0,0.06)' };

    return (
        <div style={{ padding: '12px', background: '#f5f7fa' }}>
            {/* Live Status Log Bar */}
            <div style={{ background: primaryGradient, color: 'white', padding: '10px 15px', borderRadius: '10px', marginBottom: '12px', fontSize: '12px', display: 'flex', alignItems: 'center', gap: '10px', boxShadow: '0 2px 8px rgba(102, 126, 234, 0.3)' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flex: 1 }}>
                    <IconZap size={16} color="white" />
                    <span style={{ fontWeight: '500' }}>Dashboard active - Monitoring your growth</span>
                </div>
                <div style={{ fontSize: '11px', opacity: 0.8, fontFamily: 'monospace' }}>00:00:00</div>
            </div>
            
            {/* Today's Activity & Live Progress */}
            <div style={cardStyle}>
                <h4 style={{ margin: '0 0 12px 0', fontSize: '13px', fontWeight: '600', color: primaryColor, display: 'flex', alignItems: 'center', gap: '6px' }}>
                    <IconChart size={16} color={primaryColor} /> Today's Activity & Live Progress
                </h4>
                
                {/* Activity Boxes - 5 columns with used/limit format */}
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: '8px', marginBottom: '12px' }}>
                    <div style={{ background: primaryGradient, padding: '12px 6px', borderRadius: '10px', textAlign: 'center', boxShadow: '0 4px 12px rgba(105, 63, 233, 0.3)' }}>
                        <div style={{ fontSize: '16px', fontWeight: '700', color: 'white', marginBottom: '2px' }}>
                            23<span style={{ fontSize: '11px', opacity: 0.8 }}>/30</span>
                        </div>
                        <div style={{ fontSize: '8px', color: 'rgba(255,255,255,0.95)', textTransform: 'uppercase', fontWeight: '600', letterSpacing: '0.5px' }}>Comments</div>
                    </div>
                    <div style={{ background: 'linear-gradient(135deg, #EC4899 0%, #DB2777 100%)', padding: '12px 6px', borderRadius: '10px', textAlign: 'center', boxShadow: '0 4px 12px rgba(236, 72, 153, 0.3)' }}>
                        <div style={{ fontSize: '16px', fontWeight: '700', color: 'white', marginBottom: '2px' }}>
                            47<span style={{ fontSize: '11px', opacity: 0.8 }}>/60</span>
                        </div>
                        <div style={{ fontSize: '8px', color: 'rgba(255,255,255,0.95)', textTransform: 'uppercase', fontWeight: '600', letterSpacing: '0.5px' }}>Likes</div>
                    </div>
                    <div style={{ background: 'linear-gradient(135deg, #06B6D4 0%, #0891B2 100%)', padding: '12px 6px', borderRadius: '10px', textAlign: 'center', boxShadow: '0 4px 12px rgba(6, 182, 212, 0.3)' }}>
                        <div style={{ fontSize: '16px', fontWeight: '700', color: 'white', marginBottom: '2px' }}>
                            12<span style={{ fontSize: '11px', opacity: 0.8 }}>/15</span>
                        </div>
                        <div style={{ fontSize: '8px', color: 'rgba(255,255,255,0.95)', textTransform: 'uppercase', fontWeight: '600', letterSpacing: '0.5px' }}>Shares</div>
                    </div>
                    <div style={{ background: 'linear-gradient(135deg, #693fe9 0%, #5835c7 100%)', padding: '12px 6px', borderRadius: '10px', textAlign: 'center', boxShadow: '0 4px 12px rgba(105, 63, 233, 0.3)' }}>
                        <div style={{ fontSize: '16px', fontWeight: '700', color: 'white', marginBottom: '2px' }}>
                            8<span style={{ fontSize: '11px', opacity: 0.8 }}>/30</span>
                        </div>
                        <div style={{ fontSize: '8px', color: 'rgba(255,255,255,0.95)', textTransform: 'uppercase', fontWeight: '600', letterSpacing: '0.5px' }}>Follows</div>
                    </div>
                    <div style={{ background: 'linear-gradient(135deg, #F59E0B 0%, #D97706 100%)', padding: '12px 6px', borderRadius: '10px', textAlign: 'center', boxShadow: '0 4px 12px rgba(245, 158, 11, 0.3)' }}>
                        <div style={{ fontSize: '16px', fontWeight: '700', color: 'white', marginBottom: '2px' }}>
                            15<span style={{ fontSize: '11px', opacity: 0.8 }}>/50</span>
                        </div>
                        <div style={{ fontSize: '8px', color: 'rgba(255,255,255,0.95)', textTransform: 'uppercase', fontWeight: '600', letterSpacing: '0.5px' }}>Connections</div>
                    </div>
                </div>

                {/* Active Workings Section */}
                <div style={{ paddingTop: '12px', borderTop: '1px solid #e0e0e0', marginTop: '12px' }}>
                    <strong style={{ fontSize: '11px', display: 'block', marginBottom: '10px', color: '#333' }}>
                        <IconZap size={12} color={primaryColor} /> Active Workings:
                    </strong>
                    
                    {/* Commenter Active */}
                    <div style={{ background: 'linear-gradient(135deg, #f0f8ff 0%, #e6f0ff 100%)', padding: '10px 12px', borderRadius: '8px', marginBottom: '8px', borderLeft: '4px solid #693fe9' }}>
                        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                                <IconMessage size={14} color="#693fe9" />
                                <div>
                                    <div style={{ fontWeight: '600', fontSize: '11px', color: '#693fe9' }}>Bulk Commenting</div>
                                    <div style={{ fontSize: '9px', color: '#666' }}>Processing 5/20 posts...</div>
                                </div>
                            </div>
                            <button style={{ background: '#dc3545', color: 'white', border: 'none', padding: '4px 8px', borderRadius: '4px', fontSize: '9px', cursor: 'pointer', fontWeight: '600' }}>
                                <IconStop size={10} color="white" /> Stop
                            </button>
                        </div>
                    </div>
                    
                    {/* Networking Active */}
                    <div style={{ background: 'linear-gradient(135deg, #fff8e1 0%, #fff3cd 100%)', padding: '10px 12px', borderRadius: '8px', marginBottom: '8px', borderLeft: '4px solid #f59e0b' }}>
                        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                                <IconUsers size={14} color="#f59e0b" />
                                <div>
                                    <div style={{ fontWeight: '600', fontSize: '11px', color: '#f59e0b' }}>Networking</div>
                                    <div style={{ fontSize: '9px', color: '#666' }}>Sending connection requests...</div>
                                </div>
                            </div>
                            <button style={{ background: '#dc3545', color: 'white', border: 'none', padding: '4px 8px', borderRadius: '4px', fontSize: '9px', cursor: 'pointer', fontWeight: '600' }}>
                                <IconStop size={10} color="white" /> Stop
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            {/* Quick Actions */}
            <div style={cardStyle}>
                <h4 style={{ margin: '0 0 10px 0', fontSize: '13px', fontWeight: '600', color: primaryColor, display: 'flex', alignItems: 'center', gap: '6px' }}>
                    <IconZap size={16} color={primaryColor} /> Quick Actions
                </h4>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '8px' }}>
                    <button style={{ padding: '10px', background: primaryGradient, color: 'white', border: 'none', borderRadius: '8px', fontSize: '11px', fontWeight: '600', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px', boxShadow: '0 2px 8px rgba(105, 63, 233, 0.3)' }}>
                        <IconEdit size={14} color="white" /> AI Writer
                    </button>
                    <button style={{ padding: '10px', background: primaryGradient, color: 'white', border: 'none', borderRadius: '8px', fontSize: '11px', fontWeight: '600', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px', boxShadow: '0 2px 8px rgba(105, 63, 233, 0.3)' }}>
                        <IconMessage size={14} color="white" /> Auto Comment
                    </button>
                    <button style={{ padding: '10px', background: primaryGradient, color: 'white', border: 'none', borderRadius: '8px', fontSize: '11px', fontWeight: '600', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px', boxShadow: '0 2px 8px rgba(105, 63, 233, 0.3)' }}>
                        <IconUsers size={14} color="white" /> Connect
                    </button>
                    <button style={{ padding: '10px', background: primaryGradient, color: 'white', border: 'none', borderRadius: '8px', fontSize: '11px', fontWeight: '600', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px', boxShadow: '0 2px 8px rgba(105, 63, 233, 0.3)' }}>
                        <IconDownload size={14} color="white" /> Import CSV
                    </button>
                </div>
            </div>

            {/* Monthly Usage & Limits */}
            <div style={cardStyle}>
                <h4 style={{ margin: '0 0 12px 0', fontSize: '13px', fontWeight: '600', color: primaryColor, display: 'flex', alignItems: 'center', gap: '6px' }}>
                    <IconChart size={16} color={primaryColor} /> Monthly Usage & Limits
                </h4>
                {[
                    { icon: <IconMessage size={12} color={primaryColor} />, label: 'Comments', used: 127, max: 1500, color: primaryGradient, textColor: primaryColor },
                    { icon: <IconThumbsUp size={12} color={primaryColor} />, label: 'Likes', used: 342, max: 3000, color: 'linear-gradient(90deg, #f093fb 0%, #f5576c 100%)', textColor: '#f5576c' },
                    { icon: <IconShare size={12} color={primaryColor} />, label: 'Shares', used: 58, max: 600, color: 'linear-gradient(90deg, #4facfe 0%, #00f2fe 100%)', textColor: '#00f2fe' },
                    { icon: <IconPlus size={12} color={primaryColor} />, label: 'Follows', used: 89, max: 1500, color: 'linear-gradient(90deg, #43e97b 0%, #38f9d7 100%)', textColor: '#38f9d7' },
                    { icon: <IconUserPlus size={12} color={primaryColor} />, label: 'Connections', used: 156, max: 900, color: 'linear-gradient(90deg, #fa709a 0%, #fee140 100%)', textColor: '#fee140' },
                    { icon: <IconSparkles size={12} color={primaryColor} />, label: 'AI Posts', used: 24, max: 300, color: 'linear-gradient(90deg, #fbc2eb 0%, #a18cd1 100%)', textColor: '#a18cd1' },
                    { icon: <IconBot size={12} color={primaryColor} />, label: 'AI Comments', used: 203, max: 1500, color: 'linear-gradient(90deg, #ff9a9e 0%, #ff6b6b 100%)', textColor: '#ff6b6b' },
                    { icon: <IconLightbulb size={12} color={primaryColor} />, label: 'AI Topics', used: 45, max: 300, color: 'linear-gradient(90deg, #ffeaa7 0%, #ffd93d 100%)', textColor: '#ffd93d' },
                    { icon: <IconDownload size={12} color={primaryColor} />, label: 'Import Profiles', used: 18, max: 100, color: 'linear-gradient(90deg, #38d9a9 0%, #20c997 100%)', textColor: '#20c997' }
                ].map((item, i) => (
                    <div key={i} style={{ marginBottom: '10px' }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '3px' }}>
                            <span style={{ fontSize: '11px', fontWeight: '600', color: primaryColor, display: 'flex', alignItems: 'center', gap: '4px' }}>{item.icon} {item.label}</span>
                            <span style={{ fontSize: '10px', fontWeight: '700', color: item.textColor }}>{item.used}/{item.max}</span>
                        </div>
                        <div style={{ background: '#f0f2f5', borderRadius: '8px', height: '6px', overflow: 'hidden' }}>
                            <div style={{ background: item.color, height: '100%', width: `${(item.used/item.max)*100}%`, transition: 'width 0.3s ease' }}></div>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
}
