'use client';
import React from 'react';
import { IconDownload, IconUpload, IconEdit, IconFolder, IconCreditCard, IconLink, IconMessage, IconRocket, IconZap, IconClipboard, IconRefresh, IconCheck, IconUsers, IconThumbsUp, IconShare, IconPlus } from './Icons';

const primaryColor = '#693fe9';
const primaryGradient = 'linear-gradient(135deg, #693fe9 0%, #7c4dff 100%)';

export default function ImportTab() {
    const cardStyle: React.CSSProperties = { background: 'white', borderRadius: '12px', padding: '12px', marginBottom: '12px', boxShadow: '0 2px 8px rgba(0,0,0,0.06)' };
    const inputStyle: React.CSSProperties = { width: '100%', padding: '6px 8px', fontSize: '11px', border: '2px solid #e0e0e0', borderRadius: '6px' };

    return (
        <div style={{ padding: '12px', background: '#f5f7fa' }}>
            {/* Live Status Log Bar */}
            <div style={{ background: primaryGradient, color: 'white', padding: '10px 15px', borderRadius: '10px', marginBottom: '12px', fontSize: '12px', display: 'flex', alignItems: 'center', gap: '10px', boxShadow: '0 2px 8px rgba(102, 126, 234, 0.3)' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flex: 1 }}>
                    <IconRefresh size={16} color="white" />
                    <span style={{ fontWeight: '500' }}>Ready to import profiles</span>
                </div>
                <div style={{ fontSize: '11px', opacity: 0.8, fontFamily: 'monospace' }}>00:00:00</div>
            </div>
            
            {/* Import LinkedIn Profiles Section */}
            <div style={cardStyle}>
                <h4 style={{ margin: '0 0 10px 0', fontSize: '13px', fontWeight: '600', display: 'flex', alignItems: 'center', gap: '6px' }}><IconDownload size={14} color={primaryColor} /> Import LinkedIn Profiles</h4>
                <p style={{ margin: '0 0 12px 0', color: '#666', fontSize: '11px' }}>
                    Import LinkedIn profiles for automated engagement. You can either paste profile URLs or upload a CSV file.
                </p>
                
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px', marginBottom: '12px' }}>
                    {/* Text Input Method */}
                    <div>
                        <label style={{ fontWeight: '600', display: 'block', marginBottom: '6px', fontSize: '11px' }}>✏️ Paste Profile URLs</label>
                        <textarea 
                            placeholder="Paste LinkedIn profile URLs here, each on a new line:&#10;https://www.linkedin.com/in/john-doe-123456/&#10;https://www.linkedin.com/in/jane-smith-789012/"
                            style={{ ...inputStyle, height: '100px', resize: 'vertical', fontFamily: 'monospace', fontSize: '10px' }}
                        ></textarea>
                        <div style={{ fontSize: '10px', color: '#666', marginTop: '4px' }}>
                            Profiles detected: <strong>0</strong>
                        </div>
                    </div>
                    
                    {/* CSV Upload Method */}
                    <div>
                        <label style={{ fontWeight: '600', display: 'block', marginBottom: '6px', fontSize: '11px' }}>📁 Upload CSV File</label>
                        <div style={{ border: '2px dashed #e0e0e0', borderRadius: '6px', padding: '20px', textAlign: 'center', background: '#f8f9fa' }}>
                            <button style={{ background: primaryColor, color: 'white', border: 'none', padding: '8px 16px', borderRadius: '4px', cursor: 'pointer', fontSize: '11px' }}>
                                Choose CSV File
                            </button>
                            <div style={{ marginTop: '8px', fontSize: '10px', color: '#666' }}>
                                CSV should have profile URLs in the first column
                            </div>
                        </div>
                    </div>
                </div>
                
                {/* Import Credits Display */}
                <div style={{ padding: '12px', background: 'linear-gradient(135deg, #f3e8ff 0%, #e9d5ff 100%)', borderLeft: `4px solid ${primaryColor}`, borderRadius: '4px' }}>
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '8px' }}>
                        <strong style={{ color: primaryColor, fontSize: '12px' }}>💳 Import Credits</strong>
                        <span style={{ fontSize: '10px', color: primaryColor }}>Plan: <strong>Starters</strong></span>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                        <div style={{ flex: 1, textAlign: 'center', padding: '8px', background: 'white', borderRadius: '6px' }}>
                            <div style={{ fontSize: '20px', fontWeight: 'bold', color: primaryColor }}>0</div>
                            <div style={{ fontSize: '9px', color: '#666' }}>Remaining</div>
                        </div>
                        <div style={{ flex: 1, textAlign: 'center', padding: '8px', background: 'white', borderRadius: '6px' }}>
                            <div style={{ fontSize: '20px', fontWeight: 'bold', color: '#7c4dff' }}>100</div>
                            <div style={{ fontSize: '9px', color: '#666' }}>Monthly Total</div>
                        </div>
                        <div style={{ flex: 1, textAlign: 'center', padding: '8px', background: 'white', borderRadius: '6px' }}>
                            <div style={{ fontSize: '20px', fontWeight: 'bold', color: '#ff9800' }}>0</div>
                            <div style={{ fontSize: '9px', color: '#666' }}>Used</div>
                        </div>
                    </div>
                    <small style={{ display: 'block', color: primaryColor, fontSize: '10px', marginTop: '8px' }}>
                        💡 Each profile processed uses 1 credit, buy more 500 Credits per 1$
                    </small>
                </div>
            </div>
            
            {/* Automation Actions Section */}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px', marginBottom: '12px' }}>
                {/* Connection Requests Card */}
                <div style={cardStyle}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '10px' }}>
                        <span style={{ fontSize: '18px' }}>👤</span>
                        <h4 style={{ margin: 0, fontSize: '12px' }}>Auto Connection Requests</h4>
                    </div>
                    <p style={{ color: '#666', fontSize: '10px', marginBottom: '10px' }}>
                        Automatically send connection requests to imported profiles without personalized notes.
                    </p>
                    <div style={{ marginBottom: '10px' }}>
                        <label style={{ display: 'flex', alignItems: 'center', gap: '6px', cursor: 'pointer', fontSize: '11px' }}>
                            <input type="checkbox" style={{ width: '14px', height: '14px', accentColor: primaryColor }} />
                            <span>📧 Extract Contact Info (Email & Phone)</span>
                        </label>
                    </div>
                    <button style={{ width: '100%', padding: '10px', fontSize: '11px', background: 'linear-gradient(135deg, #0a66c2 0%, #004182 100%)', color: 'white', border: 'none', borderRadius: '6px', cursor: 'pointer' }}>
                        🚀 Start Connection Requests
                    </button>
                </div>
                
                {/* Post Engagement Card */}
                <div style={cardStyle}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '10px' }}>
                        <span style={{ fontSize: '18px' }}>❤️</span>
                        <h4 style={{ margin: 0, fontSize: '12px' }}>Auto Post Engagement</h4>
                    </div>
                    <p style={{ color: '#666', fontSize: '10px', marginBottom: '10px' }}>
                        Automatically like, comment, and engage with recent posts from imported profiles.
                    </p>
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '6px', marginBottom: '10px' }}>
                        {['👍 Likes', '💬 Comments', '🔄 Reshares', '➕ Follow'].map((action, i) => (
                            <label key={i} style={{ display: 'flex', alignItems: 'center', gap: '4px', cursor: 'pointer', fontSize: '10px' }}>
                                <input type="checkbox" defaultChecked={i < 2} style={{ width: '12px', height: '12px', accentColor: primaryColor }} />
                                <span>{action}</span>
                            </label>
                        ))}
                    </div>
                    <div style={{ marginBottom: '10px', padding: '8px', background: '#fff3cd', borderLeft: '3px solid #ffc107', borderRadius: '4px' }}>
                        <label style={{ display: 'flex', alignItems: 'center', gap: '6px', cursor: 'pointer', fontSize: '10px', fontWeight: '600' }}>
                            <input type="checkbox" style={{ width: '14px', height: '14px' }} />
                            <span>🔀 Random Mode - Pick ONE action per post</span>
                        </label>
                    </div>
                    <button style={{ width: '100%', padding: '10px', fontSize: '11px', border: `2px solid ${primaryColor}`, color: primaryColor, background: 'white', borderRadius: '6px', cursor: 'pointer' }}>
                        🎯 Start Post Engagement
                    </button>
                </div>
            </div>
            
            {/* Complete Automation Card */}
            <div style={{ ...cardStyle, background: 'linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%)', border: '2px solid #28a745' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '10px' }}>
                    <span style={{ fontSize: '18px' }}>🚀</span>
                    <h4 style={{ margin: 0, color: '#28a745', fontSize: '12px' }}>Complete Automation</h4>
                </div>
                <p style={{ color: '#666', fontSize: '10px', marginBottom: '10px' }}>
                    <strong>Do both actions for each profile:</strong> Send connection request + engage with their recent posts.
                </p>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '6px', marginBottom: '10px' }}>
                    {['👍 Likes', '💬 Comments', '🔄 Shares', '➕ Follows'].map((action, i) => (
                        <label key={i} style={{ display: 'flex', alignItems: 'center', gap: '4px', cursor: 'pointer', fontSize: '10px' }}>
                            <input type="checkbox" defaultChecked style={{ width: '12px', height: '12px', accentColor: primaryColor }} />
                            <span>{action}</span>
                        </label>
                    ))}
                </div>
                <button style={{ width: '100%', padding: '10px', fontSize: '11px', background: 'linear-gradient(135deg, #28a745 0%, #1e7e34 100%)', color: 'white', border: 'none', borderRadius: '6px', cursor: 'pointer' }}>
                    🚀 Start Complete Automation
                </button>
            </div>
            
            {/* Action History Section */}
            <div style={cardStyle}>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '10px' }}>
                    <h4 style={{ margin: 0, fontSize: '12px' }}>📊 Import Actions History</h4>
                    <div style={{ display: 'flex', gap: '6px' }}>
                        <button style={{ padding: '5px 10px', fontSize: '10px', background: '#10a37f', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' }}>📥 Export CSV</button>
                        <button style={{ padding: '5px 10px', fontSize: '10px', background: '#f1f5f9', color: '#64748b', border: 'none', borderRadius: '4px', cursor: 'pointer' }}>🔄 Refresh</button>
                        <button style={{ padding: '5px 10px', fontSize: '10px', background: '#f1f5f9', color: '#64748b', border: 'none', borderRadius: '4px', cursor: 'pointer' }}>🗑️ Clear</button>
                    </div>
                </div>
                
                <div style={{ display: 'flex', gap: '15px', marginBottom: '10px', fontSize: '11px' }}>
                    <div>Total Profiles: <strong>0</strong></div>
                    <div>Connection Requests: <strong>0</strong></div>
                    <div>Posts Engaged: <strong>0</strong></div>
                    <div>Success Rate: <strong>0%</strong></div>
                </div>
                
                <div style={{ maxHeight: '150px', overflowY: 'auto', border: '1px solid #e0e0e0', borderRadius: '6px' }}>
                    <table style={{ width: '100%', fontSize: '10px', borderCollapse: 'collapse' }}>
                        <thead style={{ background: '#f8f9fa', position: 'sticky', top: 0 }}>
                            <tr>
                                <th style={{ padding: '6px', textAlign: 'left', borderBottom: '1px solid #e0e0e0' }}>Date</th>
                                <th style={{ padding: '6px', textAlign: 'left', borderBottom: '1px solid #e0e0e0' }}>Profile Name</th>
                                <th style={{ padding: '6px', textAlign: 'center', borderBottom: '1px solid #e0e0e0' }}>Conn</th>
                                <th style={{ padding: '6px', textAlign: 'center', borderBottom: '1px solid #e0e0e0' }}>Likes</th>
                                <th style={{ padding: '6px', textAlign: 'center', borderBottom: '1px solid #e0e0e0' }}>Comments</th>
                                <th style={{ padding: '6px', textAlign: 'left', borderBottom: '1px solid #e0e0e0' }}>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td colSpan={6} style={{ padding: '20px', textAlign: 'center', color: '#999' }}>
                                    No import actions yet. Start importing profiles to see history here.
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
}
