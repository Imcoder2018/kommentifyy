'use client';
import React from 'react';
import { IconAlert, IconSettings, IconSliders, IconTimer, IconClock, IconMessage, IconThumbsUp, IconShare, IconPlus, IconUserPlus, IconBot, IconMouse, IconEye, IconLayers, IconSave, IconRocket, IconGlobe } from './Icons';

const primaryColor = '#693fe9';
const primaryGradient = 'linear-gradient(135deg, #693fe9 0%, #7c4dff 100%)';

export default function LimitsTab() {
    const cardStyle: React.CSSProperties = { background: 'white', borderRadius: '12px', padding: '12px', marginBottom: '10px', boxShadow: '0 2px 8px rgba(0,0,0,0.06)' };

    return (
        <div style={{ padding: '12px', background: '#f5f7fa' }}>
            {/* Live Status Log Bar */}
            <div style={{ background: primaryGradient, color: 'white', padding: '10px 15px', borderRadius: '10px', marginBottom: '12px', fontSize: '12px', display: 'flex', alignItems: 'center', gap: '10px', boxShadow: '0 2px 8px rgba(102, 126, 234, 0.3)' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flex: 1 }}>
                    <IconAlert size={16} color="white" />
                    <span style={{ fontWeight: '500' }}>Limits configured - Safe automation active</span>
                </div>
                <div style={{ fontSize: '11px', opacity: 0.8, fontFamily: 'monospace' }}>00:00:00</div>
            </div>
            
            <div style={{ ...cardStyle, background: 'linear-gradient(135deg, #f8f9fa 0%, #ffffff 100%)' }}>
                {/* Header */}
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '12px', paddingBottom: '10px', borderBottom: '2px solid #e0e0e0' }}>
                    <div>
                        <h4 style={{ margin: '0 0 3px 0', fontSize: '13px', fontWeight: '600', display: 'flex', alignItems: 'center', gap: '6px' }}><IconAlert size={14} color={primaryColor} /> Daily Limits & Delays</h4>
                        <small style={{ color: '#666', fontSize: '10px' }}>LinkedIn-safe automation limits and timing controls</small>
                    </div>
                    <select style={{ padding: '5px 8px', fontSize: '10px', border: '2px solid #e0e0e0', borderRadius: '4px', background: 'white' }}>
                        <option>⚙️ Custom (Your Settings)</option>
                        <option>🌱 New Account (0-2 weeks)</option>
                        <option>🌿 New Account (2-8 weeks)</option>
                        <option selected>✅ Matured (Safe - Recommended)</option>
                        <option>⚡ Matured (Faster)</option>
                        <option>💎 LinkedIn Premium</option>
                        <option>🎯 Sales Navigator</option>
                        <option>🚀 Speed Mode (Use Carefully)</option>
                    </select>
                </div>

                {/* Today's Activity */}
                <div style={{ background: '#f0f8ff', padding: '8px 10px', borderRadius: '6px', marginBottom: '10px', fontSize: '10px', display: 'flex', justifyContent: 'space-around', flexWrap: 'wrap', gap: '6px' }}>
                    <span>💬 Comments: <strong style={{ color: primaryColor }}>23/30</strong></span>
                    <span>👍 Likes: <strong style={{ color: primaryColor }}>47/60</strong></span>
                    <span>🔄 Shares: <strong style={{ color: primaryColor }}>12/15</strong></span>
                    <span>👥 Follows: <strong style={{ color: primaryColor }}>8/30</strong></span>
                </div>

                {/* Daily Limits Card */}
                <div style={{ background: 'white', padding: '10px', borderRadius: '8px', marginBottom: '10px', border: '2px solid #e0e0e0' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '6px', marginBottom: '8px' }}>
                        <span style={{ fontSize: '14px' }}>📊</span>
                        <strong style={{ color: primaryColor, fontSize: '11px' }}>Daily Limits (Stops when reached)</strong>
                    </div>
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px' }}>
                        {[
                            { label: '💬 Comments Limit:', value: 30, max: 200 },
                            { label: '👍 Likes Limit:', value: 60, max: 500 },
                            { label: '🔄 Shares Limit:', value: 15, max: 100 },
                            { label: '👥 Follows Limit:', value: 30, max: 200 }
                        ].map((item, i) => (
                            <div key={i}>
                                <label style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '3px', fontSize: '10px', color: '#666', fontWeight: '600' }}>
                                    <span>{item.label}</span>
                                    <strong style={{ color: primaryColor, fontSize: '11px' }}>{item.value}</strong>
                                </label>
                                <input type="range" min="0" max={item.max} defaultValue={item.value} style={{ width: '100%' }} />
                            </div>
                        ))}
                    </div>
                </div>

                {/* Starting Delays Card */}
                <div style={{ background: 'white', padding: '10px', borderRadius: '8px', marginBottom: '10px', border: '2px solid #e0e0e0' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '6px', marginBottom: '8px' }}>
                        <span style={{ fontSize: '14px' }}>🕐</span>
                        <strong style={{ color: primaryColor, fontSize: '11px' }}>Starting Delays</strong>
                    </div>
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '10px' }}>
                        {[
                            { label: 'Automation Start:', value: '30s', desc: 'Before starting automation' },
                            { label: 'Networking Start:', value: '30s', desc: 'Before starting networking' },
                            { label: 'Import Profiles:', value: '30s', desc: 'Before starting import' }
                        ].map((item, i) => (
                            <div key={i}>
                                <label style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '3px', fontSize: '10px', color: '#666', fontWeight: '600' }}>
                                    <span>{item.label}</span>
                                    <strong style={{ color: primaryColor, fontSize: '11px' }}>{item.value}</strong>
                                </label>
                                <input type="range" min="0" max="300" defaultValue="30" style={{ width: '100%' }} />
                                <small style={{ color: '#999', fontSize: '9px' }}>{item.desc}</small>
                            </div>
                        ))}
                    </div>
                </div>

                {/* Automation Delay Intervals Card */}
                <div style={{ background: 'white', padding: '10px', borderRadius: '8px', marginBottom: '10px', border: '2px solid #e0e0e0' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '6px', marginBottom: '8px' }}>
                        <span style={{ fontSize: '14px' }}>⏱️</span>
                        <strong style={{ color: primaryColor, fontSize: '11px' }}>Automation Delay Intervals</strong>
                    </div>
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px' }}>
                        <div>
                            <label style={{ display: 'block', marginBottom: '5px', fontSize: '10px', color: '#666', fontWeight: '600' }}>Search Delay (Between Keywords)</label>
                            <div style={{ display: 'flex', gap: '6px' }}>
                                <div style={{ flex: 1 }}>
                                    <label style={{ display: 'flex', justifyContent: 'space-between', fontSize: '9px', color: '#999' }}>
                                        <span>Min</span><strong style={{ color: primaryColor }}>45s</strong>
                                    </label>
                                    <input type="range" min="10" max="120" defaultValue="45" style={{ width: '100%' }} />
                                </div>
                                <div style={{ flex: 1 }}>
                                    <label style={{ display: 'flex', justifyContent: 'space-between', fontSize: '9px', color: '#999' }}>
                                        <span>Max</span><strong style={{ color: primaryColor }}>1m 30s</strong>
                                    </label>
                                    <input type="range" min="30" max="300" defaultValue="90" style={{ width: '100%' }} />
                                </div>
                            </div>
                        </div>
                        <div>
                            <label style={{ display: 'block', marginBottom: '5px', fontSize: '10px', color: '#666', fontWeight: '600' }}>Comment Delay Interval</label>
                            <div style={{ display: 'flex', gap: '6px' }}>
                                <div style={{ flex: 1 }}>
                                    <label style={{ display: 'flex', justifyContent: 'space-between', fontSize: '9px', color: '#999' }}>
                                        <span>Min</span><strong style={{ color: primaryColor }}>1m</strong>
                                    </label>
                                    <input type="range" min="30" max="600" defaultValue="60" style={{ width: '100%' }} />
                                </div>
                                <div style={{ flex: 1 }}>
                                    <label style={{ display: 'flex', justifyContent: 'space-between', fontSize: '9px', color: '#999' }}>
                                        <span>Max</span><strong style={{ color: primaryColor }}>3m</strong>
                                    </label>
                                    <input type="range" min="60" max="1800" defaultValue="180" style={{ width: '100%' }} />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Networking Delay Card */}
                <div style={{ background: 'white', padding: '10px', borderRadius: '8px', marginBottom: '10px', border: '2px solid #e0e0e0' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '6px', marginBottom: '8px' }}>
                        <span style={{ fontSize: '14px' }}>🔗</span>
                        <strong style={{ color: primaryColor, fontSize: '11px' }}>Networking Delay Intervals</strong>
                    </div>
                    <div>
                        <label style={{ display: 'block', marginBottom: '5px', fontSize: '10px', color: '#666', fontWeight: '600' }}>Connection Request Delay</label>
                        <div style={{ display: 'flex', gap: '6px' }}>
                            <div style={{ flex: 1 }}>
                                <label style={{ display: 'flex', justifyContent: 'space-between', fontSize: '9px', color: '#999' }}>
                                    <span>Min</span><strong style={{ color: primaryColor }}>45s</strong>
                                </label>
                                <input type="range" min="10" max="120" defaultValue="45" style={{ width: '100%' }} />
                            </div>
                            <div style={{ flex: 1 }}>
                                <label style={{ display: 'flex', justifyContent: 'space-between', fontSize: '9px', color: '#999' }}>
                                    <span>Max</span><strong style={{ color: primaryColor }}>1m 30s</strong>
                                </label>
                                <input type="range" min="30" max="300" defaultValue="90" style={{ width: '100%' }} />
                            </div>
                        </div>
                    </div>
                </div>

                {/* Human Simulation Card */}
                <div style={{ background: 'white', padding: '10px', borderRadius: '8px', marginBottom: '10px', border: '2px solid #e0e0e0' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '6px', marginBottom: '8px' }}>
                        <span style={{ fontSize: '14px' }}>🤖</span>
                        <strong style={{ color: primaryColor, fontSize: '11px' }}>Human Simulation Features</strong>
                    </div>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '6px', fontSize: '11px' }}>
                        {[
                            'Mouse Trajectory Humanization (Bezier curves)',
                            'In-Tab Simulation (Random scrolling behavior)',
                            'Reading Simulation (Pause and scroll patterns)'
                        ].map((feature, i) => (
                            <label key={i} style={{ display: 'flex', alignItems: 'center', gap: '5px', cursor: 'pointer' }}>
                                <input type="checkbox" defaultChecked style={{ width: '14px', height: '14px', accentColor: primaryColor }} />
                                <span>{feature}</span>
                            </label>
                        ))}
                    </div>
                    <small style={{ display: 'block', color: '#999', marginTop: '6px', fontSize: '9px' }}>
                        💡 Makes automation appear more natural and human-like
                    </small>
                </div>

                {/* Save Button */}
                <div style={{ background: '#f0f8ff', padding: '10px', borderRadius: '6px', textAlign: 'center' }}>
                    <button style={{ padding: '10px 20px', fontSize: '12px', fontWeight: '600', background: primaryGradient, color: 'white', border: 'none', borderRadius: '8px', cursor: 'pointer', boxShadow: '0 4px 12px rgba(105, 63, 233, 0.3)' }}>
                        💾 Save All Settings
                    </button>
                    <small style={{ display: 'block', marginTop: '5px', color: '#666', fontSize: '9px' }}>
                        Settings auto-save when changed
                    </small>
                </div>
            </div>
        </div>
    );
}
