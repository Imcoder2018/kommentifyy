'use client';
import React from 'react';
import { IconSearch, IconClock, IconCalendar, IconTarget, IconRocket, IconSettings, IconUserPlus, IconFilter, IconMail, IconLink, IconUsers, IconX, IconCheck, IconGlobe } from './Icons';

const primaryColor = '#693fe9';
const primaryGradient = 'linear-gradient(135deg, #693fe9 0%, #7c4dff 100%)';

export default function NetworkTab() {
    const cardStyle: React.CSSProperties = { background: 'white', borderRadius: '12px', padding: '12px', marginBottom: '12px', boxShadow: '0 2px 8px rgba(0,0,0,0.06)' };
    const inputStyle: React.CSSProperties = { width: '100%', padding: '6px 8px', fontSize: '11px', border: '2px solid #e0e0e0', borderRadius: '6px' };

    return (
        <div style={{ padding: '12px', background: '#f5f7fa' }}>
            {/* Live Status Log Bar */}
            <div style={{ background: primaryGradient, color: 'white', padding: '10px 15px', borderRadius: '10px', marginBottom: '12px', fontSize: '12px', display: 'flex', alignItems: 'center', gap: '10px', boxShadow: '0 2px 8px rgba(102, 126, 234, 0.3)' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flex: 1 }}>
                    <IconUsers size={16} color="white" />
                    <span style={{ fontWeight: '500' }}>Networking ready - Enter search query to start</span>
                </div>
                <div style={{ fontSize: '11px', opacity: 0.8, fontFamily: 'monospace' }}>00:00:00</div>
            </div>
            
            <div style={{ ...cardStyle, background: 'linear-gradient(135deg, #f8f9fa 0%, #ffffff 100%)' }}>
                {/* Header */}
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '12px', paddingBottom: '10px', borderBottom: '2px solid #e0e0e0' }}>
                    <div>
                        <h4 style={{ margin: '0 0 3px 0', fontSize: '13px', fontWeight: '600', display: 'flex', alignItems: 'center', gap: '6px' }}><IconSearch size={14} color={primaryColor} /> Auto Search & Connect</h4>
                        <small style={{ color: '#666', fontSize: '10px' }}>Search LinkedIn and auto-send connection requests</small>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '5px', fontSize: '10px', color: '#666' }}>
                        <span>🕐 Auto-Schedule</span>
                        <div style={{ width: '32px', height: '18px', background: '#e2e8f0', borderRadius: '9px', position: 'relative', cursor: 'pointer' }}>
                            <div style={{ width: '14px', height: '14px', background: 'white', borderRadius: '50%', position: 'absolute', top: '2px', left: '2px', boxShadow: '0 1px 3px rgba(0,0,0,0.2)' }}></div>
                        </div>
                    </div>
                </div>

                {/* Scheduled Times Section */}
                <div style={{ background: '#f0f8ff', padding: '10px', borderRadius: '6px', marginBottom: '10px', fontSize: '10px' }}>
                    <div style={{ marginBottom: '5px', fontWeight: '600', color: primaryColor }}>📅 Scheduled Times:</div>
                    <div style={{ color: '#999', marginBottom: '6px' }}>No schedules. Add time below.</div>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', paddingTop: '6px', borderTop: '1px solid #d0e8ff' }}>
                        <span>⏰ Next: <strong>--</strong></span>
                        <span>⏳ <strong>--:--:--</strong></span>
                    </div>
                </div>

                {/* Search Configuration */}
                <div style={{ background: 'white', padding: '10px', borderRadius: '8px', marginBottom: '10px', border: '2px solid #e0e0e0' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '6px', marginBottom: '8px' }}>
                        <span style={{ fontSize: '14px' }}>🎯</span>
                        <strong style={{ color: primaryColor, fontSize: '12px' }}>Search Configuration</strong>
                    </div>
                    <div style={{ marginBottom: '8px' }}>
                        <label style={{ display: 'block', marginBottom: '3px', fontSize: '10px', color: '#666', fontWeight: '600' }}>Search Keyword:</label>
                        <input type="text" placeholder="e.g., VP of Sales, Growth Hacker, Marketing Director" style={inputStyle} />
                        <small style={{ display: 'block', marginTop: '3px', color: '#f59e0b', fontSize: '9px' }}>
                            💡 Supports Boolean: "VP OR Vice President" AND Sales NOT Intern
                        </small>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '6px', marginBottom: '8px' }}>
                        <input type="time" style={{ padding: '5px', fontSize: '10px', width: '75px', border: '2px solid #e0e0e0', borderRadius: '4px' }} />
                        <button style={{ padding: '5px 8px', fontSize: '10px', background: primaryColor, color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' }}>➕ Add Schedule</button>
                    </div>
                    <button style={{ width: '100%', padding: '10px', fontSize: '12px', fontWeight: '600', background: primaryGradient, color: 'white', border: 'none', borderRadius: '8px', cursor: 'pointer', boxShadow: '0 4px 12px rgba(105, 63, 233, 0.3)' }}>
                        🚀 Start People Search & Connect
                    </button>
                </div>

                {/* 2-Column Layout: Connection Settings + Search Filters */}
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px', marginBottom: '10px' }}>
                    {/* Connection Settings */}
                    <div style={{ background: 'white', padding: '10px', borderRadius: '8px', border: '2px solid #e0e0e0' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '6px', marginBottom: '8px' }}>
                            <span style={{ fontSize: '14px' }}>📊</span>
                            <strong style={{ color: primaryColor, fontSize: '11px' }}>Connection Settings</strong>
                        </div>
                        <div style={{ marginBottom: '8px' }}>
                            <label style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '3px', fontSize: '10px' }}>
                                <span>Connections:</span>
                                <strong style={{ color: primaryColor }}>10</strong>
                            </label>
                            <input type="range" min="1" max="50" defaultValue="10" style={{ width: '100%' }} />
                            <small style={{ display: 'block', marginTop: '2px', color: '#999', fontSize: '9px' }}>Max per session (50/day recommended)</small>
                        </div>
                        <div>
                            <label style={{ display: 'block', marginBottom: '3px', fontSize: '10px', color: '#666', fontWeight: '600' }}>❌ Exclude Headline Terms:</label>
                            <input type="text" defaultValue="Aspiring, Former, Seeking, Student, Intern" placeholder="Aspiring, Former, Student, Seeking" style={{ ...inputStyle, fontSize: '10px' }} />
                            <small style={{ display: 'block', marginTop: '2px', color: '#999', fontSize: '9px' }}>Comma-separated terms to skip</small>
                        </div>
                    </div>

                    {/* Search Filters */}
                    <div style={{ background: 'white', padding: '10px', borderRadius: '8px', border: '2px solid #e0e0e0' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '6px', marginBottom: '8px' }}>
                            <span style={{ fontSize: '14px' }}>🔍</span>
                            <strong style={{ color: primaryColor, fontSize: '11px' }}>Search Filters</strong>
                        </div>
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '5px', fontSize: '11px' }}>
                            {[
                                { label: 'Use Boolean Logic', checked: true },
                                { label: '2nd/3rd Degree Only', checked: true },
                                { label: 'Send with Note', checked: false },
                                { label: '✉️ Send Connection Request', checked: true },
                                { label: '📧 Extract Contact Info', checked: false }
                            ].map((filter, i) => (
                                <label key={i} style={{ display: 'flex', alignItems: 'center', gap: '5px', cursor: 'pointer' }}>
                                    <input type="checkbox" defaultChecked={filter.checked} style={{ width: '14px', height: '14px', accentColor: primaryColor }} />
                                    <span>{filter.label}</span>
                                </label>
                            ))}
                        </div>
                        <small style={{ display: 'block', color: '#999', marginTop: '6px', fontSize: '9px' }}>
                            💡 Check at least one action: Send Request or Extract Contact Info
                        </small>
                    </div>
                </div>

                {/* Connection Message */}
                <div style={{ background: 'white', padding: '10px', borderRadius: '8px', marginBottom: '10px', border: '2px solid #e0e0e0' }}>
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '8px' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                            <span style={{ fontSize: '14px' }}>✉️</span>
                            <strong style={{ color: primaryColor, fontSize: '11px' }}>Connection Message (Optional)</strong>
                        </div>
                        <small style={{ color: primaryColor, fontWeight: 'bold', fontSize: '10px' }}>0/300</small>
                    </div>
                    <textarea 
                        rows={3}
                        placeholder="Hi [Name],&#10;&#10;I noticed your experience in [Industry] and would love to connect!&#10;&#10;Best regards"
                        maxLength={300}
                        style={{ ...inputStyle, resize: 'vertical', fontFamily: '-apple-system, BlinkMacSystemFont, Segoe UI, Roboto, sans-serif', lineHeight: '1.5' }}
                    ></textarea>
                    <small style={{ display: 'block', marginTop: '3px', color: '#999', fontSize: '9px' }}>
                        Use [Name] for personalization
                    </small>
                </div>

                {/* Progress Indicator (Hidden by default) */}
                <div style={{ display: 'none', marginBottom: '10px', padding: '10px', background: '#f0f8ff', borderRadius: '6px', borderLeft: `4px solid ${primaryColor}` }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '6px' }}>
                        <span style={{ fontWeight: '600', color: primaryColor, fontSize: '11px' }}>Processing...</span>
                        <span style={{ fontSize: '10px', color: '#666' }}>0/0</span>
                    </div>
                    <div style={{ width: '100%', height: '5px', background: '#e0e0e0', borderRadius: '3px', overflow: 'hidden' }}>
                        <div style={{ height: '100%', background: primaryGradient, width: '0%', transition: 'width 0.3s ease' }}></div>
                    </div>
                    <div style={{ fontSize: '9px', color: '#666', marginTop: '4px' }}>Initializing...</div>
                </div>

                {/* Bottom Start Button */}
                <button style={{ width: '100%', padding: '12px', fontSize: '13px', fontWeight: '600', background: primaryGradient, color: 'white', border: 'none', borderRadius: '10px', cursor: 'pointer', boxShadow: '0 4px 12px rgba(105, 63, 233, 0.3)' }}>
                    🚀 Start People Search & Connect
                </button>
            </div>
        </div>
    );
}
