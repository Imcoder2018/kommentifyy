'use client';
import React from 'react';
import { IconUsers, IconBook, IconZap, IconClock, IconCalendar, IconLogOut, IconArrowUp, IconPlay, IconSettings, IconMail, IconCheck, IconExternalLink } from './Icons';

const primaryColor = '#693fe9';
const primaryGradient = 'linear-gradient(135deg, #693fe9 0%, #7c4dff 100%)';

export default function SettingsTab() {
    const cardStyle: React.CSSProperties = { background: 'white', borderRadius: '12px', padding: '12px', marginBottom: '10px', boxShadow: '0 2px 8px rgba(0,0,0,0.06)' };

    return (
        <div style={{ padding: '12px', background: '#f5f7fa' }}>
            {/* Live Status Log Bar */}
            <div style={{ background: primaryGradient, color: 'white', padding: '10px 15px', borderRadius: '10px', marginBottom: '12px', fontSize: '12px', display: 'flex', alignItems: 'center', gap: '10px', boxShadow: '0 2px 8px rgba(102, 126, 234, 0.3)' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flex: 1 }}>
                    <IconSettings size={16} color="white" />
                    <span style={{ fontWeight: '500' }}>Settings loaded - Configure your preferences</span>
                </div>
                <div style={{ fontSize: '11px', opacity: 0.8 }}>v2.0.0</div>
            </div>
            
            {/* Account Info */}
            <div style={cardStyle}>
                <div style={{ cursor: 'pointer', padding: '8px 0', borderBottom: '1px solid #e0e0e0', marginBottom: '10px' }}>
                    <span style={{ fontSize: '12px', fontWeight: '600', display: 'flex', alignItems: 'center', gap: '6px' }}><IconUsers size={14} color={primaryColor} /> Account Info</span>
                </div>
                <div style={{ background: primaryGradient, padding: '12px', borderRadius: '10px', marginBottom: '12px', color: 'white' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px' }}>
                        <div style={{ fontSize: '11px', opacity: 0.9 }}>Account Status</div>
                        <div style={{ background: 'rgba(255,255,255,0.2)', padding: '3px 8px', borderRadius: '10px', fontSize: '10px', fontWeight: '600' }}>
                            Not Logged In
                        </div>
                    </div>
                    <div style={{ background: 'rgba(255,255,255,0.1)', padding: '6px 10px', borderRadius: '6px', marginBottom: '8px' }}>
                        <div style={{ fontSize: '9px', opacity: 0.7, marginBottom: '2px' }}>Email</div>
                        <div style={{ fontSize: '11px', fontWeight: '500' }}>Not logged in</div>
                    </div>
                    <div style={{ background: 'rgba(255,255,255,0.15)', padding: '6px 10px', borderRadius: '6px' }}>
                        <div style={{ fontSize: '9px', opacity: 0.7, marginBottom: '2px' }}>Current Plan</div>
                        <div style={{ fontSize: '14px', fontWeight: '700' }}>Free</div>
                    </div>
                </div>
                <div style={{ display: 'flex', gap: '8px' }}>
                    <button style={{ flex: 1, padding: '10px', background: primaryColor, color: 'white', border: 'none', borderRadius: '6px', fontWeight: '600', cursor: 'pointer', fontSize: '11px' }}>🔑 Login to Account</button>
                </div>

                {/* Plan Limits Info */}
                <div style={{ padding: '12px', background: 'white', border: '1px solid #e0e0e0', borderRadius: '10px', marginTop: '12px' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '6px', marginBottom: '10px', paddingBottom: '8px', borderBottom: '2px solid #f0f0f0' }}>
                        <span style={{ fontSize: '16px' }}>📊</span>
                        <strong style={{ fontSize: '12px', color: primaryColor }}>Your Monthly Limits</strong>
                    </div>
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px' }}>
                        {[
                            { icon: '💬', label: 'Comments', value: '--' },
                            { icon: '❤️', label: 'Likes', value: '--' },
                            { icon: '🔄', label: 'Shares', value: '--' },
                            { icon: '👥', label: 'Follows', value: '--' },
                            { icon: '🔗', label: 'Connections', value: '--' },
                            { icon: '🤖', label: 'AI Posts', value: '--' },
                            { icon: '💭', label: 'AI Comments', value: '--' },
                            { icon: '💡', label: 'AI Topics', value: '--' }
                        ].map((item, i) => (
                            <div key={i} style={{ background: '#f8f9fa', padding: '8px', borderRadius: '6px', borderLeft: `3px solid ${primaryColor}` }}>
                                <div style={{ fontSize: '10px', color: '#666', marginBottom: '3px' }}>{item.icon} {item.label}</div>
                                <div style={{ fontSize: '14px', fontWeight: 'bold', color: primaryColor }}>{item.value}<span style={{ fontSize: '10px', fontWeight: 'normal', color: '#999' }}>/month</span></div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>

            {/* Help & Guides */}
            <div style={cardStyle}>
                <div style={{ cursor: 'pointer', padding: '8px 0', borderBottom: '1px solid #e0e0e0', marginBottom: '10px' }}>
                    <span style={{ fontSize: '12px', fontWeight: '600' }}>📚 Help & Guides</span>
                </div>
                <div style={{ background: primaryGradient, padding: '10px 12px', borderRadius: '10px', color: 'white', marginBottom: '10px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                    <div>
                        <div style={{ fontSize: '11px', fontWeight: '700' }}>🏆 Quick Tour</div>
                        <div style={{ fontSize: '10px', opacity: 0.9 }}>New to the extension?</div>
                    </div>
                    <button style={{ background: 'white', color: primaryColor, border: 'none', padding: '6px 12px', borderRadius: '6px', fontSize: '10px', fontWeight: '700', cursor: 'pointer' }}>Start</button>
                </div>
                <div style={{ fontSize: '10px', color: '#666', marginBottom: '6px' }}>Quick feature overviews. For detailed guides, see below.</div>
            </div>

            {/* Detailed Feature Guides */}
            <div style={cardStyle}>
                <div style={{ cursor: 'pointer', padding: '8px 0', borderBottom: '1px solid #e0e0e0', marginBottom: '10px' }}>
                    <span style={{ fontSize: '12px', fontWeight: '600' }}>📖 Detailed Feature Guides</span>
                </div>
                {[
                    { title: '📊 Dashboard - Your Command Center', color: primaryColor },
                    { title: '✏️ AI Writer - Create Viral Content', color: '#4caf50' },
                    { title: '🤖 Automation - Engage at Scale', color: '#ff9800' },
                    { title: '👤 Networking - Grow Your Network', color: '#2196f3' },
                    { title: '📥 Import - Target Specific Profiles', color: '#9c27b0' },
                    { title: '📏 Limits - Stay Safe', color: '#f44336' }
                ].map((guide, i) => (
                    <div key={i} style={{ background: '#f8f9fa', borderRadius: '6px', marginBottom: '6px', borderLeft: `3px solid ${guide.color}`, padding: '8px 10px', cursor: 'pointer', fontSize: '11px', fontWeight: '600', color: primaryColor }}>
                        {guide.title}
                    </div>
                ))}
                <div style={{ background: 'linear-gradient(135deg, #e8f5e9 0%, #c8e6c9 100%)', padding: '10px', borderRadius: '6px', marginTop: '8px' }}>
                    <div style={{ fontSize: '11px', fontWeight: '700', color: '#2e7d32', marginBottom: '6px' }}>🏆 Best Practices for Success</div>
                    <ul style={{ margin: 0, paddingLeft: '15px', fontSize: '10px', color: '#1b5e20', lineHeight: '1.6' }}>
                        <li><strong>Start slow:</strong> Begin with 10-15 daily actions</li>
                        <li><strong>Use business hours:</strong> 9 AM - 6 PM looks more natural</li>
                        <li><strong>AI comments &gt; likes:</strong> Comments drive more engagement</li>
                        <li><strong>Be consistent:</strong> Daily small actions beat weekly bursts</li>
                    </ul>
                </div>
            </div>

            {/* Business Hours */}
            <div style={cardStyle}>
                <div style={{ cursor: 'pointer', padding: '8px 0', borderBottom: '1px solid #e0e0e0', marginBottom: '10px' }}>
                    <span style={{ fontSize: '12px', fontWeight: '600' }}>🕐 Business Hours</span>
                </div>
                <div style={{ background: 'white', padding: '10px', borderRadius: '8px', border: '2px solid #e0e0e0', marginBottom: '10px' }}>
                    <div style={{ marginBottom: '8px' }}>
                        <label style={{ display: 'flex', alignItems: 'center', gap: '5px', fontSize: '11px', cursor: 'pointer' }}>
                            <input type="checkbox" defaultChecked style={{ width: '14px', height: '14px', accentColor: primaryColor }} />
                            <span>Enable Business Hours</span>
                        </label>
                    </div>
                    <div style={{ display: 'flex', gap: '10px', fontSize: '11px' }}>
                        <label style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                            Start:
                            <select defaultValue="9" style={{ padding: '4px', fontSize: '10px', border: '1px solid #e0e0e0', borderRadius: '4px' }}>
                                <option value="6">6 AM</option>
                                <option value="7">7 AM</option>
                                <option value="8">8 AM</option>
                                <option value="9">9 AM</option>
                                <option value="10">10 AM</option>
                            </select>
                        </label>
                        <label style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                            End:
                            <select defaultValue="18" style={{ padding: '4px', fontSize: '10px', border: '1px solid #e0e0e0', borderRadius: '4px' }}>
                                <option value="17">5 PM</option>
                                <option value="18">6 PM</option>
                                <option value="19">7 PM</option>
                                <option value="20">8 PM</option>
                            </select>
                        </label>
                    </div>
                </div>
                <div style={{ background: 'white', padding: '10px', borderRadius: '8px', border: '2px solid #e0e0e0' }}>
                    <div style={{ fontSize: '11px', fontWeight: '600', color: primaryColor, marginBottom: '6px' }}>📅 Active Days</div>
                    <div style={{ marginBottom: '6px' }}>
                        <label style={{ display: 'flex', alignItems: 'center', gap: '5px', fontSize: '10px', cursor: 'pointer' }}>
                            <input type="checkbox" style={{ width: '12px', height: '12px', accentColor: primaryColor }} />
                            <span>Allow Weekends</span>
                        </label>
                    </div>
                    <div style={{ display: 'flex', gap: '3px', fontSize: '9px' }}>
                        {['M', 'T', 'W', 'T', 'F', 'S', 'S'].map((day, i) => (
                            <label key={i} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '2px', padding: '5px 7px', background: i < 5 ? primaryGradient : '#f8f9fa', color: i < 5 ? 'white' : '#666', borderRadius: '4px', cursor: 'pointer' }}>
                                <input type="checkbox" defaultChecked={i < 5} style={{ width: '10px', height: '10px', display: 'none' }} />
                                <span style={{ fontWeight: '600' }}>{day}</span>
                            </label>
                        ))}
                    </div>
                    <div style={{ fontSize: '8px', color: '#999', marginTop: '5px' }}>Auto-saves</div>
                </div>
            </div>
        </div>
    );
}
