'use client';
import React from 'react';
import { IconEdit, IconLightbulb, IconTarget, IconFileText, IconSliders, IconHash, IconSmile, IconSparkles, IconChart, IconClock, IconCalendar, IconRocket, IconSave, IconSend } from './Icons';

const primaryColor = '#693fe9';
const primaryGradient = 'linear-gradient(135deg, #693fe9 0%, #7c4dff 100%)';

export default function WriterTab() {
    const cardStyle: React.CSSProperties = { background: 'white', borderRadius: '12px', padding: '15px', marginBottom: '12px', boxShadow: '0 2px 8px rgba(0,0,0,0.06)' };
    const inputStyle: React.CSSProperties = { width: '100%', padding: '8px 10px', fontSize: '12px', border: '2px solid #e0e0e0', borderRadius: '6px' };

    return (
        <div style={{ padding: '12px', background: '#f5f7fa' }}>
            {/* Live Status Log Bar */}
            <div style={{ background: primaryGradient, color: 'white', padding: '10px 15px', borderRadius: '10px', marginBottom: '12px', fontSize: '12px', display: 'flex', alignItems: 'center', gap: '10px', boxShadow: '0 2px 8px rgba(102, 126, 234, 0.3)' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flex: 1 }}>
                    <IconEdit size={16} color="white" />
                    <span style={{ fontWeight: '500' }}>AI Writer ready - Generate engaging content</span>
                </div>
                <div style={{ fontSize: '11px', opacity: 0.8, fontFamily: 'monospace' }}>Credits: Unlimited</div>
            </div>
            
            {/* Main 2-Column Layout */}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px', marginBottom: '12px' }}>
                
                {/* LEFT COLUMN: Post Settings */}
                <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                    <div style={{ ...cardStyle, background: 'linear-gradient(135deg, #f8f9fa 0%, #ffffff 100%)' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '12px', paddingBottom: '10px', borderBottom: '2px solid #e0e0e0' }}>
                            <IconEdit size={16} color={primaryColor} />
                            <h4 style={{ margin: 0, color: primaryColor, fontSize: '13px' }}>Post Settings</h4>
                        </div>
                        
                        {/* Topic/Idea */}
                        <div style={{ marginBottom: '10px' }}>
                            <label style={{ fontWeight: '600', color: primaryColor, marginBottom: '6px', display: 'flex', alignItems: 'center', gap: '4px', fontSize: '11px' }}>
                                <IconLightbulb size={12} color={primaryColor} /> Topic/Idea
                            </label>
                            <input type="text" defaultValue="LinkedIn Growth Strategies for 2024" style={inputStyle} />
                            <button style={{ marginTop: '6px', width: '100%', padding: '7px', fontSize: '11px', background: '#f1f5f9', color: '#64748b', border: 'none', borderRadius: '6px', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '4px' }}>
                                <IconTarget size={12} color="#64748b" /> Generate Topic Lines
                            </button>
                        </div>

                        {/* Template & Tone */}
                        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px', marginBottom: '10px' }}>
                            <div>
                                <label style={{ fontWeight: '600', color: primaryColor, fontSize: '10px', display: 'flex', alignItems: 'center', gap: '4px', marginBottom: '4px' }}>
                                    <IconFileText size={10} color={primaryColor} /> Template
                                </label>
                                <select defaultValue="Lead Magnet" style={{ ...inputStyle, cursor: 'pointer', fontSize: '11px' }}>
                                    <option>Lead Magnet</option>
                                    <option>Custom</option>
                                    <option>Announcement</option>
                                    <option>Insight</option>
                                    <option>Question</option>
                                    <option>Achievement</option>
                                    <option>Pro Tip</option>
                                    <option>Story</option>
                                    <option>Poll</option>
                                    <option>Motivation</option>
                                    <option>How-To Guide</option>
                                </select>
                            </div>
                            <div>
                                <label style={{ fontWeight: '600', color: primaryColor, fontSize: '10px', display: 'flex', alignItems: 'center', gap: '4px', marginBottom: '4px' }}>
                                    <IconSliders size={10} color={primaryColor} /> Tone
                                </label>
                                <select defaultValue="Professional" style={{ ...inputStyle, cursor: 'pointer', fontSize: '11px' }}>
                                    <option>Professional</option>
                                    <option>Casual</option>
                                    <option>Enthusiastic</option>
                                    <option>Thoughtful</option>
                                </select>
                            </div>
                        </div>

                        {/* Post Length */}
                        <div style={{ marginBottom: '10px' }}>
                            <label style={{ fontWeight: '600', color: primaryColor, fontSize: '10px', display: 'flex', alignItems: 'center', gap: '4px', marginBottom: '4px' }}>
                                <IconSliders size={10} color={primaryColor} /> Post Length
                            </label>
                            <select defaultValue="Long (1500 chars)" style={{ ...inputStyle, cursor: 'pointer', fontSize: '11px' }}>
                                <option>Short (220 chars)</option>
                                <option>Medium (750 chars)</option>
                                <option>Long (1500 chars)</option>
                                <option>Extra Long (3000 chars)</option>
                            </select>
                        </div>

                        {/* Hashtags & Emojis */}
                        <div style={{ display: 'flex', gap: '12px', padding: '8px', background: 'white', borderRadius: '6px', border: '2px solid #e0e0e0', marginBottom: '12px' }}>
                            <label style={{ display: 'flex', alignItems: 'center', gap: '5px', cursor: 'pointer', fontSize: '11px' }}>
                                <input type="checkbox" defaultChecked style={{ width: '14px', height: '14px', accentColor: primaryColor }} />
                                <span style={{ color: primaryColor, fontWeight: '500', display: 'flex', alignItems: 'center', gap: '3px' }}><IconHash size={12} color={primaryColor} /> Hashtags</span>
                            </label>
                            <label style={{ display: 'flex', alignItems: 'center', gap: '5px', cursor: 'pointer', fontSize: '11px' }}>
                                <input type="checkbox" defaultChecked style={{ width: '14px', height: '14px', accentColor: primaryColor }} />
                                <span style={{ color: primaryColor, fontWeight: '500', display: 'flex', alignItems: 'center', gap: '3px' }}><IconSmile size={12} color="#F59E0B" /> Emojis</span>
                            </label>
                        </div>

                        {/* Generate & Analyze Buttons */}
                        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px' }}>
                            <button style={{ padding: '10px', fontSize: '12px', fontWeight: '600', background: primaryGradient, color: 'white', border: 'none', borderRadius: '8px', cursor: 'pointer', boxShadow: '0 4px 10px rgba(105, 63, 233, 0.3)', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '4px' }}>
                                <IconSparkles size={14} color="white" /> Generate AI
                            </button>
                            <button style={{ padding: '10px', fontSize: '12px', fontWeight: '600', border: `2px solid ${primaryColor}`, background: 'white', color: primaryColor, borderRadius: '8px', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '4px' }}>
                                <IconChart size={14} color={primaryColor} /> Analyze
                            </button>
                        </div>
                    </div>

                    {/* Schedule Post Card */}
                    <div style={{ ...cardStyle, border: '2px solid #e0e0e0' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '10px' }}>
                            <IconClock size={14} color={primaryColor} />
                            <h4 style={{ margin: 0, color: primaryColor, fontSize: '12px' }}>Schedule Post</h4>
                        </div>
                        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px', marginBottom: '8px' }}>
                            <div>
                                <label style={{ fontSize: '10px', color: '#666', display: 'flex', alignItems: 'center', gap: '3px', marginBottom: '3px' }}>
                                    <IconCalendar size={10} color="#666" /> Date
                                </label>
                                <input type="date" defaultValue="2024-12-15" style={{ ...inputStyle, fontSize: '11px' }} />
                            </div>
                            <div>
                                <label style={{ fontSize: '10px', color: '#666', display: 'flex', alignItems: 'center', gap: '3px', marginBottom: '3px' }}>
                                    <IconClock size={10} color="#666" /> Time
                                </label>
                                <input type="time" defaultValue="09:00" style={{ ...inputStyle, fontSize: '11px' }} />
                            </div>
                        </div>
                        <button style={{ width: '100%', padding: '8px', fontSize: '11px', background: primaryColor, color: 'white', border: 'none', borderRadius: '6px', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '4px' }}>
                            <IconCalendar size={12} color="white" /> Schedule Post
                        </button>
                    </div>
                </div>

                {/* RIGHT COLUMN: Post Content */}
                <div style={{ ...cardStyle, display: 'flex', flexDirection: 'column', minHeight: '380px' }}>
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '10px', paddingBottom: '10px', borderBottom: '2px solid #e0e0e0' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                            <IconEdit size={16} color={primaryColor} />
                            <h4 style={{ margin: 0, color: primaryColor, fontSize: '13px' }}>Post Content</h4>
                        </div>
                        <div style={{ fontSize: '10px', color: '#999' }}>1,247 / 3,000 characters</div>
                    </div>
                    
                    <textarea 
                        defaultValue={`🚀 5 LinkedIn Growth Strategies That Actually Work in 2024

I've helped 500+ professionals grow their LinkedIn presence. Here's what I've learned:

1️⃣ Consistency beats perfection
Post 3-5 times per week. Your first posts won't be perfect, and that's okay.

2️⃣ Engage before you post
Spend 15 minutes commenting on others' posts before publishing yours.

3️⃣ Hook them in the first line
You have 2 seconds to capture attention. Make every word count.

4️⃣ Tell stories, not lectures
People remember stories 22x more than facts alone.

5️⃣ End with a question
Invite conversation. The algorithm rewards engagement.

Which strategy will you try first? 👇

#LinkedInGrowth #PersonalBranding #CareerDevelopment`}
                        style={{ flex: 1, minHeight: '280px', width: '100%', padding: '12px', border: '2px solid #e0e0e0', borderRadius: '8px', fontSize: '12px', lineHeight: '1.6', resize: 'vertical', fontFamily: '-apple-system, BlinkMacSystemFont, Segoe UI, Roboto, sans-serif' }}
                    ></textarea>
                    
                    {/* Action Buttons */}
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px', marginTop: '12px' }}>
                        <button style={{ padding: '12px', fontSize: '12px', fontWeight: '600', background: 'linear-gradient(135deg, #0a66c2 0%, #004182 100%)', color: 'white', border: 'none', borderRadius: '8px', cursor: 'pointer', boxShadow: '0 4px 12px rgba(10, 102, 194, 0.3)', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '4px' }}>
                            <IconSend size={14} color="white" /> Post to LinkedIn
                        </button>
                        <button style={{ padding: '12px', fontSize: '12px', fontWeight: '600', border: `2px solid ${primaryColor}`, background: 'white', color: primaryColor, borderRadius: '8px', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '4px' }}>
                            <IconSave size={14} color={primaryColor} /> Save Draft
                        </button>
                    </div>
                </div>
            </div>

            {/* Bottom Section: Tabs for Drafts & Calendar */}
            <div style={cardStyle}>
                <div style={{ display: 'flex', borderBottom: '2px solid #e0e0e0', marginBottom: '12px' }}>
                    <button style={{ flex: 1, padding: '10px', border: 'none', background: 'none', fontSize: '12px', fontWeight: '600', color: primaryColor, cursor: 'pointer', borderBottom: `3px solid ${primaryColor}`, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '4px' }}>
                        <IconSave size={12} color={primaryColor} /> Saved Drafts (3)
                    </button>
                    <button style={{ flex: 1, padding: '10px', border: 'none', background: 'none', fontSize: '12px', fontWeight: '600', color: '#999', cursor: 'pointer', borderBottom: '3px solid transparent', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '4px' }}>
                        <IconCalendar size={12} color="#999" /> Content Calendar
                    </button>
                </div>
                {/* Draft items */}
                <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                    {[
                        { title: 'AI in Marketing: A Complete Guide', date: 'Dec 3, 2024', chars: 1892 },
                        { title: 'Top 10 Remote Work Tips', date: 'Dec 2, 2024', chars: 1456 },
                        { title: 'Building a Personal Brand', date: 'Nov 30, 2024', chars: 2103 }
                    ].map((draft, i) => (
                        <div key={i} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px', background: '#f8f9fa', borderRadius: '8px' }}>
                            <div>
                                <div style={{ fontSize: '12px', fontWeight: '600', color: '#333' }}>{draft.title}</div>
                                <div style={{ fontSize: '10px', color: '#666' }}>{draft.date} • {draft.chars} chars</div>
                            </div>
                            <button style={{ padding: '6px 12px', background: primaryColor, color: 'white', border: 'none', borderRadius: '6px', fontSize: '10px', cursor: 'pointer' }}>Load</button>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
}
