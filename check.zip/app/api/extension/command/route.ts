import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { verifyToken, extractToken } from '@/lib/auth';
import jwt from 'jsonwebtoken';

export const dynamic = 'force-dynamic';
export const maxDuration = 60; // 60 seconds

// Helper to handle JWT errors gracefully
function handleAuthError(error: any) {
  if (error.name === 'TokenExpiredError') {
    return { error: 'token_expired', message: 'Authentication token has expired. Please re-authenticate.', shouldReauth: true };
  }
  if (error.name === 'JsonWebTokenError') {
    return { error: 'invalid_token', message: 'Invalid authentication token.', shouldReauth: true };
  }
  return { error: 'auth_failed', message: error.message || 'Authentication failed.', shouldReauth: false };
}

// POST - Queue a command for the extension (e.g., post to LinkedIn)
export async function POST(request: NextRequest) {
  try {
    const token = extractToken(request.headers.get('authorization'));
    if (!token) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }
    
    // Check for internal API key (for cron jobs) or JWT token
    const INTERNAL_API_KEY = process.env.INTERNAL_API_KEY || 'internal-api-key';
    let userId: string | null = null;
    let targetUserId: string | null = null;
    
    if (token === INTERNAL_API_KEY) {
      // Internal API call from cron - get targetUserId from body
      const body = await request.json();
      targetUserId = body.targetUserId || null;
      if (!targetUserId) {
        return NextResponse.json({ success: false, error: 'targetUserId required for internal API calls' }, { status: 400 });
      }
      userId = targetUserId;
      
      // Re-parse body for command/data since we consumed it
      const { command, data, targetUserId: _t } = body;
      
      if (!command) {
        return NextResponse.json({ success: false, error: 'Command is required' }, { status: 400 });
      }

      // Store the command for the extension to pick up
      const activity = await prisma.activity.create({
        data: {
          userId: userId,
          type: `extension_command_${command}`,
          metadata: JSON.stringify({
            command,
            data,
            status: 'pending',
            createdAt: new Date().toISOString(),
          }),
        },
      });

      return NextResponse.json({ success: true, commandId: activity.id, command });
    }
    
    // Regular JWT auth flow
    let payload;
    try {
      payload = verifyToken(token);
    } catch (authError: any) {
      const authInfo = handleAuthError(authError);
      return NextResponse.json({ 
        success: false, 
        error: authInfo.error, 
        message: authInfo.message,
        shouldReauth: authInfo.shouldReauth 
      }, { status: 401 });
    }

    const { command, data } = await request.json();

    if (!command) {
      return NextResponse.json({ success: false, error: 'Command is required' }, { status: 400 });
    }

    // Store the command for the extension to pick up
    // We use Activity model as a lightweight command queue
    const activity = await prisma.activity.create({
      data: {
        userId: payload.userId,
        type: `extension_command_${command}`,
        metadata: JSON.stringify({
          command,
          data,
          status: 'pending',
          createdAt: new Date().toISOString(),
        }),
      },
    });

    return NextResponse.json({ success: true, commandId: activity.id, command });
  } catch (error: any) {
    console.error('Extension command error:', error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}

// GET - Extension polls for pending commands (queue: one at a time)
export async function GET(request: NextRequest) {
  try {
    const token = extractToken(request.headers.get('authorization'));
    if (!token) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }
    let payload;
    try {
      payload = verifyToken(token);
    } catch (authError: any) {
      const authInfo = handleAuthError(authError);
      // Debug: log the actual error and token prefix
      console.error('Get extension commands error:', authInfo.message, 'Token prefix:', token.substring(0, 20) + '...');
      return NextResponse.json({ 
        success: false, 
        error: authInfo.error, 
        message: authInfo.message,
        shouldReauth: authInfo.shouldReauth 
      }, { status: 401 });
    }

    // Get recent commands from last 24 hours
    const oneDayAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);
    const commands = await prisma.activity.findMany({
      where: {
        userId: payload.userId,
        type: { startsWith: 'extension_command_' },
        timestamp: { gte: oneDayAgo },
      },
      orderBy: { timestamp: 'asc' }, // oldest first (FIFO queue)
      take: 50,
    });

    const parsed = commands.map((c: any) => {
      const meta = typeof c.metadata === 'string' ? JSON.parse(c.metadata) : c.metadata;
      return { id: c.id, ...meta, createdAt: c.timestamp };
    });

    // Check if any command is currently in_progress
    const inProgressCommand = parsed.find((c: any) => c.status === 'in_progress');

    // Auto-expire stuck in_progress commands (older than 30 minutes)
    if (inProgressCommand) {
      const cmdAge = Date.now() - new Date(inProgressCommand.createdAt).getTime();
      if (cmdAge > 30 * 60 * 1000) {
        // Mark as failed (stuck)
        try {
          const activity = await prisma.activity.findFirst({ where: { id: inProgressCommand.id } });
          if (activity) {
            const meta = typeof activity.metadata === 'string' ? JSON.parse(activity.metadata as string) : activity.metadata;
            meta.status = 'failed';
            meta.error = 'Timed out (stuck for 30+ minutes)';
            meta.completedAt = new Date().toISOString();
            await prisma.activity.update({ where: { id: inProgressCommand.id }, data: { metadata: JSON.stringify(meta) } });
          }
        } catch (e) {}
        // Fall through to send next pending command
      } else {
        // A task is currently running — don't send any more
        return NextResponse.json({ success: true, commands: [], queueStatus: 'busy', currentTask: inProgressCommand.command });
      }
    }

    // No task in progress — send only the NEXT pending/queued command (FIFO)
    const pendingCommands = parsed.filter((c: any) => c.status === 'pending' || c.status === 'queued');
    const nextCommand = pendingCommands.length > 0 ? [pendingCommands[0]] : [];

    // Debug logging
    if (parsed.length > 0) {
      console.log('📋 GET commands: total=', parsed.length, 'pending=', pendingCommands.length, 'statuses=', parsed.map((c: any) => `${c.command}:${c.status}`).join(','));
    }

    return NextResponse.json({
      success: true,
      commands: nextCommand,
      queueStatus: nextCommand.length > 0 ? 'dispatching' : 'idle',
      pendingCount: pendingCommands.length,
    });
  } catch (error: any) {
    console.error('Get extension commands error:', error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}

// PUT - Mark a command as completed
export async function PUT(request: NextRequest) {
  try {
    const token = extractToken(request.headers.get('authorization'));
    if (!token) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }
    const payload = verifyToken(token);

    const { commandId, status, data } = await request.json();

    if (!commandId) {
      return NextResponse.json({ success: false, error: 'Command ID required' }, { status: 400 });
    }

    const activity = await prisma.activity.findFirst({
      where: { id: commandId, userId: payload.userId },
    });

    if (!activity) {
      console.error('Command not found:', commandId, 'userId:', payload.userId);
      return NextResponse.json({ success: false, error: 'Command not found' }, { status: 404 });
    }

    const meta = typeof activity.metadata === 'string' ? JSON.parse(activity.metadata as string) : activity.metadata;
    const previousStatus = meta.status;
    meta.status = status || 'completed';
    if (data) meta.data = data;
    if (status === 'completed' || status === 'failed' || status === 'cancelled') meta.completedAt = new Date().toISOString();

    console.log('📝 Updating command:', commandId, 'from', previousStatus, 'to', meta.status);

    await prisma.activity.update({
      where: { id: commandId },
      data: { metadata: JSON.stringify(meta) },
    });

    console.log('✅ Command updated successfully:', commandId);
    return NextResponse.json({ success: true });
  } catch (error: any) {
    console.error('Update extension command error:', error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
