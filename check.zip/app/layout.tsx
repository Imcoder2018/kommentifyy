import type { Metadata } from 'next'
import { SpeedInsights } from '@vercel/speed-insights/next'
import { Analytics } from '@vercel/analytics/next'
import { ClerkProvider } from '@clerk/nextjs'
import I18nProvider from '@/lib/i18n/I18nProvider'

export const metadata: Metadata = {
  metadataBase: new URL('https://kommentify.com'),
  title: {
    default: 'Kommentify - LinkedIn Automation That Doesn\'t Get You Banned | AI Comments & Post Scheduler',
    template: '%s | Kommentify'
  },
  description: 'Kommentify is an AI-powered LinkedIn automation extension for smart commenting, intelligent networking, and lead tracking—all in a safe, browser-based solution. 500+ users trust us.',
  keywords: [
    'LinkedIn automation',
    'LinkedIn auto comment',
    'LinkedIn growth tool',
    'AI LinkedIn comments',
    'LinkedIn networking',
    'LinkedIn post scheduler',
    'LinkedIn engagement tool',
    'LinkedIn marketing automation',
    'grow LinkedIn followers',
    'LinkedIn lead generation'
  ],
  authors: [{ name: 'Kommentify' }],
  creator: 'Kommentify',
  publisher: 'Kommentify',
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
  openGraph: {
    type: 'website',
    locale: 'en_US',
    url: 'https://kommentify.com',
    siteName: 'Kommentify',
    title: 'AI LinkedIn Automation Extension for Growth & Leads | Kommentify',
    description: 'Kommentify is an AI-powered LinkedIn automation extension for smart commenting, intelligent networking, and lead tracking—all in a safe, browser-based solution.',
    images: [
      {
        url: '/og-image.png',
        width: 1200,
        height: 630,
        alt: 'Kommentify - LinkedIn Automation',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'AI LinkedIn Automation Extension for Growth & Leads | Kommentify',
    description: 'Kommentify is an AI-powered LinkedIn automation extension for smart commenting, intelligent networking, and lead tracking.',
    images: ['/og-image.png'],
    creator: '@kommentify',
  },
  verification: {
    google: 'your-google-verification-code', // Replace with actual code
  },
  alternates: {
    canonical: 'https://kommentify.com',
  },
  category: 'technology',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <ClerkProvider>
      <html lang="en">
        <head>
          {/* Google Analytics */}
          <script async src="https://www.googletagmanager.com/gtag/js?id=G-V19D160Y31"></script>
          <script dangerouslySetInnerHTML={{ __html: `
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());
            gtag('config', 'G-V19D160Y31');
          `}} />
          
          <link rel="icon" href="/favicon.png" type="image/png" />
          <link rel="apple-touch-icon" href="/favicon.png" />
          <link rel="manifest" href="/manifest.json" />
          
          {/* Meta Pixel Code */}
          <script dangerouslySetInnerHTML={{ __html: `!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,document,'script','https://connect.facebook.net/en_US/fbevents.js');fbq('init','1325317928900506');fbq('track','PageView');` }} />
          <noscript dangerouslySetInnerHTML={{ __html: `<img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=1325317928900506&ev=PageView&noscript=1" />` }} />
          <meta name="theme-color" content="#693fe9" />
          <meta name="apple-mobile-web-app-capable" content="yes" />
          <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
          
          {/* Structured Data - Product Schema */}
          <script
            type="application/ld+json"
            dangerouslySetInnerHTML={{
              __html: JSON.stringify({
                '@context': 'https://schema.org',
                '@type': 'SoftwareApplication',
                name: 'Kommentify',
                applicationCategory: 'BusinessApplication',
                operatingSystem: 'Chrome',
                description: 'AI-powered LinkedIn automation tool for auto-commenting, networking, and growth.',
                url: 'https://kommentify.com',
                author: {
                  '@type': 'Organization',
                  name: 'Kommentify',
                  url: 'https://kommentify.com'
                },
                offers: [
                  {
                    '@type': 'Offer',
                    name: 'Starter Plan',
                    price: '9',
                    priceCurrency: 'USD',
                    priceValidUntil: '2026-12-31',
                    availability: 'https://schema.org/InStock'
                  },
                  {
                    '@type': 'Offer',
                    name: 'Professional Plan',
                    price: '29',
                    priceCurrency: 'USD',
                    priceValidUntil: '2026-12-31',
                    availability: 'https://schema.org/InStock'
                  },
                  {
                    '@type': 'Offer',
                    name: 'Lifetime Deal',
                    price: '69',
                    priceCurrency: 'USD',
                    description: 'One-time payment, lifetime access',
                    availability: 'https://schema.org/LimitedAvailability'
                  }
                ],
                aggregateRating: {
                  '@type': 'AggregateRating',
                  ratingValue: '5.0',
                  ratingCount: '500',
                  bestRating: '5',
                  worstRating: '1'
                },
              }),
            }}
          />
          
          {/* Structured Data - Organization Schema */}
          <script
            type="application/ld+json"
            dangerouslySetInnerHTML={{
              __html: JSON.stringify({
                '@context': 'https://schema.org',
                '@type': 'Organization',
                name: 'Kommentify',
                url: 'https://kommentify.com',
                logo: 'https://kommentify.com/favicon.png',
                sameAs: [
                  'https://chromewebstore.google.com/detail/kommentify-linkedin-auto/laeckkpjacbodjglcnenggpdpehkacei'
                ],
                contactPoint: {
                  '@type': 'ContactPoint',
                  contactType: 'customer service',
                  url: 'https://kommentify.com/contact'
                }
              }),
            }}
          />
          
          <style>{`
            * {
              margin: 0;
              padding: 0;
              box-sizing: border-box;
            }
            html, body {
              margin: 0;
              padding: 0;
              overflow-x: hidden;
            }
          `}</style>
        </head>
        <body style={{ margin: 0, padding: 0 }}>
          <I18nProvider>
            {children}
          </I18nProvider>
          <SpeedInsights />
          <Analytics />
        </body>
      </html>
    </ClerkProvider>
  )
}
