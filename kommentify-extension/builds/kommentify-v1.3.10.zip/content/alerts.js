import { storage as e } from '../shared/storage/storage.js';
import { toast as i } from '../shared/utils/toaster.js';
import { sounds as A } from '../shared/utils/sounds.js';
import { StorageKey as e$1, SwitchState as a } from '../shared/storage/constants.js';

const r=new class{async outputAutomationAlertsIfNeeded(){const r=await e.getString(e$1.AutomationCompleteMessage);if(!r)return;i.success(r,"Auto-Pilot Complete");await e.getEnum(e$1.AutomationSoundState)===a.On&&A.success(),await e.remove(e$1.AutomationCompleteMessage);}};

export { r as alerts };
