import { feedActions as o$1 } from '../shared/dom/feedActions.js';
import { feedScraper as o } from '../shared/dom/feedScraper.js';
import { api as n } from '../shared/api/api.js';
import { DataAttribute as t, EngagementType as o$2 } from '../shared/storage/constants.js';
import { log as e } from '../shared/utils/logger.js';
import '../shared/dom/waitUntil.js';
import '../shared/dom/domium.js';
import '../shared/utils/appConfig.js';
import '../shared/storage/storage.js';

const i=new class{async create(i,n$1,m,d,g){try{e("log","Starting ReplyCreator...");const g=await o.getMentionElements(n$1);o$1.displaySpinner(n$1);const p=o.getPostAuthor(i),l=o.getPostText(i);if(!l)throw new Error("Failed to read post text.");const c=o.getCommentText(i);if(!c)throw new Error("Failed to read comment text.");const u=o.getCommentAuthorSeat(i),h=o.getCommentUrn(i);e("log","Scraping complete."),e("log","Calling API to generate reply...");const f=await n.generateReply(u,h,p,l,c,d.me,m);e("success","API returned generated text."),o$1.pasteReplyText(n$1,g,f);const w=await o.getSubmitButton(n$1);if(!w||w.hasAttribute(t.AlreadyRegistered))return;w.setAttribute(t.AlreadyRegistered,"true"),w.addEventListener("click",()=>{e("log","Submit button clicked. Logging engagement.");const e$1=i.hasAttribute(t.IsAutomation);if(n.engaged(u,h,o$2.Reply,e$1),!e$1){const e=h?`https://www.linkedin.com/feed/update/${h}`:window.location.href;n.peep(d.me,d.imageUrl,o$2.Reply,e);}}),e("success","ReplyCreator finished.");}finally{o$1.removeSpinner(n$1);}}};

export { i as replyCreator };
