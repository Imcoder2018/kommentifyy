import { PostAge as m } from '../storage/constants.js';

const s=new class{isTimeSymbolLessThanOrEqualPostAge(s,t){if(!s)return !1;const o={[m.NotSpecified]:()=>!0,[m.OneDay]:e=>/^(?:\d{1,2}[smh]|1d)\b/.test(e),[m.ThreeDays]:e=>/^(?:\d{1,2}[smh]|[1-3]d)\b/.test(e),[m.OneWeek]:e=>/^(?:\d{1,2}[smhd]|1w)\b/.test(e),[m.OneMonth]:e=>/^(?:\d{1,2}[smhdw]|1mo)\b/.test(e),[m.ThreeMonths]:e=>/^(?:\d{1,2}[smhdw]|[1-3]mo)\b/.test(e)}[t];return !!o&&o(s)}};

export { s as times };
