import { feedActions as o } from '../shared/dom/feedActions.js';
import { feedScraper as o$1 } from '../shared/dom/feedScraper.js';
import { api as n } from '../shared/api/api.js';
import { DataAttribute as t, EngagementType as o$2 } from '../shared/storage/constants.js';
import { log as e } from '../shared/utils/logger.js';
import '../shared/dom/waitUntil.js';
import '../shared/dom/domium.js';
import '../shared/utils/appConfig.js';
import '../shared/storage/storage.js';

const i=new class{async create(i,a,m,d,g){try{e("log","Starting CommentCreator..."),o.displaySpinner(a);const g=m.commentMentionPostAuthor?o$1.getPostAuthor(i):null;let c=o$1.getPostText(i);const l=o$1.getPostInnerArticleUrlIfExist(i);if(l&&(c=await o$1.getArticleText(l)||c),!c)throw new Error("Failed to read post text.");const p=o$1.getPostAuthorSeat(i),u=o$1.getPostUrn(i);e("log","Scraping complete."),e("log","Calling API to generate comment...");const h=await n.generateComment(p,u,g,c,m);e("success","API returned generated text."),o.pasteCommentText(a,h);const f=await o$1.getSubmitButton(a);if(!f||f.hasAttribute(t.AlreadyRegistered))return;f.setAttribute(t.AlreadyRegistered,"true"),f.addEventListener("click",()=>{e("log","Submit button clicked. Logging engagement.");const t$1=i.hasAttribute(t.IsAutomation);if(n.engaged(p,u,o$2.Comment,t$1),!t$1){const t=u?`https://www.linkedin.com/feed/update/${u}`:window.location.href;n.peep(d.me,d.imageUrl,o$2.Comment,t);}}),e("success","CommentCreator finished.");}finally{o.removeSpinner(a);}}};

export { i as commentCreator };
