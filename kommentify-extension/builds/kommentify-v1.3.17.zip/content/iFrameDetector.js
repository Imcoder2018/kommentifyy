import { clicker as r$1 } from './clicker.js';
import { DataAttribute as t } from '../shared/storage/constants.js';
import '../shared/dom/waitUntil.js';
import '../shared/api/api.js';
import '../shared/dom/feedScraper.js';
import '../shared/utils/logger.js';
import '../shared/dom/feedActions.js';
import '../shared/dom/domium.js';
import '../shared/utils/appConfig.js';
import '../shared/storage/storage.js';

const r=new class{constructor(){this.DETECTION_INTERVAL=2e3;}constantlyDetectAndRegisterClicks(){setInterval(()=>this.detectAndRegister(),this.DETECTION_INTERVAL);}detectAndRegister(){const r=document.querySelectorAll("iframe");for(const s of r)s.hasAttribute(t.AlreadyRegistered)||s.hasAttribute(t.DynamicHiddenIFrame)||(s.addEventListener("load",()=>{try{(s.contentDocument||s.contentWindow.document).body.addEventListener("click",r$1.click);}catch(t){}}),s.setAttribute(t.AlreadyRegistered,"true"));}};

export { r as iFrameDetector };
