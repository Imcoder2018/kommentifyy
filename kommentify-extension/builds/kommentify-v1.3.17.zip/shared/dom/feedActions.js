import { domActions as s } from './domium.js';
import { appConfig as e } from '../utils/appConfig.js';
import { DataAttribute as t } from '../storage/constants.js';

const o=new class{displaySpinner(t){const o=t.querySelector("[data-placeholder]");o&&(o.style.display="none"),t.innerHTML="";const r=s.createThumbnailSpinner(e.spinnerUrl);t.appendChild(r);}removeSpinner(e){const n=e.querySelector(`img[${t.DynamicSpinnerImage}]`);n&&n.parentElement.removeChild(n);}pasteCommentText(e,n){this.removeSpinner(e);const t=e.querySelector('div[contenteditable="true"]')||e;t.innerHTML="",t.focus();const o=`<p>${n.replace(/\n/g,"</p><p>")}</p>`;document.execCommand("insertHTML",!1,o),t.dispatchEvent(new Event("input",{bubbles:!0,cancelable:!0}));}pasteReplyText(e,n,t){const o=e.querySelector('div[contenteditable="true"]')||e;o.focus();let r="";if(n&&n.length>0)for(const e of n)r+=e.outerHTML+"&nbsp;";const p=`<p>${r}${t.replace(/\n/g,"</p><p>")}</p>`;document.execCommand("insertHTML",!1,p),o.dispatchEvent(new Event("input",{bubbles:!0,cancelable:!0}));}};

export { o as feedActions };
