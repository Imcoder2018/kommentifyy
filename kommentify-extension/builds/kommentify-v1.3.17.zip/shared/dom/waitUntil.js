const e=new class{constructor(){this.TIMEOUT=5e3,this.DELAY=100;}delay(e,t=this.TIMEOUT){return new Promise(l=>{let r=0;const s=setInterval(()=>{e()&&(clearInterval(s),l(!0)),r+=this.DELAY,r>t&&(clearInterval(s),l(!1));},this.DELAY);})}async elementAppears(e,t=this.TIMEOUT,l=document){let r=null;return await this.delay(()=>(r=l.querySelector(e),null!==r),t),r}};

export { e as waitUntil };
