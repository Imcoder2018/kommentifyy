const o=(o,t)=>Math.floor(Math.random()*(t-o+1))+o,t=o=>new Promise(t=>setTimeout(t,o)),a=async(a,e)=>{const n=o(a,e);await t(n);};

export { t as delay, o as random, a as randomDelay };
