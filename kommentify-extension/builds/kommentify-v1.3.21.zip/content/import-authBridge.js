!function(){const t=JSON.parse('"content/authBridge.js"');import(chrome.runtime.getURL(t));}();
