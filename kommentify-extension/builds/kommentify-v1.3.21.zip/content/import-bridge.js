!function(){const t=JSON.parse('"content/bridge.js"');import(chrome.runtime.getURL(t));}();
