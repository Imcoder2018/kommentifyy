let e=!1,t=0;async function c(){const c=Date.now();if(c-t<1e3)return e;t=c;try{const t=await chrome.storage.local.get(["bulkProcessingActive","peopleSearchActive"]);return e=t.bulkProcessingActive||t.peopleSearchActive||!1,e}catch(e){return !1}}async function n(e,t="operation"){return await c()?null:await e()}function r(){t=0;}

export { c as isAutomationRunning, r as refreshAutomationState, n as runIfNotAutomating };
