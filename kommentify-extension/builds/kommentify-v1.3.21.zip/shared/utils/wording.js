function n(n){return 1===n?"":"s"}

export { n as s };
