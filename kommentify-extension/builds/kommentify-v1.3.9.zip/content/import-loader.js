!function(){const t=JSON.parse('"content/loader.js"');import(chrome.runtime.getURL(t));}();
