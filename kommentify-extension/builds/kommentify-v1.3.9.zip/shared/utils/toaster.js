const i=new class{constructor(){void 0!==window.iziToast&&window.iziToast.settings({position:"topRight",timeout:5e3,progressBar:!0,close:!0,animateInside:!1,transitionIn:"fadeInLeft",transitionOut:"fadeOutRight"});}_show(i,s,o=""){void 0!==window.iziToast&&window.iziToast[i]({title:o,message:s});}success=(i,s="Success")=>this._show("success",i,s);error=(i,s="Error")=>this._show("error",i,s);warning=(i,s="Warning")=>this._show("warning",i,s);info=(i,s="Info")=>this._show("info",i,s)};

export { i as toast };
