import { featureChecker } from '../../shared/utils/featureChecker.js';
import { featureChecker as featureChecker$1 } from '../../shared/utils/featureChecker.js';
import { sendMessageSafe } from '../../shared/utils/messageHandler.js';

const API_CONFIG = {
    BASE_URL: 'https://kommentify.com'
};

// Global Error Handling
window.onerror = function (msg, url, line, col, error) {
    console.error('Global Error:', { msg, url, line, col, error });
    // Try to show error in UI if possible
    const overlay = document.getElementById('loading-overlay');
    if (overlay) {
        overlay.innerHTML = `
            <div style="text-align: center; padding: 20px; color: #dc3545;">
                <h3>Something went wrong</h3>
                <p>${msg}</p>
                <button onclick="location.reload()" style="margin-top: 10px; padding: 8px 16px; background: #693fe9; color: white; border: none; borderRadius: 4px; cursor: pointer;">Reload</button>
            </div>
        `;
    }
    return false;
};

window.addEventListener('unhandledrejection', function (event) {
    console.error('Unhandled Promise Rejection:', event.reason);
});

// Show notification to user
function showNotification(message, type = 'info', duration = 3000) {
    // Create notification element if it doesn't exist
    let notification = document.getElementById('extension-notification');
    if (!notification) {
        notification = document.createElement('div');
        notification.id = 'extension-notification';
        notification.style.cssText = `
            position: fixed;
            top: 10px;
            right: 10px;
            padding: 12px 16px;
            border-radius: 8px;
            color: white;
            font-weight: 500;
            z-index: 10000;
            max-width: 300px;
            word-wrap: break-word;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            transform: translateX(100%);
            transition: transform 0.3s ease;
        `;
        document.body.appendChild(notification);
    }

    // Set message and type-specific styling
    notification.textContent = message;

    const colors = {
        success: '#28a745',
        error: '#dc3545',
        warning: '#ffc107',
        info: '#007bff'
    };

    notification.style.backgroundColor = colors[type] || colors.info;

    // Show notification
    notification.style.transform = 'translateX(0)';

    // Hide after duration
    setTimeout(() => {
        notification.style.transform = 'translateX(100%)';
    }, duration);
}

// Alias for showNotification to maintain compatibility
function showToast(message, type = 'info', duration = 3000) {
    showNotification(message, type, duration);
}

// Database Status Check Function
async function checkDatabaseStatus() {
    try {
        const storage = await chrome.storage.local.get(['apiBaseUrl']);
        const apiUrl = storage.apiBaseUrl || API_CONFIG.BASE_URL;

        const response = await fetch(`${apiUrl}/api/database/status`, {
            method: 'GET',
            headers: { 'Content-Type': 'application/json' }
        });

        const data = await response.json();

        if (data.success && data.status === 'connected') {
            console.log('✅ Database Status: Connected (PostgreSQL)');
            console.log('📊 Database Stats:', data.stats);
        } else {
            console.warn('⚠️ Database Status: Issues detected');
            showDatabaseWarning(data.error || 'Database connection issues');
        }

    } catch (error) {
        console.error('❌ Database Status Check Failed:', error);
        if (error.message.includes('Error code 14')) {
            showDatabaseWarning('SQLite database detected - migration to PostgreSQL required');
        }
    }
}

function showDatabaseWarning(message) {
    const banner = document.createElement('div');
    banner.style.cssText = `
        position: fixed; top: 0; left: 0; right: 0; 
        background: #ffc107; color: #000; padding: 8px; 
        text-align: center; font-size: 11px; z-index: 10000;
        border-bottom: 1px solid #ffb300;
    `;
    banner.innerHTML = `⚠️ Database: ${message}`;
    document.body.insertBefore(banner, document.body.firstChild);
    setTimeout(() => banner.remove(), 8000);
}

// Global state object
const state = {
    ui: {},
    preferences: {},
    account: {},
    statistics: {},
    dailyLimits: {},
    isAuthenticated: false,
    userData: {}
};

// Global elements object
const elements = {};

// ===== AUTHENTICATION & ACCOUNT MANAGEMENT =====

// Validate JWT token - WITH 15-MINUTE CACHING
async function validateJWTToken(token) {
    if (!token) {
        console.log('No token provided');
        return false;
    }

    const parts = token.split('.');
    if (parts.length !== 3) {
        console.log('Invalid token format');
        return false;
    }

    // Check cached validation first (15 minute cache)
    const VALIDATION_CACHE_DURATION = 15 * 60 * 1000; // 15 minutes
    const { tokenValidationCache, tokenValidationTimestamp } = await chrome.storage.local.get([
        'tokenValidationCache',
        'tokenValidationTimestamp'
    ]);
    
    if (tokenValidationCache && tokenValidationTimestamp) {
        const cacheAge = Date.now() - tokenValidationTimestamp;
        if (cacheAge < VALIDATION_CACHE_DURATION) {
            console.log(`⚡ Using cached token validation (age: ${Math.round(cacheAge / 1000)}s)`);
            return tokenValidationCache.isValid;
        } else {
            console.log(`⏰ Token validation cache expired (age: ${Math.round(cacheAge / 1000)}s)`);
        }
    }

    // Get API base URL from storage
    const { apiBaseUrl } = await chrome.storage.local.get('apiBaseUrl');
    const apiUrl = apiBaseUrl || API_CONFIG.BASE_URL;

    console.log('Validating token with backend...');

    try {
        const response = await fetch(`${apiUrl}/api/auth/validate`, {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
            }
        });

        const data = await response.json();

        if (data.success) {
            console.log('Token validated successfully by backend');
            // Cache the validation result
            await chrome.storage.local.set({
                tokenValidationCache: { isValid: true },
                tokenValidationTimestamp: Date.now()
            });
            console.log('💾 Cached token validation for 15 minutes');
            return true;
        } else {
            console.log('Token validation failed:', data.error);
            await chrome.storage.local.remove(['authToken', 'userData', 'refreshToken', 'tokenValidationCache', 'tokenValidationTimestamp']);
            return false;
        }
    } catch (apiError) {
        console.error('Backend validation failed:', apiError);
        // If backend is unavailable, do basic format validation only
        try {
            const payload = JSON.parse(atob(parts[1]));
            const now = Math.floor(Date.now() / 1000);

            if (payload.exp && payload.exp < now) {
                console.log('Token expired');
                await chrome.storage.local.remove(['authToken', 'userData', 'refreshToken', 'tokenValidationCache', 'tokenValidationTimestamp']);
                return false;
            }

            console.log('Backend unavailable, using basic validation');
            // Cache this as well
            await chrome.storage.local.set({
                tokenValidationCache: { isValid: true },
                tokenValidationTimestamp: Date.now()
            });
            return true;
        } catch (decodeError) {
            console.error('Token decode error:', decodeError);
            return false;
        }
    }
}

// Show login screen for unauthenticated users
function showLoginScreen() {
    document.body.innerHTML = `
        <div style="
            min-height: 600px;
            background: linear-gradient(135deg, #693fe9 0%, #1a2340 100%);
            color: white;
            padding: 20px;
        ">
            <div style="max-width: 400px; margin: 0 auto;">
                <div style="text-align: center; margin-bottom: 30px;">
                    <h1 style="font-size: 28px; margin-bottom: 10px;">🚀 Kommentify</h1>
                    <p style="opacity: 0.9; font-size: 14px;">LinkedIn Automation & AI Content</p>
                </div>
                
                <div style="background: white; border-radius: 15px; padding: 30px; color: #333;">
                    <!-- Status Messages -->
                    <div id="auth-status" style="
                        background: #f8f9fa;
                        color: #666;
                        padding: 12px;
                        border-radius: 8px;
                        margin-bottom: 20px;
                        font-size: 14px;
                        text-align: center;
                        display: none;
                    "></div>
                    
                    <div style="text-align: center; margin-bottom: 25px;">
                        <div style="font-size: 50px; margin-bottom: 15px;">🔐</div>
                        <h2 style="font-size: 20px; margin-bottom: 10px; color: #333;">Welcome Back!</h2>
                        <p style="color: #666; font-size: 14px; line-height: 1.5;">
                            Click below to sign in or create an account using our secure authentication.
                        </p>
                    </div>
                    
                    <!-- Primary Login Button -->
                    <button id="clerk-login-btn" style="
                        width: 100%;
                        padding: 16px;
                        background: #693fe9;
                        color: white;
                        border: none;
                        border-radius: 10px;
                        font-size: 16px;
                        font-weight: 600;
                        cursor: pointer;
                        transition: all 0.3s;
                        margin-bottom: 15px;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        gap: 10px;
                    ">
                        <span>🚀</span> Sign In / Sign Up
                    </button>
                    
                    <p style="text-align: center; color: #999; font-size: 12px; margin-bottom: 20px;">
                        Opens in a new tab for secure authentication
                    </p>
                    
                </div>
                
                <div style="text-align: center; margin-top: 20px; font-size: 12px; opacity: 0.8;">
                    <p>✅ Automated Engagement • ✅ AI Content • ✅ Smart Scheduling</p>
                </div>
            </div>
        </div>
    `;

    // Add event listeners
    setupLoginScreenListeners();
}

// Setup event listeners for login screen
function setupLoginScreenListeners() {
    // Clerk login button - opens login page in new tab
    document.getElementById('clerk-login-btn').addEventListener('click', handleClerkLogin);
}

// Handle Clerk login - opens sign-in page in new tab and polls for auth token
async function handleClerkLogin() {
    const clerkBtn = document.getElementById('clerk-login-btn');
    const authStatus = document.getElementById('auth-status');
    
    try {
        // Get API base URL
        const storage = await chrome.storage.local.get(['apiBaseUrl']);
        let apiUrl = storage.apiBaseUrl || API_CONFIG.BASE_URL;
        
        // Allow localhost for development testing
        if (!apiUrl) {
            apiUrl = API_CONFIG.BASE_URL;
        }
        
        // Show loading state
        clerkBtn.disabled = true;
        clerkBtn.innerHTML = '<span>⏳</span> Opening login...';
        
        // Open extension-auth page directly (it will redirect to sign-in if needed)
        const authUrl = `${apiUrl}/extension-auth`;
        console.log('Opening extension auth URL:', authUrl);
        
        const tab = await chrome.tabs.create({ url: authUrl, active: true });
        
        // Show status message
        if (authStatus) {
            authStatus.style.display = 'block';
            authStatus.style.background = '#e8f4fd';
            authStatus.style.color = '#0066cc';
            authStatus.innerHTML = '⏳ Waiting for you to sign in...<br><small>This popup will refresh automatically</small>';
        }
        
        // Poll chrome.storage for auth token (set by content script on extension-auth page)
        let pollCount = 0;
        const maxPolls = 150; // 5 minutes (2 second interval)
        
        const checkAuthInterval = setInterval(async () => {
            pollCount++;
            
            try {
                // Check if auth token is now in storage (set by authBridge content script)
                const authStorage = await chrome.storage.local.get(['authToken', 'userData']);
                
                if (authStorage.authToken) {
                    console.log('✅ Auth token found in storage! User logged in.');
                    clearInterval(checkAuthInterval);
                    
                    // Try to close the login tab
                    try {
                        await chrome.tabs.remove(tab.id);
                    } catch (e) {
                        // Tab might already be closed
                    }
                    
                    // Reload the popup
                    location.reload();
                    return;
                }
            } catch (storageError) {
                console.log('Checking storage for auth...', pollCount);
            }
            
            // Check if tab was closed
            try {
                await chrome.tabs.get(tab.id);
            } catch (e) {
                // Tab was closed, stop polling
                console.log('Login tab closed by user');
                clearInterval(checkAuthInterval);
                
                clerkBtn.disabled = false;
                clerkBtn.innerHTML = '<span>🚀</span> Sign In / Sign Up';
                
                if (authStatus) {
                    authStatus.style.display = 'none';
                }
                return;
            }
            
            // Update status animation
            if (pollCount % 3 === 0 && authStatus) {
                const dots = '.'.repeat((pollCount % 3) + 1);
                authStatus.innerHTML = `⏳ Waiting for sign in${dots}<br><small>Complete sign-in in the opened tab</small>`;
            }
            
            // Timeout after max polls
            if (pollCount >= maxPolls) {
                console.log('Login check timeout');
                clearInterval(checkAuthInterval);
                
                clerkBtn.disabled = false;
                clerkBtn.innerHTML = '<span>🚀</span> Sign In / Sign Up';
                
                if (authStatus) {
                    authStatus.style.background = '#fff3cd';
                    authStatus.style.color = '#856404';
                    authStatus.innerHTML = '⚠️ Login timed out. Please try again.';
                }
            }
        }, 2000); // Poll every 2 seconds
        
    } catch (error) {
        console.error('Clerk login error:', error);
        
        clerkBtn.disabled = false;
        clerkBtn.innerHTML = '<span>🚀</span> Sign In / Sign Up';
        
        if (authStatus) {
            authStatus.style.display = 'block';
            authStatus.style.background = '#f8d7da';
            authStatus.style.color = '#721c24';
            authStatus.textContent = '❌ Failed to open login page. Please try again.';
        }
    }
}

// Update plan features display in Settings tab
function updateFeaturesDisplay(plan) {
    if (!plan) return;
    
    const featuresIncluded = document.getElementById('features-included');
    const featuresNotIncluded = document.getElementById('features-not-included');
    
    if (!featuresIncluded || !featuresNotIncluded) return;
    
    const allFeatures = [
        { name: 'General Automation', key: 'allowAutomation' },
        { name: 'AI Comment Generation', key: 'allowAiCommentGeneration' },
        { name: 'AI Post Generation', key: 'allowAiPostGeneration' },
        { name: 'AI Topic Lines', key: 'allowAiTopicLines' },
        { name: 'Post Scheduling', key: 'allowPostScheduling' },
        { name: 'Automation Scheduling', key: 'allowAutomationScheduling' },
        { name: 'Networking Features', key: 'allowNetworking' },
        { name: 'Network Scheduling', key: 'allowNetworkScheduling' },
        { name: 'CSV Export', key: 'allowCsvExport' },
        { name: 'Import Profiles Auto Engagement', key: 'allowImportProfiles' },
    ];
    
    const included = allFeatures.filter(f => plan[f.key] !== false);
    const notIncluded = allFeatures.filter(f => plan[f.key] === false);
    
    // Display included features
    if (included.length > 0) {
        featuresIncluded.innerHTML = included.map(f => 
            `<div style="padding: 6px 0; border-bottom: 1px solid #f0f0f0;">
                <span style="color: #28a745; marginRight: 8px; fontWeight: bold;">✓</span>
                ${f.name}
            </div>`
        ).join('');
    } else {
        featuresIncluded.innerHTML = '<div style="padding: 8px; background: #f8f9fa; border-radius: 6px; color: #999;">No features available in this plan</div>';
    }
    
    // Display not included features
    if (notIncluded.length > 0) {
        featuresNotIncluded.innerHTML = notIncluded.map(f => 
            `<div style="padding: 6px 0; border-bottom: 1px solid #f0f0f0; color: #999;">
                <span style="color: #dc3545; marginRight: 8px; fontWeight: bold;">✗</span>
                ${f.name}
                <span style="fontSize: 10px; marginLeft: 8px; color: #ffc107; cursor: pointer;" onclick="document.getElementById('upgrade-plan-btn').click();">⬆️ Upgrade</span>
            </div>`
        ).join('');
    } else {
        featuresNotIncluded.innerHTML = '<div style="padding: 8px; background: #d4edda; border-radius: 6px; color: #28a745;">🎉 You have access to all features!</div>';
    }
}

// Update the authentication UI based on login status
async function updateAuthenticationUI() {
    console.log('=== UPDATE AUTHENTICATION UI CALLED ===');
    try {
        const storage = await chrome.storage.local.get(['authToken', 'userData', 'apiBaseUrl']);
        const isLoggedIn = !!storage.authToken;
        const userData = storage.userData || {};

        console.log('Authentication UI Update:');
        console.log('- Is Logged In:', isLoggedIn);
        console.log('- Has User Data:', !!userData);
        console.log('- User Data:', userData);
        console.log('- Token exists:', !!storage.authToken);

        // Get elements directly since the elements variable might not be available
        const accountStatus = document.getElementById('account-status');
        const accountPlan = document.getElementById('account-plan');
        const accountEmail = document.getElementById('account-email');
        const headerPlanName = document.getElementById('header-plan-name');
        const loginSection = document.getElementById('login-section');
        const logoutSection = document.getElementById('logout-section');
        const planLimitComments = document.getElementById('plan-limit-comments');
        const planLimitLikes = document.getElementById('plan-limit-likes');
        const planLimitShares = document.getElementById('plan-limit-shares');
        const planLimitFollows = document.getElementById('plan-limit-follows');
        const planLimitConnections = document.getElementById('plan-limit-connections');
        const planLimitAiPosts = document.getElementById('plan-limit-ai-posts');
        const planLimitAiComments = document.getElementById('plan-limit-ai-comments');
        const planLimitAiTopics = document.getElementById('plan-limit-ai-topics');

        // Update status display
        if (accountStatus) {
            accountStatus.textContent = isLoggedIn ? 'Logged In' : 'Not Logged In';
        }

        // Show/hide appropriate sections
        if (loginSection && logoutSection) {
            loginSection.style.display = isLoggedIn ? 'none' : 'block';
            logoutSection.style.display = isLoggedIn ? 'block' : 'none';
        }

        if (isLoggedIn) {
            // Check if we have cached user data (15 min cache)
            const USERDATA_CACHE_DURATION = 15 * 60 * 1000;
            const { userDataCache, userDataCacheTimestamp } = await chrome.storage.local.get([
                'userDataCache',
                'userDataCacheTimestamp'
            ]);
            
            let validateData = null;
            
            if (userDataCache && userDataCacheTimestamp) {
                const cacheAge = Date.now() - userDataCacheTimestamp;
                if (cacheAge < USERDATA_CACHE_DURATION) {
                    console.log(`⚡ Using cached user data (age: ${Math.round(cacheAge / 1000)}s)`);
                    validateData = userDataCache;
                }
            }
            
            // Fetch fresh user data only if cache miss/expired
            if (!validateData) {
                try {
                    const apiUrl = storage.apiBaseUrl || API_CONFIG.BASE_URL;
                    
                    console.log('Fetching fresh user data from backend...');
                    const validateResponse = await fetch(`${apiUrl}/api/auth/validate`, {
                        headers: {
                            'Authorization': `Bearer ${storage.authToken}`
                        }
                    });
                    
                    if (validateResponse.ok) {
                        validateData = await validateResponse.json();
                        console.log('📊 Validate API Response:', validateData);
                        
                        // Cache the result
                        await chrome.storage.local.set({
                            userDataCache: validateData,
                            userDataCacheTimestamp: Date.now()
                        });
                        console.log('💾 Cached user data for 15 minutes');
                    }
                } catch (error) {
                    console.error('Error fetching user data:', error);
                }
            }
            
            // Use validateData (from cache or fresh)
            if (validateData && validateData.success && validateData.user) {
                console.log('👤 User data:', validateData.user);
                console.log('📋 User plan:', validateData.user.plan);
                
                // Update stored userData with fresh data from backend
                await chrome.storage.local.set({
                    userData: validateData.user
                });
                console.log('💾 Updated stored userData with fresh backend data');
                
                // Update email
                if (accountEmail && validateData.user.email) {
                    accountEmail.textContent = validateData.user.email;
                    console.log('✅ Email updated:', validateData.user.email);
                }
                
                if (validateData.user.plan && validateData.user.plan.name) {
                    // Update plan name in Settings
                    if (accountPlan) {
                        accountPlan.textContent = validateData.user.plan.name || 'Free';
                    }
                    // Update plan name in Header badge
                    if (headerPlanName) {
                        headerPlanName.textContent = validateData.user.plan.name || 'Free';
                    }
                    console.log('✅ Plan name updated from backend:', validateData.user.plan.name);
                    
                    // Update plan limits from user.plan
                    if (planLimitComments) planLimitComments.textContent = validateData.user.plan.monthlyComments || '--';
                    if (planLimitLikes) planLimitLikes.textContent = validateData.user.plan.monthlyLikes || '--';
                    if (planLimitShares) planLimitShares.textContent = validateData.user.plan.monthlyShares || '--';
                    if (planLimitFollows) planLimitFollows.textContent = validateData.user.plan.monthlyFollows || '--';
                    if (planLimitConnections) planLimitConnections.textContent = validateData.user.plan.monthlyConnections || '--';
                    if (planLimitAiPosts) planLimitAiPosts.textContent = validateData.user.plan.aiPostsPerMonth || '--';
                    if (planLimitAiComments) planLimitAiComments.textContent = validateData.user.plan.aiCommentsPerMonth || '--';
                    if (planLimitAiTopics) planLimitAiTopics.textContent = validateData.user.plan.aiTopicLinesPerMonth || '--';
                    console.log('✅ Settings plan limits updated from backend:', validateData.user.plan);
                    
                    // Update features display
                    updateFeaturesDisplay(validateData.user.plan);
                } else {
                    console.warn('⚠️ No plan data found in user object');
                    if (accountPlan) {
                        accountPlan.textContent = 'No Plan';
                    }
                    if (headerPlanName) {
                        headerPlanName.textContent = 'No Plan';
                    }
                }
            } else if (userData.email) {
                // Fallback to stored userData if no fresh data
                if (accountEmail) {
                    accountEmail.textContent = userData.email;
                }
                if (userData.plan) {
                    if (accountPlan) accountPlan.textContent = userData.plan.name || 'Free';
                    if (headerPlanName) headerPlanName.textContent = userData.plan.name || 'Free';
                    if (planLimitComments) planLimitComments.textContent = userData.plan.monthlyComments || '--';
                    if (planLimitLikes) planLimitLikes.textContent = userData.plan.monthlyLikes || '--';
                    if (planLimitShares) planLimitShares.textContent = userData.plan.monthlyShares || '--';
                    if (planLimitFollows) planLimitFollows.textContent = userData.plan.monthlyFollows || '--';
                    if (planLimitConnections) planLimitConnections.textContent = userData.plan.monthlyConnections || '--';
                    if (planLimitAiPosts) planLimitAiPosts.textContent = userData.plan.aiPostsPerMonth || '--';
                    if (planLimitAiComments) planLimitAiComments.textContent = userData.plan.aiCommentsPerMonth || '--';
                    if (planLimitAiTopics) planLimitAiTopics.textContent = userData.plan.aiTopicLinesPerMonth || '--';
                }
                
                // Update features display
                updateFeaturesDisplay(userData.plan || validateData?.user?.plan);
            }
        } else {
            // Show that user needs to login - NO DEFAULT LIMITS
            if (accountPlan) {
                accountPlan.textContent = 'Login Required';
            }
            if (headerPlanName) {
                headerPlanName.textContent = 'Free';
            }
            if (accountEmail) {
                accountEmail.textContent = 'Not logged in';
            }

            if (planLimitComments) planLimitComments.textContent = '--';
            if (planLimitLikes) planLimitLikes.textContent = '--';
            if (planLimitShares) planLimitShares.textContent = '--';
            if (planLimitFollows) planLimitFollows.textContent = '--';
            if (planLimitConnections) planLimitConnections.textContent = '--';
            if (planLimitAiPosts) planLimitAiPosts.textContent = '--';
            if (planLimitAiComments) planLimitAiComments.textContent = '--';
            if (planLimitAiTopics) planLimitAiTopics.textContent = '--';
        }
    } catch (error) {
        console.error('Error updating authentication UI:', error);
    }
}

// Prevent multiple simultaneous calls
let isLoadingPlans = false;

// Load available plans from backend with caching
async function loadPlans() {
    // Prevent multiple simultaneous calls
    if (isLoadingPlans) {
        console.log('⚠️ loadPlans already in progress, skipping...');
        return;
    }
    
    isLoadingPlans = true;
    console.log('Loading plans...');
    
    try {
        // Get elements directly
        const plansLoading = document.getElementById('plans-loading');
        const plansError = document.getElementById('plans-error');
        const plansContainer = document.getElementById('plans-container');

        const storage = await chrome.storage.local.get(['apiBaseUrl', 'cachedPlans', 'plansCacheTime']);
        const apiUrl = storage.apiBaseUrl || API_CONFIG.BASE_URL;

        // Clear any old cached plans to force fresh API call
        await chrome.storage.local.remove(['cachedPlans', 'plansCacheTime', 'fallbackPlans']);

        // Show loading state
        if (plansLoading) plansLoading.style.display = 'block';
        if (plansError) plansError.style.display = 'none';
        if (plansContainer) plansContainer.style.display = 'none';

        // Fetch plans directly from API
        
        const response = await fetch(`${apiUrl}/api/plans`, {
            method: 'GET',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
            }
        });
        
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        
        const data = await response.json();

        if (data.success && data.plans) {
            console.log('✅ Plans loaded:', data.plans.length, 'plans');
            
            displayPlans(data.plans);
            
            if (plansLoading) plansLoading.style.display = 'none';
            if (plansContainer) plansContainer.style.display = 'grid';
        } else {
            console.error('API response missing success or plans:', data);
            throw new Error(data.error || 'API response missing plans data');
        }
    } catch (error) {
        console.error('❌ Error loading plans:', error.message);
        
        const plansLoading = document.getElementById('plans-loading');
        const plansError = document.getElementById('plans-error');
        const plansContainer = document.getElementById('plans-container');
        
        if (plansLoading) plansLoading.style.display = 'none';
        if (plansError) {
            plansError.style.display = 'block';
            plansError.innerHTML = `
                <div style="color: #dc3545; text-align: center; padding: 20px;">
                    <h4>❌ Failed to Load Plans</h4>
                    <p>Error: ${error.message}</p>
                    <p>API URL: ${apiUrl}/api/plans</p>
                    <button id="retry-plans" style="margin-top: 10px; padding: 8px 16px; background: #693fe9; color: white; border: none; border-radius: 4px; cursor: pointer;">
                        🔄 Retry
                    </button>
                </div>
            `;
            
            // Add retry functionality
            document.getElementById('retry-plans')?.addEventListener('click', loadPlans);
        }
        if (plansContainer) plansContainer.style.display = 'none';
        
        showNotification(`❌ Failed to load plans: ${error.message}`, 'error');
    } finally {
        isLoadingPlans = false;
    }
}

// Display plans in the modal - SHOWING LIFETIME DEALS ONLY
async function displayPlans(plans) {
    const plansContainer = document.getElementById('plans-container');
    if (!plansContainer) {
        console.error('Plans container not found');
        return;
    }

    plansContainer.innerHTML = '';
    
    // Get user's current plan from backend API
    let userCurrentPlanName = null;
    try {
        const storage = await chrome.storage.local.get(['authToken', 'apiBaseUrl']);
        if (storage.authToken) {
            const apiUrl = storage.apiBaseUrl || API_CONFIG.BASE_URL;
            const response = await fetch(`${apiUrl}/api/auth/validate`, {
                headers: { 'Authorization': `Bearer ${storage.authToken}` }
            });
            const data = await response.json();
            if (data.success && data.user && data.user.plan) {
                userCurrentPlanName = data.user.plan.name;
                console.log('User current plan from API:', userCurrentPlanName);
            }
        }
    } catch (error) {
        console.error('Error fetching user plan:', error);
    }

    // LIFETIME DEALS ONLY - Filter for lifetime plans
    const lifetimeDeals = plans.filter(plan => plan.isLifetime === true);
    
    /* MONTHLY PLANS COMMENTED OUT - Uncomment to show monthly plans again
    const paidPlans = plans.filter(plan => {
        const planName = plan.name.toLowerCase();
        return planName !== 'free' && planName !== 'free trial' && !planName.includes('free trial') && !plan.isLifetime;
    });
    */
    
    // If no lifetime deals found, show message
    if (lifetimeDeals.length === 0) {
        plansContainer.innerHTML = `
            <div style="text-align: center; padding: 40px; grid-column: 1 / -1;">
                <p style="color: #666; margin-bottom: 20px;">Loading lifetime deals...</p>
                <a href="https://kommentify.com/plans" target="_blank" style="
                    display: inline-block;
                    padding: 12px 24px;
                    background: linear-gradient(135deg, #f59e0b, #ef4444);
                    color: white;
                    text-decoration: none;
                    border-radius: 8px;
                    font-weight: bold;
                ">View Lifetime Deals →</a>
            </div>
        `;
        return;
    }
    
    // Add header for lifetime deals
    const header = document.createElement('div');
    header.style.cssText = 'grid-column: 1 / -1; text-align: center; margin-bottom: 20px;';
    header.innerHTML = `
        <div style="display: inline-block; background: linear-gradient(135deg, rgba(245, 158, 11, 0.2), rgba(239, 68, 68, 0.1)); border: 1px solid rgba(245, 158, 11, 0.4); padding: 8px 20px; border-radius: 20px; color: #f59e0b; font-weight: 600; margin-bottom: 10px;">
            🔥 LIMITED TIME — Pay Once, Use Forever
        </div>
    `;
    plansContainer.appendChild(header);
    
    lifetimeDeals.forEach((plan, index) => {
        const isCurrentPlan = userCurrentPlanName && plan.name.toLowerCase() === userCurrentPlanName.toLowerCase();
        const isPopular = plan.popular || plan.name.toLowerCase().includes('growth');
        const planCard = document.createElement('div');
        
        // Calculate savings (assuming yearly equivalent)
        const yearlyCost = plan.price * 12;
        yearlyCost - (plan.lifetimePrice || plan.price);
        
        planCard.style.cssText = `
            border: 2px solid ${isCurrentPlan ? '#28a745' : (isPopular ? '#f59e0b' : 'rgba(255,255,255,0.1)')};
            border-radius: 16px;
            padding: 24px;
            text-align: center;
            transition: all 0.3s;
            cursor: pointer;
            background: ${isPopular ? 'linear-gradient(135deg, rgba(245, 158, 11, 0.1), rgba(239, 68, 68, 0.05))' : 'rgba(255,255,255,0.02)'};
            ${isPopular ? 'transform: scale(1.02); box-shadow: 0 10px 40px rgba(245, 158, 11, 0.2);' : ''}
            ${isCurrentPlan ? 'box-shadow: 0 4px 12px rgba(40, 167, 69, 0.2);' : ''}
            position: relative;
        `;

        plan.features || {};
        const limits = plan.limits || {};
        const lifetimePrice = plan.lifetimePrice || plan.price;
        
        // Get spots info
        const spotsRemaining = plan.lifetimeSpotsRemaining || plan.lifetimeMaxSpots - (plan.lifetimeSoldSpots || 0);

        planCard.innerHTML = `
            ${isPopular && !isCurrentPlan ? '<div style="position: absolute; top: -12px; left: 50%; transform: translateX(-50%); background: linear-gradient(135deg, #f59e0b, #ef4444); color: white; padding: 6px 16px; border-radius: 20px; font-size: 11px; font-weight: 700; white-space: nowrap;">🔥 MOST POPULAR</div>' : ''}
            ${isCurrentPlan ? '<div style="background: #28a745; color: white; padding: 4px 8px; border-radius: 4px; font-size: 12px; font-weight: bold; margin-bottom: 10px;">✓ CURRENT PLAN</div>' : ''}
            
            <h3 style="color: ${isPopular ? '#fbbf24' : '#693fe9'}; margin-bottom: 5px; margin-top: ${isPopular ? '10px' : '0'}; font-size: 20px;">${plan.name}</h3>
            <div style="font-size: 12px; color: #888; margin-bottom: 12px;">One-time payment</div>
            
            <div style="font-size: 14px; text-decoration: line-through; color: #888; margin-bottom: 4px;">$${(lifetimePrice * 12).toFixed(0)}/year</div>
            <div style="font-size: 36px; font-weight: 800; color: ${isPopular ? '#fbbf24' : '#693fe9'}; margin-bottom: 4px;">
                $${lifetimePrice}
            </div>
            <div style="font-size: 14px; color: #888; margin-bottom: 8px;">once</div>
            <div style="display: inline-block; background: #22c55e; color: white; padding: 4px 12px; border-radius: 20px; font-size: 12px; font-weight: 600; margin-bottom: 16px;">Save $${((lifetimePrice * 12) - lifetimePrice).toFixed(0)}</div>
            
            ${spotsRemaining ? `<div style="font-size: 12px; color: #f59e0b; margin-bottom: 12px;">⚠️ Only ${spotsRemaining} spots remaining</div>` : ''}
            
            <div style="text-align: left; margin-bottom: 15px; font-size: 13px; border-top: 1px solid rgba(0,0,0,0.1); padding-top: 15px;">
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 6px;">
                    <div>💭 ${limits.aiComments || limits.aiCommentsPerMonth || 0} AI Comments/mo</div>
                    <div>🤖 ${limits.aiPosts || limits.aiPostsPerMonth || 0} AI Posts/mo</div>
                    <div>❤️ ${limits.likes || limits.monthlyLikes || 0} Auto Likes</div>
                    <div>📤 ${limits.shares || limits.monthlyShares || 0} Auto Shares</div>
                    <div>👥 ${limits.follows || limits.monthlyFollows || 0} Auto Follows</div>
                    <div>🔗 ${limits.connections || limits.monthlyConnections || 0} Connections</div>
                </div>
            </div>
            
            <div style="text-align: left; margin-bottom: 16px; font-size: 13px;">
                <div style="color: #10b981;">✅ Lifetime Updates</div>
                <div style="color: #10b981;">✅ Priority Support</div>
                <div style="color: #10b981;">✅ 30-Day Money-Back</div>
            </div>
            
            <button style="
                width: 100%;
                padding: 12px;
                background: ${isCurrentPlan ? '#28a745' : (isPopular ? 'linear-gradient(135deg, #f59e0b, #ef4444)' : 'linear-gradient(135deg, #693fe9, #8b5cf6)')};
                color: white;
                border: none;
                border-radius: 10px;
                font-weight: bold;
                cursor: pointer;
                font-size: 14px;
                ${isCurrentPlan ? 'opacity: 0.8;' : ''}
            " class="select-plan-btn" data-plan-id="${plan.id}" data-stripe-link="${plan.stripeLink || ''}" ${isCurrentPlan ? 'disabled' : ''}>
                ${isCurrentPlan ? 'Current Plan' : '🚀 Get Lifetime Access'}
            </button>
        `;

        planCard.addEventListener('mouseenter', () => {
            if (!isPopular) {
                planCard.style.borderColor = '#693fe9';
                planCard.style.transform = 'translateY(-2px)';
            }
        });

        planCard.addEventListener('mouseleave', () => {
            if (!isPopular) {
                planCard.style.borderColor = 'rgba(255,255,255,0.1)';
                planCard.style.transform = 'translateY(0)';
            }
        });

        const btn = planCard.querySelector('.select-plan-btn');
        btn.addEventListener('click', (e) => {
            e.stopPropagation();
            selectPlan(plan.id, plan.stripeLink || '');
        });

        plansContainer.appendChild(planCard);
    });
    
    // Add footer
    const footer = document.createElement('div');
    footer.style.cssText = 'grid-column: 1 / -1; text-align: center; margin-top: 20px; display: flex; justify-content: center; gap: 20px; flex-wrap: wrap;';
    footer.innerHTML = `
        <span style="color: #888; font-size: 12px;">✅ 30-Day Money-Back</span>
        <span style="color: #888; font-size: 12px;">✅ One-Time Payment</span>
        <span style="color: #888; font-size: 12px;">✅ Lifetime Updates</span>
    `;
    plansContainer.appendChild(footer);
}

// Handle plan selection
function selectPlan(planId, stripeLink) {
    // Always open the plans page URL
    const plansUrl = 'https://kommentify.com/plans';
    chrome.tabs.create({ url: plansUrl });
    if (elements.planModal) elements.planModal.style.display = 'none';
}

async function handleLogin() {
    try {
        const storage = await chrome.storage.local.get(['apiBaseUrl']);
        const apiUrl = storage.apiBaseUrl || API_CONFIG.BASE_URL;
        const loginUrl = `${apiUrl}/login`;

        await chrome.tabs.create({ url: loginUrl });
    } catch (error) {
        console.error('Error handling login:', error);
    }
}

async function handleLogout() {
    try {
        await chrome.storage.local.remove([
            'authToken', 
            'userData', 
            'tokenValidationCache', 
            'tokenValidationTimestamp',
            'userDataCache',
            'userDataCacheTimestamp'
        ]);
        updateAuthenticationUI();
        alert('Logged out successfully');
    } catch (error) {
        console.error('Error handling logout:', error);
    }
}

// Check and show upgrade prompts
function checkAndShowUpgradePrompts(usage, limits, features) {
    // Check if any limit is reached
    const limitsReached = [];

    if (usage.comments >= limits.comments) limitsReached.push('comments');
    if (usage.likes >= limits.likes) limitsReached.push('likes');
    if (usage.shares >= limits.shares) limitsReached.push('shares');
    if (usage.follows >= limits.follows) limitsReached.push('follows');

    // Show upgrade banner if limits reached
    if (limitsReached.length > 0) {
        showUpgradeBanner(limitsReached);
    }

    // Disable features not available in plan
    if (!features.postScheduling) {
        const scheduleBtn = document.getElementById('schedule-post');
        if (scheduleBtn) {
            scheduleBtn.disabled = true;
            scheduleBtn.title = 'Upgrade to Pro for post scheduling';
        }
    }

    if (!features.networking) {
        const networkingBtn = document.getElementById('start-people-search');
        if (networkingBtn) {
            networkingBtn.disabled = true;
            networkingBtn.title = 'Upgrade to Pro for networking features';
        }
    }
}

// Show upgrade banner
function showUpgradeBanner(limitsReached) {
    const banner = document.createElement('div');
    banner.style.cssText = `
            position: fixed;
            top: 10px;
            left: 50%;
            transform: translateX(-50%);
            background: linear-gradient(135deg, #693fe9 0%, #693fe9 100%);
            color: white;
            padding: 15px 25px;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.3);
            z-index: 10000;
            font-size: 14px;
            text-align: center;
            max-width: 400px;
        `;

    banner.innerHTML = `
            <strong>⚠️ Daily Limit Reached</strong><br>
            You've reached your daily limit for: ${limitsReached.join(', ')}<br>
            <button style="
                margin-top: 10px;
                padding: 8px 20px;
                background: white;
                color: #693fe9;
                border: none;
                border-radius: 8px;
                font-weight: 600;
                cursor: pointer;
            " onclick="alert('Visit our website to upgrade your plan!')">
                Upgrade Plan
            </button>
        `;

    document.body.appendChild(banner);

    // Auto-remove after 10 seconds
    setTimeout(() => banner.remove(), 10000);
}

/**
 * INSPIRATION SOURCES MODULE
 * Handles profile scraping, vector storage, and RAG-based content generation
 */


// State for inspiration sources
let inspirationSources = [];
let selectedSourceUrls = [];
let useInspirationContext = true;

// Initialize inspiration sources functionality
function initializeInspirationSources() {
    console.log('🎨 Initializing inspiration sources...');
    
    // Toggle panel button
    const toggleBtn = document.getElementById('toggle-inspiration-panel');
    const panel = document.getElementById('inspiration-panel');
    
    if (toggleBtn && panel) {
        toggleBtn.addEventListener('click', () => {
            const isHidden = panel.style.display === 'none';
            panel.style.display = isHidden ? 'block' : 'none';
            toggleBtn.innerHTML = isHidden 
                ? '<span class="icon icon-chevron-up"></span> Collapse' 
                : '<span class="icon icon-chevron-down"></span> Expand';
        });
    }
    
    // Add inspiration source button
    const addSourceBtn = document.getElementById('add-inspiration-source');
    if (addSourceBtn) {
        addSourceBtn.addEventListener('click', handleAddInspirationSource);
    }
    
    // Refresh sources button
    const refreshBtn = document.getElementById('refresh-sources');
    if (refreshBtn) {
        refreshBtn.addEventListener('click', loadInspirationSources);
    }
    
    // Use context toggle
    const contextToggle = document.getElementById('use-inspiration-context');
    if (contextToggle) {
        contextToggle.addEventListener('change', (e) => {
            useInspirationContext = e.target.checked;
            const selectorContainer = document.getElementById('source-selector-container');
            if (selectorContainer) {
                selectorContainer.style.display = useInspirationContext ? 'block' : 'none';
            }
            console.log('Use inspiration context:', useInspirationContext);
        });
    }
    
    // Use all sources checkbox
    const useAllCheckbox = document.getElementById('use-all-sources');
    if (useAllCheckbox) {
        useAllCheckbox.addEventListener('change', (e) => {
            if (e.target.checked) {
                selectedSourceUrls = inspirationSources.map(s => s.profileUrl);
            } else {
                selectedSourceUrls = [];
            }
            updateSourceCheckboxes();
        });
    }
    
    // Load existing sources
    loadInspirationSources();
}

// Listen for storage changes to auto-refresh when background completes scraping
chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName === 'local' && changes.lastInspirationResult) {
        const result = changes.lastInspirationResult.newValue;
        if (result && result.success) {
            console.log('📚 Background scraping completed, refreshing sources...');
            loadInspirationSources();
        }
    }
});

// Load inspiration sources from backend
async function loadInspirationSources() {
    console.log('📚 Loading inspiration sources from backend...');
    try {
        const { authToken, apiBaseUrl } = await chrome.storage.local.get(['authToken', 'apiBaseUrl']);
        const apiUrl = apiBaseUrl || API_CONFIG.BASE_URL;
        
        if (!authToken) {
            console.warn('No auth token found, cannot load sources');
            return;
        }
        
        console.log('📚 Fetching from:', `${apiUrl}/api/vector/ingest`);
        
        const response = await fetch(`${apiUrl}/api/vector/ingest`, {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${authToken}`,
                'Content-Type': 'application/json'
            }
        });
        
        const data = await response.json();
        console.log('📚 Load sources response:', data);
        
        if (data.success && data.sources) {
            inspirationSources = data.sources;
            selectedSourceUrls = inspirationSources.map(s => s.profileUrl);
            renderSourcesList();
            updateSourceCheckboxes();
            console.log(`📚 Loaded ${inspirationSources.length} inspiration sources:`, inspirationSources);
        } else {
            console.warn('📚 No sources in response or request failed:', data.error);
        }
    } catch (error) {
        console.error('❌ Failed to load inspiration sources:', error);
    }
}

// Render the sources list
function renderSourcesList() {
    const listContainer = document.getElementById('inspiration-sources-list');
    if (!listContainer) return;
    
    if (inspirationSources.length === 0) {
        listContainer.innerHTML = `
            <p style="text-align: center; color: #999; font-size: 13px; padding: 20px;">
                No sources added yet. Add a LinkedIn profile above to get started!
            </p>
        `;
        return;
    }
    
    listContainer.innerHTML = inspirationSources.map(source => `
        <div class="source-item">
            <div style="display: flex; align-items: center; gap: 10px;">
                <span style="font-size: 18px;">👤</span>
                <div>
                    <div style="font-weight: 600; color: #333; font-size: 13px;">${source.name}</div>
                    <div style="font-size: 11px; color: #666;">${source.postCount} posts saved</div>
                </div>
            </div>
            <button class="delete-source-btn" data-url="${source.profileUrl}" 
                    style="background: none; border: none; color: #dc3545; cursor: pointer; font-size: 14px;">
                🗑️
            </button>
        </div>
    `).join('');
    
    // Add delete handlers
    listContainer.querySelectorAll('.delete-source-btn').forEach(btn => {
        btn.addEventListener('click', () => handleDeleteSource(btn.dataset.url));
    });
}

// Update source checkboxes
function updateSourceCheckboxes() {
    const container = document.getElementById('source-checkboxes');
    if (!container) return;
    
    const useAllChecked = selectedSourceUrls.length === inspirationSources.length;
    
    let html = `
        <label class="source-checkbox ${useAllChecked ? 'selected' : ''}">
            <input type="checkbox" id="use-all-sources" ${useAllChecked ? 'checked' : ''}>
            <span>Use All Sources</span>
        </label>
    `;
    
    inspirationSources.forEach(source => {
        const isSelected = selectedSourceUrls.includes(source.profileUrl);
        html += `
            <label class="source-checkbox ${isSelected ? 'selected' : ''}" data-url="${source.profileUrl}">
                <input type="checkbox" ${isSelected ? 'checked' : ''}>
                <span>${source.name}</span>
            </label>
        `;
    });
    
    container.innerHTML = html;
    
    // Re-attach event listeners
    const useAllCheckbox = document.getElementById('use-all-sources');
    if (useAllCheckbox) {
        useAllCheckbox.addEventListener('change', (e) => {
            if (e.target.checked) {
                selectedSourceUrls = inspirationSources.map(s => s.profileUrl);
            } else {
                selectedSourceUrls = [];
            }
            updateSourceCheckboxes();
        });
    }
    
    container.querySelectorAll('.source-checkbox[data-url]').forEach(label => {
        const checkbox = label.querySelector('input');
        checkbox.addEventListener('change', (e) => {
            const url = label.dataset.url;
            if (e.target.checked) {
                if (!selectedSourceUrls.includes(url)) {
                    selectedSourceUrls.push(url);
                }
            } else {
                selectedSourceUrls = selectedSourceUrls.filter(u => u !== url);
            }
            updateSourceCheckboxes();
        });
    });
}

// Handle adding a new inspiration source
async function handleAddInspirationSource() {
    const urlInput = document.getElementById('inspiration-profile-url');
    const countSelect = document.getElementById('scrape-post-count');
    document.getElementById('scrape-status');
    const addBtn = document.getElementById('add-inspiration-source');
    
    const profileUrl = urlInput?.value?.trim();
    const postCount = parseInt(countSelect?.value || '10');
    
    if (!profileUrl) {
        showStatus('Please enter a LinkedIn profile URL', 'error');
        return;
    }
    
    // Validate LinkedIn URL
    if (!profileUrl.includes('linkedin.com/in/')) {
        showStatus('Please enter a valid LinkedIn profile URL (e.g., https://linkedin.com/in/username)', 'error');
        return;
    }
    
    // Disable button and show loading
    if (addBtn) {
        addBtn.disabled = true;
        addBtn.innerHTML = '<span class="icon icon-loader"></span> Scraping posts...';
    }
    showStatus('Opening profile and scraping posts...', 'info');
    
    try {
        // Send message to background script to handle scraping AND saving to backend
        // Background script now handles the full flow to avoid popup timeout issues
        const response = await chrome.runtime.sendMessage({
            action: 'scrapeProfilePosts',
            profileUrl,
            postCount
        });
        
        console.log('✅ Scrape response received:', response);
        
        if (response.success) {
            if (response.savedToBackend) {
                showStatus(`✅ Added ${response.savedCount} posts from ${response.authorName}!`, 'success');
                urlInput.value = '';
                // Reload sources to show the new one
                await loadInspirationSources();
            } else if (response.backendError) {
                showStatus(`⚠️ Scraped ${response.posts?.length || 0} posts but failed to save: ${response.backendError}`, 'error');
            } else {
                showStatus(`✅ Scraped ${response.posts?.length || 0} posts from ${response.authorName}`, 'success');
                urlInput.value = '';
                await loadInspirationSources();
            }
        } else {
            throw new Error(response.error || 'Failed to scrape posts');
        }
    } catch (error) {
        console.error('Add inspiration source error:', error);
        // Check if error is due to popup timeout - background may have completed anyway
        if (error.message?.includes('Could not establish connection') || 
            error.message?.includes('message port closed')) {
            showStatus('⏳ Scraping in progress... Please wait and refresh the sources list.', 'info');
        } else {
            showStatus(`❌ ${error.message}`, 'error');
        }
    } finally {
        if (addBtn) {
            addBtn.disabled = false;
            addBtn.innerHTML = '<span class="icon icon-plus"></span> Scrape & Add Profile';
        }
    }
}

// Handle deleting a source
async function handleDeleteSource(profileUrl) {
    if (!confirm('Delete this inspiration source? This will remove all saved posts from this profile.')) {
        return;
    }
    
    try {
        // Delete from vector DB
        const { authToken, apiBaseUrl } = await chrome.storage.local.get(['authToken', 'apiBaseUrl']);
        const apiUrl = apiBaseUrl || API_CONFIG.BASE_URL;
        
        const response = await fetch(`${apiUrl}/api/vector/delete`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${authToken}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ profileUrl })
        });
        
        const data = await response.json();
        
        if (data.success) {
            // Remove from local state
            inspirationSources = inspirationSources.filter(s => s.profileUrl !== profileUrl);
            selectedSourceUrls = selectedSourceUrls.filter(u => u !== profileUrl);
            renderSourcesList();
            updateSourceCheckboxes();
            showNotification(`Deleted ${data.deleted || 0} posts`, 'success');
        } else {
            throw new Error(data.error || 'Failed to delete source');
        }
    } catch (error) {
        console.error('Delete source error:', error);
        showNotification('Failed to delete source: ' + error.message, 'error');
    }
}

// Show status message
function showStatus(message, type = 'info') {
    const statusDiv = document.getElementById('scrape-status');
    if (!statusDiv) return;
    
    statusDiv.style.display = 'block';
    statusDiv.style.color = type === 'error' ? '#dc3545' : type === 'success' ? '#28a745' : '#666';
    statusDiv.textContent = message;
    
    if (type === 'success') {
        setTimeout(() => {
            statusDiv.style.display = 'none';
        }, 3000);
    }
}

// Get current inspiration settings for post generation
function getInspirationSettings() {
    return {
        useInspirationContext,
        selectedSources: selectedSourceUrls,
        topK: 3
    };
}

// --- POST WRITER FUNCTIONS --- //

/**
 * Check if any automation processing is currently active
 * Returns processing type if active, null if not
 */
async function checkProcessingActive() {
    try {
        const response = await chrome.runtime.sendMessage({ action: 'getProcessingState' });
        if (response && response.isProcessing) {
            return response.processingType || 'automation';
        }
        return null;
    } catch (error) {
        console.warn('Could not check processing state:', error);
        return null;
    }
}

/**
 * Show processing disclaimer message
 */
function showProcessingDisclaimer(processingType) {
    const typeNames = {
        'bulk_processing': 'Commenter Tab',
        'people_search': 'Networking Tab',
        'import': 'Import Tab',
        'automation': 'Automation'
    };
    const typeName = typeNames[processingType] || 'another tab';
    
    showToast(`⏳ Please wait - processing is running in ${typeName}. Stop it first or wait for completion.`, 'warning');
    
    // Also show a more detailed alert
    const shouldSwitch = confirm(
        `⚠️ Writer Tab Actions Blocked\n\n` +
        `Processing is currently running in ${typeName}.\n\n` +
        `To use Writer tab features, you can:\n` +
        `• Wait for the current processing to complete\n` +
        `• Switch to that tab and click Stop\n\n` +
        `Click OK to switch to Dashboard (where you can stop processing)`
    );
    
    if (shouldSwitch) {
        // Switch to dashboard tab
        const dashboardTab = document.querySelector('[data-tab="dashboard"]');
        if (dashboardTab) {
            dashboardTab.click();
        }
    }
}

async function generatePost() {
    // Check if processing is active
    const processingType = await checkProcessingActive();
    if (processingType) {
        showProcessingDisclaimer(processingType);
        return;
    }
    
    // Check if AI post generation is allowed in user's plan
    const canUseAiPost = await featureChecker.checkFeature('aiPostGeneration');
    if (!canUseAiPost) {
        showToast('⬆️ AI Post Generation requires a paid plan. Please upgrade!', 'error');
        const planModal = document.getElementById('plan-modal');
        if (planModal) {
            planModal.style.display = 'flex';
            loadPlans();
        }
        return;
    }
    
    const topic = elements.postTopic.value.trim();
    if (!topic) {
        alert('Please enter a topic or idea for your post');
        return;
    }

    const template = elements.postTemplate.value;
    const tone = elements.postTone.value;
    const length = parseInt(elements.postLength.value) || 1500;
    const includeHashtags = elements.postIncludeHashtags.checked;
    const includeEmojis = elements.postIncludeEmojis.checked;
    const useCheapModel = state.preferences.useCheapModel || false;
    
    // Get advanced settings
    const targetAudience = elements.targetAudience?.value?.trim() || '';
    const keyMessage = elements.keyMessage?.value?.trim() || '';
    const userBackground = elements.userBackground?.value?.trim() || '';
    
    // Get inspiration context settings
    let inspirationSettings = { useInspirationContext: false, selectedSources: [], topK: 3 };
    try {
        inspirationSettings = getInspirationSettings();
    } catch (e) {
        console.warn('Could not get inspiration settings:', e);
    }

    // Show loading state
    const loadingMsg = inspirationSettings.useInspirationContext 
        ? '✨ Generating post with your inspiration context...\n\nAnalyzing writing styles from your saved sources...'
        : '✨ Generating viral LinkedIn post with AI...\n\nThis may take a few seconds...';
    elements.postContent.value = loadingMsg;
    elements.generatePost.disabled = true;

    try {
        // If using inspiration context, call the RAG-based API directly
        if (inspirationSettings.useInspirationContext && inspirationSettings.selectedSources.length > 0) {
            const { authToken, apiBaseUrl } = await chrome.storage.local.get(['authToken', 'apiBaseUrl']);
            const apiUrl = apiBaseUrl || API_CONFIG.BASE_URL;
            
            const ragResponse = await fetch(`${apiUrl}/api/vector/generate`, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${authToken}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    topic,
                    template,
                    tone,
                    length,
                    includeEmojis,
                    includeHashtags,
                    useInspirationContext: true,
                    selectedSources: inspirationSettings.selectedSources,
                    topK: inspirationSettings.topK
                })
            });
            
            const ragData = await ragResponse.json();
            
            if (ragData.success && ragData.post) {
                elements.postContent.value = ragData.post;
                updateCharacterCount();
                if (ragData.contextUsed > 0) {
                    showToast(`✨ Generated with ${ragData.contextUsed} inspiration examples`, 'success');
                }
                elements.generatePost.disabled = false;
                return;
            }
            // Fall through to regular generation if RAG fails
            console.log('RAG generation failed, falling back to regular generation');
        }
        
        // Regular generation via background script
        const response = await chrome.runtime.sendMessage({
            action: 'generatePost',
            topic,
            template,
            tone,
            length,
            includeHashtags,
            includeEmojis,
            useCheapModel,
            targetAudience,
            keyMessage,
            userBackground
        });

        if (response && response.content) {
            elements.postContent.value = response.content;
            updateCharacterCount(); // Update character counter after AI content is set
        } else if (response && response.error) {
            // Check if it's a limit/plan error
            const errorMsg = response.error.toLowerCase();
            if (errorMsg.includes('limit') || errorMsg.includes('plan') || errorMsg.includes('upgrade')) {
                // Show upgrade prompt
                showToast('Monthly AI post limit reached. Please upgrade your plan.', 'error');
                
                // Switch to limits tab to show upgrade option
                const limitsTab = document.querySelector('[data-tab="limits"]');
                if (limitsTab) {
                    limitsTab.click();
                }
                
                // Clear the generating message
                elements.postContent.value = '';
            } else {
                // Other errors - show error and fallback
                showToast(response.error, 'error');
                elements.postContent.value = generatePostFromTemplate(topic, template, includeHashtags, includeEmojis);
                updateCharacterCount();
            }
        } else {
            // Fallback: use template
            elements.postContent.value = generatePostFromTemplate(topic, template, includeHashtags, includeEmojis);
            updateCharacterCount();
        }
    } catch (error) {
        console.error('Error generating post:', error);
        showToast('Failed to generate post', 'error');
        elements.postContent.value = generatePostFromTemplate(topic, template, includeHashtags, includeEmojis);
        updateCharacterCount();
    } finally {
        elements.generatePost.disabled = false;
    }
}

function generatePostFromTemplate(topic, template, includeHashtags = true, includeEmojis = true) {
    const emoji = includeEmojis;
    const hashtag = (tag) => includeHashtags ? `#${tag}` : '';

    const templates = {
        lead_magnet: `${emoji ? '🚀 ' : ''}R.I.P traditional ${topic}\n\nMost of them charge high fees and get you half of the "promised" results.\n\nWe've helped 50+ clients using a system most don't even know exists.\n\nThe difference?\n\nMost do outbound OR content.\n\nWe do both simultaneously (and they amplify each other).\n\nHere's what happens when they combine:\n${emoji ? '→ ' : '- '}3X higher reply rates\n${emoji ? '→ ' : '- '}Reach qualified people\n${emoji ? '→ ' : '- '}Credibility skyrockets\n${emoji ? '→ ' : '- '}Sales cycles cut in half\n\nWant to see if this fits your business?\n\n1. Connect with me\n2. DM me "INFO"\n\nI'll send you our full breakdown.\n\n${includeHashtags ? `${hashtag('LinkedIn')} ${hashtag(topic.replace(/\s+/g, ''))} ${hashtag('LeadGeneration')}` : ''}`,
        announcement: `${emoji ? '🎉 ' : ''}Exciting news!\n\nI wanted to share something about ${topic}.\n\nWhat do you think? Share your thoughts below!\n\n${includeHashtags ? `${hashtag('LinkedIn')} ${hashtag(topic.replace(/\s+/g, ''))}` : ''}`,
        insight: `${emoji ? '💡 ' : ''}Here's something I learned recently about ${topic}:\n\n${topic} is becoming increasingly important in today's landscape.\n\nWhat's your take on this?\n\n${includeHashtags ? `${hashtag('Learning')} ${hashtag(topic.replace(/\s+/g, ''))}` : ''}`,
        question: `${emoji ? '🤔 ' : ''}Quick question for my network:\n\nWhat are your thoughts on ${topic}?\n\nI'd love to hear your perspective!\n\n${includeHashtags ? `${hashtag('Discussion')} ${hashtag(topic.replace(/\s+/g, ''))}` : ''}`,
        achievement: `${emoji ? '🏆 ' : ''}Proud to share my recent work on ${topic}\n\nIt's been an incredible journey.\n\nThank you to everyone who supported me!\n\n${includeHashtags ? `${hashtag('Achievement')} ${hashtag(topic.replace(/\s+/g, ''))}` : ''}`,
        tip: `${emoji ? '📌 ' : ''}Pro tip about ${topic}:\n\nThis can really make a difference in your work.\n\nHave you tried this? Let me know!\n\n${includeHashtags ? `${hashtag('Tips')} ${hashtag(topic.replace(/\s+/g, ''))}` : ''}`,
        custom: `${topic}\n\n${includeHashtags ? `${hashtag('LinkedIn')} ${hashtag('Professional')}` : ''}`
    };

    return templates[template] || templates.custom;
}

function analyzePost() {
    const content = elements.postContent.value.trim();
    if (!content) {
        alert('Please enter or generate post content first');
        return;
    }

    const words = content.split(/\s+/).filter(w => w.length > 0);
    const sentences = content.split(/[.!?]+/).filter(s => s.trim().length > 0);
    
    const analysis = {
        score: 0,
        length: content.length,
        wordCount: words.length,
        sentenceCount: sentences.length,
        hasEmojis: /[\u{1F300}-\u{1F9FF}\u{2600}-\u{26FF}\u{2700}-\u{27BF}]/u.test(content),
        hasQuestion: /\?/.test(content),
        hasCallToAction: /comment|share|thoughts|opinion|let me know|what do you think|agree|disagree|reply|tell me|how do you|would you|have you|check out|click|join|follow|subscribe|dm|message/i.test(content),
        hasNumbers: /\d+/.test(content),
        hasStructure: (content.match(/\n/g) || []).length >= 1,
        hasBulletPoints: /^[\-•✓→✅❌📌🔹]/m.test(content) || /\n[\-•✓→✅❌📌🔹]/m.test(content),
        lineBreaks: (content.match(/\n/g) || []).length,
        recommendations: []
    };

    // Base score for having content (35 points)
    analysis.score += 35;
    
    // Length scoring (25 points) - more lenient
    if (analysis.length >= 100) {
        analysis.score += 25; // Good length
    } else if (analysis.length >= 50) {
        analysis.score += 20; // Acceptable length
    } else if (analysis.length >= 20) {
        analysis.score += 10; // Short but ok
    }
    
    // Emojis (15 points) - important for engagement
    if (analysis.hasEmojis) {
        analysis.score += 15;
    }
    
    // Formatting (10 points)
    if (analysis.hasStructure || analysis.lineBreaks >= 1) {
        analysis.score += 10;
    }
    
    // Engagement elements (10 points)
    if (analysis.hasQuestion || analysis.hasCallToAction) {
        analysis.score += 10;
    }
    
    // Bonus points (5 points)
    if (analysis.hasBulletPoints) analysis.score += 3;
    if (analysis.hasNumbers) analysis.score += 2;

    // Cap at 100
    analysis.score = Math.min(100, analysis.score);

    // Generate only actionable recommendations (max 2)
    if (analysis.score >= 85) {
        analysis.recommendations.push('✨ Excellent post! Ready to publish');
    } else {
        // Only show most impactful recommendations
        if (!analysis.hasEmojis && analysis.score < 90) {
            analysis.recommendations.push('😊 Add 1-2 emojis for visual appeal (+15 points)');
        }
        if (analysis.length < 100 && analysis.score < 90) {
            analysis.recommendations.push('📝 Add more content for better engagement (+25 points)');
        }
        
        // Limit to 2 recommendations max
        if (analysis.recommendations.length === 0) {
            analysis.recommendations.push('✅ Your post is good to go!');
        }
    }

    // Display analysis with color-coded score
    const scoreColor = analysis.score >= 85 ? '#28a745' : analysis.score >= 70 ? '#ffc107' : analysis.score >= 50 ? '#fd7e14' : '#dc3545';
    elements.engagementScore.textContent = analysis.score;
    elements.engagementScore.style.color = scoreColor;
    
    elements.postRecommendations.innerHTML = analysis.recommendations.length > 0
        ? '<ul style="margin: 0; padding-left: 16px; font-size: 11px;">' + analysis.recommendations.map(r => `<li style="margin-bottom: 4px;">${r}</li>`).join('') + '</ul>'
        : '<p style="color: green; margin: 0;">✓ Your post looks great!</p>';
    elements.postAnalysis.style.display = 'block';
}

async function copyPost() {
    const content = elements.postContent.value;
    if (!content) {
        alert('No content to copy');
        return;
    }

    try {
        await navigator.clipboard.writeText(content);
        elements.copyPost.textContent = '✓ Copied!';
        setTimeout(() => {
            elements.copyPost.textContent = '📋 Copy';
        }, 2000);
    } catch (error) {
        alert('Failed to copy. Please copy manually.');
    }
}

async function saveDraft() {
    const content = elements.postContent.value.trim();
    if (!content) {
        alert('No content to save');
        return;
    }

    const drafts = await chrome.storage.local.get('postDrafts');
    const draftsList = drafts.postDrafts || [];

    draftsList.push({
        id: Date.now(),
        content,
        createdAt: new Date().toISOString()
    });

    await chrome.storage.local.set({ postDrafts: draftsList });
    alert('Draft saved successfully!');
    loadDrafts();
}

async function loadDrafts() {
    try {
        const drafts = await chrome.storage.local.get('postDrafts');
        const draftsList = drafts.postDrafts || [];

        if (elements.draftCount) {
            elements.draftCount.textContent = draftsList.length;
        }

        if (draftsList.length > 0 && elements.draftsList) {
            elements.draftsList.innerHTML = draftsList.map(draft => {
                const date = new Date(draft.createdAt).toLocaleString('en-US', { 
                    month: 'short', day: 'numeric', year: 'numeric', 
                    hour: '2-digit', minute: '2-digit' 
                });
                const preview = draft.content.substring(0, 100) + (draft.content.length > 100 ? '...' : '');
                return `
                    <div style="padding: 12px; margin-bottom: 10px; background: white; border: 1px solid #e0e0e0; border-radius: 8px; border-left: 4px solid #693fe9;">
                        <div style="display: flex; justify-content: space-between; align-items: start; gap: 10px;">
                            <div style="flex: 1; min-width: 0;">
                                <div style="font-size: 13px; color: #444; margin-bottom: 6px; line-height: 1.4; word-wrap: break-word;">${preview}</div>
                                <div style="font-size: 11px; color: #999;">📅 ${date}</div>
                            </div>
                            <div style="display: flex; gap: 6px; flex-shrink: 0;">
                                <button class="content-item-action" data-draft-id="${draft.id}" data-action="load" 
                                        style="padding: 6px 12px; background: #693fe9; color: white; border: none; border-radius: 5px; font-size: 11px; cursor: pointer; font-weight: 600;">
                                    Load
                                </button>
                                <button class="content-item-action" data-draft-id="${draft.id}" data-action="delete" 
                                        style="padding: 6px 12px; background: #dc3545; color: white; border: none; border-radius: 5px; font-size: 11px; cursor: pointer; font-weight: 600;">
                                    Delete
                                </button>
                            </div>
                        </div>
                    </div>
                `;
            }).join('');

            // Add event listeners to buttons
            elements.draftsList.querySelectorAll('.content-item-action').forEach(btn => {
                btn.addEventListener('click', async () => {
                    const id = parseInt(btn.dataset.draftId);
                    const action = btn.dataset.action;

                    if (action === 'load') {
                        await loadDraft(id);
                    } else if (action === 'delete') {
                        await deleteDraft(id);
                    }
                });
            });
        } else if (elements.draftsList) {
            elements.draftsList.innerHTML = '<p class="empty-state">No saved drafts</p>';
        }
    } catch (error) {
        console.error('Error loading drafts:', error);
    }
}

async function loadDraft(id) {
    const drafts = await chrome.storage.local.get('postDrafts');
    const draftsList = drafts.postDrafts || [];
    const draft = draftsList.find(d => d.id === id);

    if (draft && elements.postContent) {
        elements.postContent.value = draft.content;
        alert('Draft loaded! You can now edit or post it.');
    }
}

async function deleteDraft(id) {
    if (!confirm('Delete this draft?')) return;

    const drafts = await chrome.storage.local.get('postDrafts');
    const draftsList = drafts.postDrafts || [];
    const updated = draftsList.filter(d => d.id !== id);
    await chrome.storage.local.set({ postDrafts: updated });
    loadDrafts();
}

async function postToLinkedIn() {
    // Check if processing is active
    const processingType = await checkProcessingActive();
    if (processingType) {
        showProcessingDisclaimer(processingType);
        return;
    }
    
    const content = elements.postContent.value.trim();
    if (!content) {
        alert('No content to post');
        return;
    }

    // Disable button and show loading state
    elements.postToLinkedIn.disabled = true;
    elements.postToLinkedIn.textContent = '⏳ Posting...';

    try {
        // Send message to background to post
        const response = await chrome.runtime.sendMessage({
            action: 'postToLinkedIn',
            content: content
        });

        if (response && response.success) {
            alert('Post published successfully!');
            elements.postContent.value = ''; // Clear content
            if (elements.postScheduleDatetime) elements.postScheduleDatetime.value = ''; // Clear schedule
        } else {
            alert('Failed to post. Please try manually.');
        }
    } catch (error) {
        console.error('Error posting:', error);
        alert('Error posting to LinkedIn. Please try manually.');
    } finally {
        elements.postToLinkedIn.disabled = false;
        elements.postToLinkedIn.textContent = '🚀 Post to LinkedIn';
    }
}

async function generateTopicLines() {
    // Check if processing is active
    const processingType = await checkProcessingActive();
    if (processingType) {
        showProcessingDisclaimer(processingType);
        return;
    }
    
    // Check if AI topic lines is allowed in user's plan
    const canUseAiTopics = await featureChecker.checkFeature('aiTopicLines');
    if (!canUseAiTopics) {
        showToast('⬆️ AI Topic Lines requires a paid plan. Please upgrade!', 'error');
        const planModal = document.getElementById('plan-modal');
        if (planModal) {
            planModal.style.display = 'flex';
            loadPlans();
        }
        return;
    }
    
    const topic = elements.postTopic.value.trim();
    if (!topic) {
        alert('Please enter a topic or general idea first');
        return;
    }

    // Show loading state
    elements.generateTopicLines.disabled = true;
    elements.generateTopicLines.textContent = '⏳ Generating...';
    elements.topicLinesList.innerHTML = '<p style="color: #666; padding: 10px;">AI is generating topic lines...</p>';
    elements.topicLinesContainer.style.display = 'block';

    try {
        // Send message to background to generate topic lines using AI
        const response = await chrome.runtime.sendMessage({
            action: 'generateTopicLines',
            topic
        });

        if (response.success && response.topics && response.topics.length > 0) {
            // Display AI-generated topic lines as clickable options
            elements.topicLinesList.innerHTML = '';
            response.topics.forEach((topicLine, index) => {
                const topicDiv = document.createElement('div');
                topicDiv.style.cssText = 'padding: 10px; margin: 5px 0; border: 1px solid #693fe9; border-radius: 5px; cursor: pointer; transition: all 0.2s; background-color: #FEFEFF;';
                topicDiv.innerHTML = `<strong style="color: #693fe9;">${index + 1}.</strong> ${topicLine}`;

                // Hover effect
                topicDiv.onmouseover = () => {
                    topicDiv.style.backgroundColor = '#693fe9';
                    topicDiv.style.color = '#FEFEFF';
                };
                topicDiv.onmouseout = () => {
                    topicDiv.style.backgroundColor = '#FEFEFF';
                    topicDiv.style.color = '#010100';
                };

                // Click to select
                topicDiv.onclick = () => {
                    elements.postTopic.value = topicLine;
                    elements.topicLinesContainer.style.display = 'none';
                    showToast('Topic selected! You can now generate your post.');
                };

                elements.topicLinesList.appendChild(topicDiv);
            });
        } else {
            const errorMessage = response.error || 'Failed to generate topic lines. Please try again.';
            elements.topicLinesList.innerHTML = `<p style="color: #dc3545; padding: 10px;">${errorMessage}</p>`;
        }
    } catch (error) {
        console.error('Error generating topic lines:', error);
        elements.topicLinesList.innerHTML = `
                <div style="color: #dc3545; padding: 15px; background: #ffe6e6; border-radius: 5px; border-left: 4px solid #dc3545;">
                    <strong>⚠️ Database Connection Error</strong><br>
                    <small>The backend database is currently unavailable. This is a known issue with the serverless database.</small><br>
                    <small style="margin-top: 8px; display: block;"><strong>Temporary Solution:</strong> Try again in a few minutes or contact support.</small>
                </div>
            `;
    } finally {
        elements.generateTopicLines.disabled = false;
        elements.generateTopicLines.textContent = '✨ Generate Topic Lines';
    }
}

// Character counter functionality
function updateCharacterCount() {
    const postContent = document.getElementById('post-content');
    const charCountEl = document.getElementById('char-count');
    
    if (postContent && charCountEl) {
        const currentLength = postContent.value.length;
        const maxLength = 3000;
        charCountEl.textContent = `${currentLength} / ${maxLength} characters`;
        
        // Change color based on usage
        if (currentLength > maxLength * 0.9) {
            charCountEl.style.color = '#dc3545'; // Red when near limit
        } else if (currentLength > maxLength * 0.7) {
            charCountEl.style.color = '#ffc107'; // Yellow when getting close
        } else {
            charCountEl.style.color = '#6c757d'; // Default gray
        }
    }
}

// Initialize character counter when post writer is loaded
function initializeCharacterCounter() {
    const postContent = document.getElementById('post-content');
    if (postContent) {
        // Update on input
        postContent.addEventListener('input', updateCharacterCount);
        postContent.addEventListener('paste', () => {
            // Update after paste event completes
            setTimeout(updateCharacterCount, 10);
        });
        
        // Initial update
        updateCharacterCount();
    }
}

// Credits Service for Import Tab
class CreditsService {
    constructor() {
        this.baseUrl = 'https://kommentify.com/api';
    }

    /**
     * Get import credits status for current user
     */
    async getImportCredits() {
        try {
            const token = await this.getAuthToken();
            if (!token) {
                throw new Error('Authentication required');
            }

            const response = await fetch(`${this.baseUrl}/usage/import-credits`, {
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                }
            });

            const data = await response.json();
            if (!data.success) {
                throw new Error(data.error || 'Failed to get credits');
            }

            console.log('📊 CREDITS: Current status:', data.credits);
            return data.credits;
        } catch (error) {
            console.error('❌ CREDITS: Failed to get credits:', error);
            throw error;
        }
    }

    /**
     * Check if user has enough credits for import processing
     * @param {number} profileCount - Number of profiles to process
     */
    async checkCreditsAvailable(profileCount = 1) {
        try {
            const credits = await this.getImportCredits();
            return {
                hasCredits: credits.remaining >= profileCount,
                remaining: credits.remaining,
                needed: profileCount,
                total: credits.total,
                used: credits.used
            };
        } catch (error) {
            console.error('❌ CREDITS: Failed to check credits:', error);
            return {
                hasCredits: false,
                remaining: 0,
                needed: profileCount,
                error: error.message
            };
        }
    }

    /**
     * Track import profile usage (increment by 1)
     */
    async trackImportUsage() {
        try {
            const token = await this.getAuthToken();
            if (!token) {
                throw new Error('Authentication required');
            }

            const response = await fetch(`${this.baseUrl}/usage/track`, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    actionType: 'importProfile'
                })
            });

            const data = await response.json();
            if (!data.success) {
                throw new Error(data.error || 'Failed to track usage');
            }

            console.log('✅ CREDITS: Import usage tracked, remaining credits:', data.usage.importProfiles);
            return data;
        } catch (error) {
            console.error('❌ CREDITS: Failed to track usage:', error);
            throw error;
        }
    }

    /**
     * Get authentication token from storage
     */
    async getAuthToken() {
        return new Promise(async (resolve) => {
            // Try local storage first
            chrome.storage.local.get(['authToken'], (localResult) => {
                if (localResult.authToken) {
                    resolve(localResult.authToken);
                } else {
                    // Fallback to sync storage
                    chrome.storage.sync.get(['authToken'], (syncResult) => {
                        resolve(syncResult.authToken || null);
                    });
                }
            });
        });
    }

    /**
     * Update UI with credits information
     */
    updateCreditsUI(credits) {
        try {
            const remainingEl = document.getElementById('import-credits-remaining');
            const totalEl = document.getElementById('import-credits-total');
            const usedEl = document.getElementById('import-credits-used');
            const planEl = document.getElementById('import-plan-name');

            if (remainingEl) remainingEl.textContent = credits.remaining || '0';
            if (totalEl) totalEl.textContent = credits.total || '0';
            if (usedEl) usedEl.textContent = credits.used || '0';
            if (planEl) planEl.textContent = credits.planName || 'Free';

            // Update colors based on remaining credits
            if (remainingEl) {
                if (credits.remaining <= 0) {
                    remainingEl.style.color = '#f44336'; // Red
                } else if (credits.remaining <= 5) {
                    remainingEl.style.color = '#ff9800'; // Orange
                } else {
                    remainingEl.style.color = '#4caf50'; // Green
                }
            }
        } catch (error) {
            console.error('❌ CREDITS: Failed to update UI:', error);
        }
    }
}

/**
 * Status Logger Module
 * Manages status bar updates for automation, networking, and import tabs
 * Shows waiting/delay logs to keep users informed
 */

// Status bar configuration for each tab
const statusBars = {
    automation: {
        bar: 'automation-status-bar',
        icon: 'automation-status-icon',
        text: 'automation-status-text',
        timer: 'automation-status-timer'
    },
    networking: {
        bar: 'networking-status-bar',
        icon: 'networking-status-icon',
        text: 'networking-status-text',
        timer: 'networking-status-timer'
    },
    import: {
        bar: 'import-status-bar',
        icon: 'import-status-icon',
        text: 'import-status-text',
        timer: 'import-status-timer'
    }
};

// Countdown interval storage
const countdownIntervals = {
    automation: null,
    networking: null,
    import: null
};

/**
 * Show status bar for a specific tab
 */
function showStatusBar(tab, message, icon = '🔄') {
    const config = statusBars[tab];
    if (!config) return;
    
    const barEl = document.getElementById(config.bar);
    const iconEl = document.getElementById(config.icon);
    const textEl = document.getElementById(config.text);
    
    if (barEl) {
        barEl.style.display = 'flex';
    }
    if (iconEl) {
        iconEl.textContent = icon;
    }
    if (textEl) {
        textEl.textContent = message;
    }
}

/**
 * Hide status bar for a specific tab
 */
function hideStatusBar(tab) {
    const config = statusBars[tab];
    if (!config) return;
    
    const barEl = document.getElementById(config.bar);
    if (barEl) {
        barEl.style.display = 'none';
    }
    
    // Clear any countdown
    clearCountdown(tab);
}

/**
 * Show waiting/delay countdown
 */
function showWaitingCountdown(tab, seconds, message) {
    const config = statusBars[tab];
    if (!config) return;
    
    // Show the status bar
    showStatusBar(tab, message, '⏳');
    
    // Clear any existing countdown
    clearCountdown(tab);
    
    let remainingSeconds = seconds;
    const timerEl = document.getElementById(config.timer);
    
    // Update timer display
    const updateTimer = () => {
        if (timerEl) {
            const mins = Math.floor(remainingSeconds / 60);
            const secs = remainingSeconds % 60;
            timerEl.textContent = `${mins}:${secs.toString().padStart(2, '0')}`;
        }
    };
    
    updateTimer();
    
    // Start countdown
    countdownIntervals[tab] = setInterval(() => {
        remainingSeconds--;
        updateTimer();
        
        if (remainingSeconds <= 0) {
            clearCountdown(tab);
            if (timerEl) timerEl.textContent = '';
        }
    }, 1000);
}

/**
 * Clear countdown for a tab
 */
function clearCountdown(tab) {
    if (countdownIntervals[tab]) {
        clearInterval(countdownIntervals[tab]);
        countdownIntervals[tab] = null;
    }
    
    const config = statusBars[tab];
    if (config) {
        const timerEl = document.getElementById(config.timer);
        if (timerEl) timerEl.textContent = '';
    }
}

/**
 * Log status with predefined types
 */
function logStatus(tab, type, details = {}) {
    const messages = {
        // General
        'starting': { icon: '🚀', text: 'Starting process...' },
        'stopped': { icon: '🛑', text: 'Process stopped' },
        'completed': { icon: '✅', text: 'Process completed!' },
        'error': { icon: '❌', text: `Error: ${details.message || 'Unknown error'}` },
        
        // Automation specific
        'scraping-posts': { icon: '🔍', text: `Scraping posts... Found ${details.count || 0}` },
        'filtering-posts': { icon: '🔬', text: 'Filtering posts by keywords...' },
        'processing-post': { icon: '📝', text: `Processing post ${details.current || 0}/${details.total || 0}` },
        'generating-comment': { icon: '🤖', text: 'Generating AI comment...' },
        'posting-comment': { icon: '💬', text: 'Posting comment...' },
        'liking-post': { icon: '❤️', text: 'Liking post...' },
        'sharing-post': { icon: '📤', text: 'Sharing post...' },
        'following-author': { icon: '👥', text: 'Following author...' },
        
        // Networking specific
        'searching-profiles': { icon: '🔍', text: `Searching profiles... Found ${details.count || 0}` },
        'filtering-profiles': { icon: '🔬', text: 'Filtering profiles...' },
        'processing-profile': { icon: '👤', text: `Processing profile ${details.current || 0}/${details.total || 0}` },
        'sending-connection': { icon: '🤝', text: `Sending connection to ${details.name || 'profile'}...` },
        'extracting-info': { icon: '📧', text: 'Extracting contact info...' },
        
        // Import specific
        'loading-profiles': { icon: '📂', text: `Loading ${details.count || 0} profiles...` },
        'validating-urls': { icon: '🔗', text: 'Validating profile URLs...' },
        'opening-profile': { icon: '🔓', text: `Opening profile ${details.current || 0}/${details.total || 0}` },
        'engaging-profile': { icon: '💫', text: `Engaging with ${details.name || 'profile'}...` },
        
        // Waiting messages
        'waiting-page-load': { icon: '⏳', text: 'Waiting for page to load...' },
        'waiting-action-delay': { icon: '⏳', text: `Waiting ${details.seconds || 0}s (human-like delay)...` },
        'waiting-before-next': { icon: '⏳', text: 'Waiting before next action...' },
        'waiting-scroll': { icon: '📜', text: 'Scrolling to load more...' },
        'waiting-rate-limit': { icon: '⚠️', text: `Rate limit - waiting ${details.seconds || 60}s...` },
        'waiting-cooldown': { icon: '❄️', text: `Cooling down... ${details.seconds || 0}s remaining` }
    };
    
    const msg = messages[type] || { icon: '📌', text: type };
    showStatusBar(tab, msg.text, msg.icon);
    
    // If it's a waiting message with seconds, show countdown
    if (type.startsWith('waiting-') && details.seconds) {
        showWaitingCountdown(tab, details.seconds, msg.text);
    }
    
    // Log to console for debugging
    console.log(`[${tab.toUpperCase()}] ${msg.icon} ${msg.text}`);
}

/**
 * Initialize status logger - listen for messages from content scripts
 */
function initializeStatusLogger() {
    // Listen for status updates from chrome.runtime messages
    chrome.runtime?.onMessage?.addListener((request, sender, sendResponse) => {
        if (request.action === 'updateTabStatus') {
            const { tab, type, details } = request;
            logStatus(tab, type, details);
            sendResponse({ success: true });
        }
        return true;
    });
    
    console.log('📊 Status Logger initialized');
}

/**
 * Check if daily limit is reached for a specific action type
 * @param {string} actionType - 'comments', 'likes', 'shares', 'follows', 'connections'
 * @returns {Object} { canProceed: boolean, used: number, limit: number, remaining: number }
 */
async function checkDailyLimit(actionType) {
    try {
        const storage = await chrome.storage.local.get(['dailyLimits', 'engagementStatistics']);
        const dailyLimits = storage.dailyLimits || {
            comments: 30,
            likes: 60,
            shares: 15,
            follows: 30,
            connections: 50
        };
        
        // Get today's usage
        const now = new Date();
        const dateKey = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
        const todayStats = storage.engagementStatistics?.dailyStats?.[dateKey] || {};
        
        const limit = dailyLimits[actionType] || 999;
        const used = todayStats[actionType] || 0;
        const remaining = Math.max(0, limit - used);
        const canProceed = used < limit;
        
        console.log(`📊 LIMITS: ${actionType} - Used: ${used}/${limit}, Remaining: ${remaining}, Can proceed: ${canProceed}`);
        
        return { canProceed, used, limit, remaining };
    } catch (error) {
        console.error('Error checking daily limit:', error);
        return { canProceed: true, used: 0, limit: 999, remaining: 999 };
    }
}

/**
 * Check all daily limits and return status
 * @returns {Object} Status of all limits
 */
async function checkAllDailyLimits() {
    const comments = await checkDailyLimit('comments');
    const likes = await checkDailyLimit('likes');
    const shares = await checkDailyLimit('shares');
    const follows = await checkDailyLimit('follows');
    const connections = await checkDailyLimit('connections');
    
    return {
        comments,
        likes,
        shares,
        follows,
        connections,
        anyLimitReached: !comments.canProceed || !likes.canProceed || !shares.canProceed || !follows.canProceed || !connections.canProceed
    };
}

/**
 * Get remaining actions before limits are reached
 * @returns {Object} Remaining counts for each action type
 */
async function getRemainingActions() {
    const limits = await checkAllDailyLimits();
    return {
        comments: limits.comments.remaining,
        likes: limits.likes.remaining,
        shares: limits.shares.remaining,
        follows: limits.follows.remaining,
        connections: limits.connections.remaining
    };
}

async function loadDailyLimits() {
    try {
        console.log('⚙️ LIMITS: Loading daily limits...');

        // Get auth token
        const storage = await chrome.storage.local.get(['authToken', 'apiBaseUrl', 'accountType', 'accountLimits', 'commentDelay']);
        const token = storage.authToken;
        const apiUrl = storage.apiBaseUrl || API_CONFIG.BASE_URL;

        const accountType = storage.accountType || 'matured';
        const accountLimits = storage.accountLimits || { comments: 150, likes: Infinity, shares: Infinity, follows: Infinity };
        const commentDelay = storage.commentDelay || { base: 180, randomMin: 1, randomMax: 60 };

        // Set dropdown values
        if (elements.accountType) elements.accountType.value = accountType;
        if (elements.commentDelay) {
            elements.commentDelay.value = commentDelay.base.toString();
        }

        let counts = { comments: 0, likes: 0, shares: 0, follows: 0 };
        let limits = accountLimits;

        if (token) {
            try {
                // Fetch daily usage from backend
                const response = await fetch(`${apiUrl}/api/usage/daily`, {
                    method: 'GET',
                    headers: {
                        'Authorization': `Bearer ${token}`
                    }
                });

                if (response.ok) {
                    const data = await response.json();
                    if (data.success) {
                        counts = data.usage || counts;
                        // Backend limits might be different from local accountLimits preference
                        // We can display backend limits or local preference. 
                        // The UI seems to want to show "Limit: X". 
                        // Let's use the backend limits if available as they are the hard limits.
                        if (data.limits) {
                            limits = data.limits;
                        }
                    }
                }
            } catch (apiError) {
                console.error('Error fetching limits from API:', apiError);
            }
        } else {
            // Fallback to local storage if not logged in (legacy support or just show zeros)
            const localData = await chrome.storage.local.get('dailyCounts');
            if (localData.dailyCounts) {
                counts = localData.dailyCounts;
            }
        }

        // Update limits display - show AI comments instead of normal comments
        const aiCommentsUsed = counts.aiComments || 0;
        const aiCommentsLimit = limits.aiComments || 0;
        const bonusAiComments = counts.bonusAiComments || 0;
        const totalAiCommentsAvailable = aiCommentsLimit + bonusAiComments;

        if (elements.limitComments) elements.limitComments.textContent = `${aiCommentsUsed}/${totalAiCommentsAvailable}`;
        if (elements.limitLikes) elements.limitLikes.textContent = `${counts.likes}/${limits.likes === Infinity ? '∞' : limits.likes}`;
        if (elements.limitShares) elements.limitShares.textContent = `${counts.shares}/${limits.shares === Infinity ? '∞' : limits.shares}`;
        if (elements.limitFollows) elements.limitFollows.textContent = `${counts.follows}/${limits.follows === Infinity ? '∞' : limits.follows}`;

    } catch (error) {
        console.error('Error loading limits:', error);
    }
}

// --- LIMITS SETTINGS FUNCTIONS ---

/**
 * Update random interval display for dropdowns
 */
function updateRandomIntervalDisplay(selectId) {
    const select = document.getElementById(selectId);
    const displayId = `${selectId}-display`;
    const display = document.getElementById(displayId);
    
    if (!select || !display) return;
    
    const value = parseInt(select.value);
    
    if (value === 0) {
        display.textContent = 'Off';
    } else if (value < 60) {
        display.textContent = `${value}s`;
    } else {
        const minutes = Math.floor(value / 60);
        display.textContent = `${minutes}m`;
    }
}

/**
 * Update delay display for sliders
 */
function updateDelayDisplay(sliderId) {
    const slider = document.getElementById(sliderId);
    const display = document.getElementById(`${sliderId}-display`);

    if (!slider || !display) return;

    const value = parseInt(slider.value);

    // Format display based on value
    if (value < 60) {
        display.textContent = `${value}s`;
    } else if (value < 3600) {
        const minutes = Math.floor(value / 60);
        const seconds = value % 60;
        display.textContent = seconds > 0 ? `${minutes}m ${seconds}s` : `${minutes}m`;
    } else {
        const hours = Math.floor(value / 3600);
        const minutes = Math.floor((value % 3600) / 60);
        display.textContent = minutes > 0 ? `${hours}h ${minutes}m` : `${hours}h`;
    }
}

/**
 * Load limits settings from storage
 */
async function loadLimitsSettings() {
    try {
        console.log('⚙️ LIMITS: Loading limits settings...');

        const result = await chrome.storage.local.get([
            'delaySettings',
            'automationPreferences',
            'humanSimulation',
            'dailyLimits',
            'randomIntervalSettings',
            'user',
            'limitsPresetApplied'
        ]);
        
        // Apply default preset for new users if not already applied
        if (!result.limitsPresetApplied) {
            console.log('⚙️ LIMITS: First time user - applying default matured-safe preset');
            // Mark as applied to avoid reapplying on every load
            await chrome.storage.local.set({ limitsPresetApplied: true, accountPreset: 'matured-safe' });
            // Apply the preset after a short delay to ensure DOM is ready
            setTimeout(() => {
                const accountTypeSelect = document.getElementById('account-type');
                if (accountTypeSelect) {
                    accountTypeSelect.value = 'matured-safe';
                }
                applyAccountPreset('matured-safe');
            }, 100);
        } else {
            // Load saved preset selection
            const savedPreset = await chrome.storage.local.get('accountPreset');
            if (savedPreset.accountPreset) {
                const accountTypeSelect = document.getElementById('account-type');
                if (accountTypeSelect) {
                    accountTypeSelect.value = savedPreset.accountPreset;
                }
            }
        }

        const delaySettings = result.delaySettings || {
            automationStartDelay: 0,
            networkingStartDelay: 0,
            searchMinDelay: 30,
            searchMaxDelay: 60,
            commentMinDelay: 60,
            commentMaxDelay: 180,
            networkingMinDelay: 30,
            networkingMaxDelay: 60,
            beforeOpeningPostsDelay: 5,
            postPageLoadDelay: 3,
            beforeLikeDelay: 2,
            beforeCommentDelay: 3,
            beforeShareDelay: 2,
            beforeFollowDelay: 2,
            postWriterPageLoadDelay: 3,
            postWriterClickDelay: 2,
            postWriterTypingDelay: 2,
            postWriterSubmitDelay: 3,
            baseDelay: 5,
            taskInitDelay: 0
        };

        const automationPreferences = result.automationPreferences || {
            openSearchInWindow: true
        };

        const humanSimulation = result.humanSimulation || {
            mouseMovement: true,
            scrolling: true,
            readingPause: true
        };

        // Set starting delays
        const automationStartDelay = document.getElementById('automation-start-delay');
        if (automationStartDelay) automationStartDelay.value = delaySettings.automationStartDelay;

        const networkingStartDelay = document.getElementById('networking-start-delay');
        if (networkingStartDelay) networkingStartDelay.value = delaySettings.networkingStartDelay;

        const importStartDelay = document.getElementById('import-start-delay');
        if (importStartDelay) importStartDelay.value = delaySettings.importStartDelay;

        // Set delay sliders
        const searchDelayMin = document.getElementById('search-delay-min');
        if (searchDelayMin) searchDelayMin.value = delaySettings.searchMinDelay;

        const searchDelayMax = document.getElementById('search-delay-max');
        if (searchDelayMax) searchDelayMax.value = delaySettings.searchMaxDelay;

        const commentDelayMin = document.getElementById('comment-delay-min');
        if (commentDelayMin) commentDelayMin.value = delaySettings.commentMinDelay;

        const commentDelayMax = document.getElementById('comment-delay-max');
        if (commentDelayMax) commentDelayMax.value = delaySettings.commentMaxDelay;

        const networkingDelayMin = document.getElementById('networking-delay-min');
        if (networkingDelayMin) networkingDelayMin.value = delaySettings.networkingMinDelay;

        const networkingDelayMax = document.getElementById('networking-delay-max');
        if (networkingDelayMax) networkingDelayMax.value = delaySettings.networkingMaxDelay;

        // Set post action delays
        const beforeOpeningPostsDelay = document.getElementById('before-opening-posts-delay');
        if (beforeOpeningPostsDelay) beforeOpeningPostsDelay.value = delaySettings.beforeOpeningPostsDelay;

        const postPageLoadDelay = document.getElementById('post-page-load-delay');
        if (postPageLoadDelay) postPageLoadDelay.value = delaySettings.postPageLoadDelay;

        const beforeLikeDelay = document.getElementById('before-like-delay');
        if (beforeLikeDelay) beforeLikeDelay.value = delaySettings.beforeLikeDelay;

        const beforeCommentDelay = document.getElementById('before-comment-delay');
        if (beforeCommentDelay) beforeCommentDelay.value = delaySettings.beforeCommentDelay;

        const beforeShareDelay = document.getElementById('before-share-delay');
        if (beforeShareDelay) beforeShareDelay.value = delaySettings.beforeShareDelay;

        const beforeFollowDelay = document.getElementById('before-follow-delay');
        if (beforeFollowDelay) beforeFollowDelay.value = delaySettings.beforeFollowDelay;

        // Set post writer delays
        const postWriterPageLoadDelay = document.getElementById('post-writer-page-load-delay');
        if (postWriterPageLoadDelay) postWriterPageLoadDelay.value = delaySettings.postWriterPageLoadDelay;

        const postWriterClickDelay = document.getElementById('post-writer-click-delay');
        if (postWriterClickDelay) postWriterClickDelay.value = delaySettings.postWriterClickDelay;

        const postWriterTypingDelay = document.getElementById('post-writer-typing-delay');
        if (postWriterTypingDelay) postWriterTypingDelay.value = delaySettings.postWriterTypingDelay;

        const postWriterSubmitDelay = document.getElementById('post-writer-submit-delay');
        if (postWriterSubmitDelay) postWriterSubmitDelay.value = delaySettings.postWriterSubmitDelay;

        // Update displays for all delay sliders
        updateDelayDisplay('search-delay-min');
        updateDelayDisplay('search-delay-max');
        updateDelayDisplay('comment-delay-min');
        updateDelayDisplay('comment-delay-max');
        updateDelayDisplay('networking-delay-min');
        updateDelayDisplay('networking-delay-max');
        updateDelayDisplay('automation-start-delay');
        updateDelayDisplay('networking-start-delay');
        updateDelayDisplay('import-start-delay');
        updateDelayDisplay('post-writer-page-load-delay');
        updateDelayDisplay('post-writer-click-delay');
        updateDelayDisplay('post-writer-typing-delay');
        updateDelayDisplay('post-writer-submit-delay');
        updateDelayDisplay('before-opening-posts-delay');
        updateDelayDisplay('post-page-load-delay');
        updateDelayDisplay('before-like-delay');
        updateDelayDisplay('before-comment-delay');
        updateDelayDisplay('before-share-delay');
        updateDelayDisplay('before-follow-delay');
        
        // Update daily limit displays
        const dailyLimitInputs = ['daily-comment-limit-input', 'daily-like-limit-input', 'daily-share-limit-input', 'daily-follow-limit-input'];
        dailyLimitInputs.forEach(id => {
            const slider = document.getElementById(id);
            const displayId = id.replace('-input', '-display');
            const display = document.getElementById(displayId);
            if (slider && display) {
                display.textContent = slider.value;
            }
        });

        // Set automation preferences
        const openSearchInWindow = document.getElementById('open-search-in-window');
        if (openSearchInWindow) openSearchInWindow.checked = automationPreferences.openSearchInWindow;

        // Set human simulation
        const humanMouseMovement = document.getElementById('human-mouse-movement');
        if (humanMouseMovement) humanMouseMovement.checked = humanSimulation.mouseMovement;

        const humanScrolling = document.getElementById('human-scrolling');
        if (humanScrolling) humanScrolling.checked = humanSimulation.scrolling;

        const humanReadingPause = document.getElementById('human-reading-pause');
        if (humanReadingPause) humanReadingPause.checked = humanSimulation.readingPause;

        // Set random interval settings
        const randomIntervalSettings = result.randomIntervalSettings || {
            minInterval: 30,
            maxInterval: 60
        };

        const randomIntervalMin = document.getElementById('random-interval-min');
        if (randomIntervalMin) {
            randomIntervalMin.value = randomIntervalSettings.minInterval;
            updateRandomIntervalDisplay('random-interval-min');
        }

        const randomIntervalMax = document.getElementById('random-interval-max');
        if (randomIntervalMax) {
            randomIntervalMax.value = randomIntervalSettings.maxInterval;
            updateRandomIntervalDisplay('random-interval-max');
        }

        // Set daily limits
        const dailyLimits = result.dailyLimits || {
            comments: 50,
            likes: 100,
            shares: 20,
            follows: 50
        };

        const dailyCommentLimitInput = document.getElementById('daily-comment-limit-input');
        if (dailyCommentLimitInput) dailyCommentLimitInput.value = dailyLimits.comments;

        const dailyLikeLimitInput = document.getElementById('daily-like-limit-input');
        if (dailyLikeLimitInput) dailyLikeLimitInput.value = dailyLimits.likes;

        const dailyShareLimitInput = document.getElementById('daily-share-limit-input');
        if (dailyShareLimitInput) dailyShareLimitInput.value = dailyLimits.shares;

        const dailyFollowLimitInput = document.getElementById('daily-follow-limit-input');
        if (dailyFollowLimitInput) dailyFollowLimitInput.value = dailyLimits.follows;

        // Apply plan limit validation after setting values
        await applyPlanLimitValidation();

        console.log('✅ LIMITS: Settings loaded successfully');

    } catch (error) {
        console.error('❌ LIMITS: Error loading settings:', error);
    }
}

/**
 * Apply plan limit validation by fetching current user plan limits
 */
async function applyPlanLimitValidation() {
    try {
        const storage = await chrome.storage.local.get(['authToken', 'apiBaseUrl', 'userData']);
        const token = storage.authToken;
        const apiUrl = storage.apiBaseUrl || API_CONFIG.BASE_URL;
        const userData = storage.userData;

        if (!token || !userData) {
            console.log('LIMITS: No auth data, skipping plan validation');
            return;
        }

        // Fetch current plan limits from backend
        const response = await fetch(`${apiUrl}/api/usage/daily`, {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });

        if (response.ok) {
            const data = await response.json();
            if (data.success && data.limits) {
                // Update plan limit displays
                const maxCommentsSpan = document.getElementById('max-comments-plan');
                if (maxCommentsSpan) maxCommentsSpan.textContent = data.limits.comments || 50;
                
                const maxLikesSpan = document.getElementById('max-likes-plan');
                if (maxLikesSpan) maxLikesSpan.textContent = data.limits.likes || 100;
                
                const maxSharesSpan = document.getElementById('max-shares-plan');
                if (maxSharesSpan) maxSharesSpan.textContent = data.limits.shares || 20;
                
                const maxFollowsSpan = document.getElementById('max-follows-plan');
                if (maxFollowsSpan) maxFollowsSpan.textContent = data.limits.follows || 50;
                
                console.log('✅ LIMITS: Plan limits updated:', data.limits);
                
                // Call the plan limit enforcement directly
                window.enforcePlanLimitsGlobal?.(data.limits);
            }
        }
    } catch (error) {
        console.error('LIMITS: Error applying plan validation:', error);
    }
}

/**
 * Save limits settings to storage
 */
async function saveLimitsSettings() {
    try {
        console.log('💾 LIMITS: Saving limits settings...');

        const delaySettings = {
            automationStartDelay: parseInt(document.getElementById('automation-start-delay').value) || 0,
            networkingStartDelay: parseInt(document.getElementById('networking-start-delay').value) || 0,
            importStartDelay: parseInt(document.getElementById('import-start-delay').value) || 0,
            searchMinDelay: parseInt(document.getElementById('search-delay-min').value) || 30,
            searchMaxDelay: parseInt(document.getElementById('search-delay-max').value) || 60,
            commentMinDelay: parseInt(document.getElementById('comment-delay-min').value) || 60,
            commentMaxDelay: parseInt(document.getElementById('comment-delay-max').value) || 180,
            networkingMinDelay: parseInt(document.getElementById('networking-delay-min').value) || 30,
            networkingMaxDelay: parseInt(document.getElementById('networking-delay-max').value) || 60,
            beforeOpeningPostsDelay: parseInt(document.getElementById('before-opening-posts-delay').value) || 5,
            postPageLoadDelay: parseInt(document.getElementById('post-page-load-delay').value) || 3,
            beforeLikeDelay: parseInt(document.getElementById('before-like-delay').value) || 2,
            beforeCommentDelay: parseInt(document.getElementById('before-comment-delay').value) || 3,
            beforeShareDelay: parseInt(document.getElementById('before-share-delay').value) || 2,
            beforeFollowDelay: parseInt(document.getElementById('before-follow-delay').value) || 2,
            postWriterPageLoadDelay: parseInt(document.getElementById('post-writer-page-load-delay').value) || 3,
            postWriterClickDelay: parseInt(document.getElementById('post-writer-click-delay').value) || 2,
            postWriterTypingDelay: parseInt(document.getElementById('post-writer-typing-delay').value) || 2,
            postWriterSubmitDelay: parseInt(document.getElementById('post-writer-submit-delay').value) || 3,
            baseDelay: parseInt(document.getElementById('base-delay')?.value) || 5,
            taskInitDelay: parseInt(document.getElementById('task-init-delay')?.value) || 0
        };

        const automationPreferences = {
            openSearchInWindow: document.getElementById('open-search-in-window').checked
        };

        const humanSimulation = {
            mouseMovement: document.getElementById('human-mouse-movement').checked,
            scrolling: document.getElementById('human-scrolling').checked,
            readingPause: document.getElementById('human-reading-pause').checked
        };

        const dailyLimits = {
            comments: parseInt(document.getElementById('daily-comment-limit-input').value) || 50,
            likes: parseInt(document.getElementById('daily-like-limit-input').value) || 100,
            shares: parseInt(document.getElementById('daily-share-limit-input').value) || 20,
            follows: parseInt(document.getElementById('daily-follow-limit-input').value) || 50
        };

        const randomIntervalSettings = {
            minInterval: parseInt(document.getElementById('random-interval-min')?.value) || 30,
            maxInterval: parseInt(document.getElementById('random-interval-max')?.value) || 60
        };

        await chrome.storage.local.set({
            delaySettings,
            automationPreferences,
            humanSimulation,
            dailyLimits,
            randomIntervalSettings
        });

        // Settings saved silently (removed annoying popup)

    } catch (error) {
        console.error('❌ LIMITS: Error saving settings:', error);
        alert('Error saving settings');
    }
}

/**
 * Account Type Presets - LinkedIn-safe automation limits
 * Optimized for safety while minimizing user wait time
 */
const ACCOUNT_PRESETS = {
    'your-choice': null, // User's custom settings - don't change anything
    
    'new-conservative': {
        // For brand new accounts (0-2 weeks old) - Very cautious to build trust
        dailyLimits: { comments: 5, likes: 15, shares: 3, follows: 8 },
        startingDelays: { automation: 10, networking: 10, import: 10 },
        postWriterDelays: { pageLoad: 5, click: 2, typing: 2, submit: 3 },
        automationDelays: { searchMin: 45, searchMax: 90, commentMin: 60, commentMax: 120 },
        networkingDelays: { min: 60, max: 120 },
        postActionDelays: { opening: 3, page: 4, like: 2, comment: 3, share: 2, follow: 2 }
    },
    
    'new-moderate': {
        // For newer accounts (2-8 weeks old) - Building activity gradually
        dailyLimits: { comments: 15, likes: 35, shares: 8, follows: 18 },
        startingDelays: { automation: 5, networking: 5, import: 5 },
        postWriterDelays: { pageLoad: 4, click: 1, typing: 2, submit: 2 },
        automationDelays: { searchMin: 30, searchMax: 60, commentMin: 45, commentMax: 90 },
        networkingDelays: { min: 45, max: 90 },
        postActionDelays: { opening: 2, page: 3, like: 2, comment: 2, share: 2, follow: 2 }
    },
    
    'matured-safe': {
        // For established accounts (3+ months) - Safe daily use, optimized speed
        dailyLimits: { comments: 30, likes: 60, shares: 15, follows: 30 },
        startingDelays: { automation: 3, networking: 3, import: 3 },
        postWriterDelays: { pageLoad: 3, click: 1, typing: 1, submit: 2 },
        automationDelays: { searchMin: 15, searchMax: 30, commentMin: 25, commentMax: 60 },
        networkingDelays: { min: 30, max: 60 },
        postActionDelays: { opening: 2, page: 3, like: 1, comment: 2, share: 1, follow: 1 }
    },
    
    'matured-aggressive': {
        // For mature accounts (6+ months) - Higher activity, still safe
        dailyLimits: { comments: 50, likes: 100, shares: 25, follows: 50 },
        startingDelays: { automation: 2, networking: 2, import: 2 },
        postWriterDelays: { pageLoad: 3, click: 1, typing: 1, submit: 2 },
        automationDelays: { searchMin: 10, searchMax: 25, commentMin: 20, commentMax: 45 },
        networkingDelays: { min: 20, max: 45 },
        postActionDelays: { opening: 1, page: 3, like: 1, comment: 1, share: 1, follow: 1 }
    },
    
    'premium-user': {
        // For LinkedIn Premium users - Higher limits expected
        dailyLimits: { comments: 60, likes: 120, shares: 30, follows: 60 },
        startingDelays: { automation: 2, networking: 2, import: 2 },
        postWriterDelays: { pageLoad: 3, click: 1, typing: 1, submit: 2 },
        automationDelays: { searchMin: 10, searchMax: 20, commentMin: 15, commentMax: 35 },
        networkingDelays: { min: 15, max: 35 },
        postActionDelays: { opening: 1, page: 3, like: 1, comment: 1, share: 1, follow: 1 }
    },
    
    'sales-navigator': {
        // For Sales Navigator users - Professional high volume
        dailyLimits: { comments: 75, likes: 150, shares: 40, follows: 75 },
        startingDelays: { automation: 0, networking: 0, import: 0 },
        postWriterDelays: { pageLoad: 3, click: 1, typing: 1, submit: 2 },
        automationDelays: { searchMin: 8, searchMax: 18, commentMin: 12, commentMax: 30 },
        networkingDelays: { min: 12, max: 30 },
        postActionDelays: { opening: 1, page: 2, like: 1, comment: 1, share: 1, follow: 1 }
    },
    
    'speed-mode': {
        // Fast processing - Use at your own risk (minimal delays)
        dailyLimits: { comments: 100, likes: 200, shares: 50, follows: 100 },
        startingDelays: { automation: 0, networking: 0, import: 0 },
        postWriterDelays: { pageLoad: 2, click: 1, typing: 1, submit: 1 },
        automationDelays: { searchMin: 5, searchMax: 12, commentMin: 8, commentMax: 20 },
        networkingDelays: { min: 8, max: 20 },
        postActionDelays: { opening: 1, page: 2, like: 1, comment: 1, share: 1, follow: 1 }
    }
};

/**
 * Apply account type preset to all limit and delay sliders
 */
function applyAccountPreset(presetType) {
    const preset = ACCOUNT_PRESETS[presetType];
    
    // Save the selected preset
    chrome.storage.local.set({ accountPreset: presetType });
    
    if (!preset) {
        // "Your Choice" selected - don't change anything
        console.log('Custom preset selected - keeping user values');
        return;
    }
    
    console.log(`Applying preset: ${presetType}`, preset);
    
    // Helper function to update slider and display
    const updateSlider = (id, value, displayId) => {
        const slider = document.getElementById(id);
        const display = document.getElementById(displayId);
        if (slider) {
            slider.value = value;
            if (display) {
                display.textContent = value;
            }
            // Trigger display update for formatted values
            updateDelayDisplay(id);
        }
    };
    
    // 1. Update Daily Limits
    if (preset.dailyLimits) {
        updateSlider('daily-comment-limit-input', preset.dailyLimits.comments, 'daily-comment-limit-display');
        updateSlider('daily-like-limit-input', preset.dailyLimits.likes, 'daily-like-limit-display');
        updateSlider('daily-share-limit-input', preset.dailyLimits.shares, 'daily-share-limit-display');
        updateSlider('daily-follow-limit-input', preset.dailyLimits.follows, 'daily-follow-limit-display');
    }
    
    // 2. Update Starting Delays
    if (preset.startingDelays) {
        updateSlider('automation-start-delay', preset.startingDelays.automation, 'automation-start-delay-display');
        updateSlider('networking-start-delay', preset.startingDelays.networking, 'networking-start-delay-display');
        updateSlider('import-start-delay', preset.startingDelays.import, 'import-start-delay-display');
    }
    
    // 3. Update Post Writer Delays
    if (preset.postWriterDelays) {
        updateSlider('post-writer-page-load-delay', preset.postWriterDelays.pageLoad, 'post-writer-page-load-delay-display');
        updateSlider('post-writer-click-delay', preset.postWriterDelays.click, 'post-writer-click-delay-display');
        updateSlider('post-writer-typing-delay', preset.postWriterDelays.typing, 'post-writer-typing-delay-display');
        updateSlider('post-writer-submit-delay', preset.postWriterDelays.submit, 'post-writer-submit-delay-display');
    }
    
    // 4. Update Automation Delay Intervals
    if (preset.automationDelays) {
        updateSlider('search-delay-min', preset.automationDelays.searchMin, 'search-delay-min-display');
        updateSlider('search-delay-max', preset.automationDelays.searchMax, 'search-delay-max-display');
        updateSlider('comment-delay-min', preset.automationDelays.commentMin, 'comment-delay-min-display');
        updateSlider('comment-delay-max', preset.automationDelays.commentMax, 'comment-delay-max-display');
    }
    
    // 5. Update Networking Delay Intervals
    if (preset.networkingDelays) {
        updateSlider('networking-delay-min', preset.networkingDelays.min, 'networking-delay-min-display');
        updateSlider('networking-delay-max', preset.networkingDelays.max, 'networking-delay-max-display');
    }
    
    // 6. Update Post Action Delays
    if (preset.postActionDelays) {
        updateSlider('before-opening-posts-delay', preset.postActionDelays.opening, 'before-opening-posts-delay-display');
        updateSlider('post-page-load-delay', preset.postActionDelays.page, 'post-page-load-delay-display');
        updateSlider('before-like-delay', preset.postActionDelays.like, 'before-like-delay-display');
        updateSlider('before-comment-delay', preset.postActionDelays.comment, 'before-comment-delay-display');
        updateSlider('before-share-delay', preset.postActionDelays.share, 'before-share-delay-display');
        updateSlider('before-follow-delay', preset.postActionDelays.follow, 'before-follow-delay-display');
    }
    
    // Auto-save the new settings
    setTimeout(() => {
        saveLimitsSettings();
    }, 300);
}

// ========== IMPORT FUNCTIONALITY ==========

// Import module loading
console.log('🚀 IMPORT MODULE: import.js loaded successfully!');

let importedProfiles = [];
let isConnectionProcessing = false;
let isEngagementProcessing = false;

// Initialize credits service
const creditsService = new CreditsService();
console.log('✅ IMPORT: CreditsService initialized successfully');

// Forward declare window functions (will be defined later)
console.log('🔧 IMPORT MODULE: Declaring window functions...');
window.startConnectionRequests = null;
window.startPostEngagement = null;
window.startCombinedAutomation = null;
console.log('✅ IMPORT MODULE: Window functions declared');

// Flag to track if message listener is already added
let messageListenerAdded = false;

/**
 * Set up import progress message listener early (called on popup open)
 * This allows receiving progress updates even when not on the import tab
 */
// Flag to track if storage listener is already added
let storageListenerAdded = false;

function setupImportProgressListener() {
    if (messageListenerAdded) {
        console.log('📥 IMPORT: Progress listener already added');
        return;
    }
    
    console.log('📥 IMPORT: Setting up progress listener early...');
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
        if (message.action === 'importProgress') {
            console.log('📥 IMPORT: Received importProgress message:', message.type);
            handleImportProgressUpdate(message);
        }
        return false;
    });
    messageListenerAdded = true;
    console.log('✅ IMPORT: Early progress listener added');
    
    // Also set up storage change listener for when background updates storage directly
    if (!storageListenerAdded) {
        chrome.storage.onChanged.addListener((changes, areaName) => {
            if (areaName !== 'local') return;
            
            // Update profile URLs input when pendingImportProfiles changes
            if (changes.pendingImportProfiles) {
                console.log('💾 IMPORT UI: Storage changed - pendingImportProfiles updated');
                const newProfiles = changes.pendingImportProfiles.newValue || [];
                const input = document.getElementById('profile-urls-input');
                const countEl = document.getElementById('profile-count');
                
                if (input) {
                    input.value = newProfiles.join('\n');
                }
                if (countEl) {
                    countEl.textContent = newProfiles.length;
                }
                importedProfiles = newProfiles;
                updateImportedProfilesDisplay();
            }
            
            // Update progress bar when importProgressState changes
            if (changes.importProgressState) {
                const progressState = changes.importProgressState.newValue;
                if (progressState) {
                    console.log('💾 IMPORT UI: Storage changed - progress state updated');
                    const currentEl = document.getElementById('combined-current');
                    const totalEl = document.getElementById('combined-total');
                    const progressBarEl = document.getElementById('combined-progress-bar');
                    const percentageEl = document.getElementById('combined-percentage');
                    
                    if (currentEl) currentEl.textContent = progressState.current || 0;
                    if (totalEl) totalEl.textContent = progressState.total || 0;
                    
                    if (progressBarEl && progressState.total > 0) {
                        const pct = Math.round((progressState.current / progressState.total) * 100);
                        progressBarEl.style.width = `${pct}%`;
                        if (percentageEl) percentageEl.textContent = `${pct}%`;
                    }
                }
            }
            
            // Reload history when completedImportProfiles changes
            if (changes.completedImportProfiles) {
                console.log('💾 IMPORT UI: Storage changed - completed profiles updated, reloading history');
                loadImportHistory();
            }
        });
        storageListenerAdded = true;
        console.log('✅ IMPORT: Storage change listener added');
    }
}

/**
 * Initialize import functionality
 */
function initializeImport() {
    console.log('🔧 Initializing Import functionality...');
    
    // Check and restore import automation state
    checkImportAutomationState();
    
    // Sync profile URLs from storage (removes any that were processed while popup was closed)
    syncProfileUrlsFromStorage();
    
    // Load import credits on initialization
    console.log('🔧 IMPORT: About to load import credits...');
    loadImportCredits().then(() => {
        console.log('🔧 IMPORT: Import credits loading completed');
    }).catch((error) => {
        console.error('🔧 IMPORT: Import credits loading failed:', error);
    });
    
    // Set up storage change listener for live history updates
    setupLiveHistoryUpdates();
    
    // Profile input handlers
    const profileInput = document.getElementById('profile-urls-input');
    const csvUpload = document.getElementById('csv-upload');
    const csvUploadBtn = document.getElementById('csv-upload-button');

    if (profileInput) {
        profileInput.addEventListener('input', handleProfileInput);
    }

    if (csvUpload) {
        csvUpload.addEventListener('change', handleCsvUpload);
    }

    if (csvUploadBtn) {
        csvUploadBtn.addEventListener('click', () => {
            csvUpload.click();
        });
    }
    
    // Action button handlers
    document.getElementById('start-connection-requests');
    document.getElementById('start-post-engagement');
    
    // Event listeners will be set up after functions are defined
    
    // History handlers
    const refreshBtn = document.getElementById('refresh-import-history');
    const clearBtn = document.getElementById('clear-import-history');
    const exportBtn = document.getElementById('export-import-csv');
    
    if (refreshBtn) {
        refreshBtn.addEventListener('click', loadImportHistory);
    }
    
    if (clearBtn) {
        clearBtn.addEventListener('click', clearImportHistory);
    }
    
    if (exportBtn) {
        exportBtn.addEventListener('click', exportImportHistoryToCSV);
    }
    
    // Show post details toggle
    const showPostDetailsToggle = document.getElementById('show-post-details');
    if (showPostDetailsToggle) {
        showPostDetailsToggle.addEventListener('change', loadImportHistory);
    }
    
    // Import history search functionality
    const importHistorySearch = document.getElementById('import-history-search');
    if (importHistorySearch) {
        importHistorySearch.addEventListener('input', loadImportHistory);
    }
    
    // Load existing history
    loadImportHistory();
    
    // Set up action button event listeners
    console.log('🔗 IMPORT: Setting up event listeners for import buttons...');
    const startConnectionBtn = document.getElementById('start-connection-requests');
    const startEngagementBtn = document.getElementById('start-post-engagement'); 
    const startCombinedBtn = document.getElementById('start-combined-automation');
    
    if (startConnectionBtn) {
        // Button click listener
        startConnectionBtn.addEventListener('click', () => {
            console.log('🔘 IMPORT: Button clicked - calling startConnectionRequests');
            if (window.startConnectionRequests) {
                window.startConnectionRequests();
            } else {
                console.error('❌ IMPORT: window.startConnectionRequests not defined yet!');
            }
        });
        console.log('✅ IMPORT: Connection requests button listener added');
    }
    
    if (startEngagementBtn) {
        startEngagementBtn.addEventListener('click', () => {
            if (window.startPostEngagement) window.startPostEngagement();
        });
        console.log('✅ IMPORT: Post engagement button listener added');
    } else {
        console.error('❌ IMPORT: start-post-engagement button not found');
    }
    
    if (startCombinedBtn) {
        startCombinedBtn.addEventListener('click', () => {
            if (window.startCombinedAutomation) window.startCombinedAutomation();
        });
        console.log('✅ IMPORT: Combined automation button listener added');
    } else {
        console.error('❌ IMPORT: start-combined-automation button not found');
    }
    
    // Set up stop button event listeners
    const stopConnectionBtn = document.getElementById('stop-connection-requests');
    const stopEngagementBtn = document.getElementById('stop-post-engagement');
    const stopCombinedBtn = document.getElementById('stop-combined-automation');
    
    if (stopConnectionBtn) {
        stopConnectionBtn.addEventListener('click', () => stopImportAutomation('connection'));
    }
    if (stopEngagementBtn) {
        stopEngagementBtn.addEventListener('click', () => stopImportAutomation('engagement'));
    }
    if (stopCombinedBtn) {
        stopCombinedBtn.addEventListener('click', () => stopImportAutomation('combined'));
    }
    console.log('✅ IMPORT: Stop button listeners added');
    
    // Ensure progress listener is set up (uses flag to prevent duplicates)
    setupImportProgressListener();
    
    // Initialize import scheduler
    initializeImportScheduler();
    
    console.log('✅ Import functionality initialized');
}

/**
 * Handle live progress updates from background script
 */
function handleImportProgressUpdate(message) {
    const { type, profileUrl, profileName, current, total, status, result } = message;
    
    console.log('📥 IMPORT UI: Received progress update:', type, profileUrl || '');
    
    // Update progress bar
    const currentEl = document.getElementById('combined-current');
    const totalEl = document.getElementById('combined-total');
    const progressBarEl = document.getElementById('combined-progress-bar');
    const percentageEl = document.getElementById('combined-percentage');
    
    if (currentEl) currentEl.textContent = current || 0;
    if (totalEl) totalEl.textContent = total || 0;
    
    if (progressBarEl && total > 0) {
        const pct = Math.round((current / total) * 100);
        progressBarEl.style.width = `${pct}%`;
        if (percentageEl) percentageEl.textContent = `${pct}%`;
    }
    
    // Save progress to storage for persistence
    chrome.storage.local.set({ 
        importProgress: { current, total }
    });
    
    // Handle processing started - start live history refresh
    if (type === 'start') {
        console.log('🚀 IMPORT UI: Automation started, total profiles:', total);
        startLiveHistoryRefresh();
    }
    
    // Handle profile started
    if (type === 'profileStart') {
        console.log('👤 IMPORT UI: Profile started:', profileName, profileUrl);
        addLiveHistoryRow({
            id: Date.now(),
            timestamp: Date.now(),
            profileUrl,
            profileName,
            status: 'processing'
        });
    }
    
    // Handle profile completed
    if (type === 'profileComplete' && result) {
        console.log('✅ IMPORT UI: Profile completed:', profileUrl, 'Success:', result.success);
        
        // Update the live row
        const rowId = document.querySelector(`[id^="import-row-"]`)?.id?.replace('import-row-', '');
        if (rowId) {
            updateLiveHistoryRow(rowId, {
                status: result.success ? 'completed' : 'failed',
                connectionSent: result.connectionSent,
                likes: result.likes,
                comments: result.comments
            });
        }
        
        // Remove completed profile from input box and storage immediately
        if (profileUrl && result.success) {
            console.log('🗑️ IMPORT UI: Removing processed profile from UI:', profileUrl);
            removeProfileByUrl(profileUrl);
            removeProcessedProfile(profileUrl);
        }
        
        // Force reload history table for live updates
        loadImportHistory();
    }
    
    // Handle automation complete
    if (type === 'complete') {
        console.log('🎉 IMPORT UI: Automation complete!');
        // Stop live refresh
        stopLiveHistoryRefresh();
        // Reload history from storage
        loadImportHistory();
        // Reset UI
        resetImportUI('combined');
    }
}

/**
 * Stop import automation
 */
async function stopImportAutomation(type) {
    console.log(`🛑 IMPORT: Stopping ${type} automation...`);
    
    // Disable stop button and show stopping state
    const stopBtn = document.getElementById(`stop-${type === 'connection' ? 'connection-requests' : type === 'engagement' ? 'post-engagement' : 'combined-automation'}`);
    if (stopBtn) {
        stopBtn.textContent = '⏳ Stopping...';
        stopBtn.disabled = true;
    }
    
    try {
        const response = await chrome.runtime.sendMessage({ action: 'stopImportAutomation' });
        if (response && response.success) {
            showToast('Import automation stopped', 'info');
        }
    } catch (error) {
        console.error('Error stopping import:', error);
    }
    
    // Clear processing state from storage
    await chrome.storage.local.set({ 
        importAutomationActive: false, 
        importAutomationType: null,
        importProgress: null 
    });
    
    // Reset UI after a brief delay
    setTimeout(() => {
        resetImportUI(type);
    }, 1000);
}

/**
 * Reset import UI after stop or completion
 */
function resetImportUI(type) {
    const startBtnId = type === 'connection' ? 'start-connection-requests' : 
                       type === 'engagement' ? 'start-post-engagement' : 'start-combined-automation';
    const stopBtnId = type === 'connection' ? 'stop-connection-requests' : 
                      type === 'engagement' ? 'stop-post-engagement' : 'stop-combined-automation';
    const progressId = type === 'connection' ? 'connection-progress' : 
                       type === 'engagement' ? 'engagement-progress' : 'combined-progress';
    
    const startBtn = document.getElementById(startBtnId);
    const stopBtn = document.getElementById(stopBtnId);
    const progress = document.getElementById(progressId);
    
    if (startBtn) {
        startBtn.style.display = 'block';
        startBtn.disabled = false;
    }
    if (stopBtn) {
        stopBtn.style.display = 'none';
        stopBtn.textContent = '🛑 Stop';
        stopBtn.disabled = false;
    }
    if (progress) {
        progress.style.display = 'none';
    }
}

/**
 * Handle profile URLs input
 */
async function handleProfileInput() {
    const input = document.getElementById('profile-urls-input');
    const countEl = document.getElementById('profile-count');
    
    if (!input || !countEl) return;
    
    const text = input.value.trim();
    const urls = text.split('\n').filter(line => {
        const trimmed = line.trim();
        return trimmed && trimmed.includes('linkedin.com/in/');
    });
    
    countEl.textContent = urls.length;
    importedProfiles = urls.map(url => url.trim());
    
    // Save profile URLs to local storage for persistence
    await saveProfileUrlsToStorage(importedProfiles);
    
    updateImportedProfilesDisplay();
}

/**
 * Save profile URLs to local storage
 */
async function saveProfileUrlsToStorage(profiles) {
    try {
        await chrome.storage.local.set({ pendingImportProfiles: profiles });
        console.log('📝 IMPORT: Saved', profiles.length, 'profile URLs to storage');
    } catch (error) {
        console.error('📝 IMPORT: Failed to save profile URLs:', error);
    }
}

/**
 * Sync profile URLs from storage when popup opens
 * This handles profiles that were processed while popup was closed
 */
async function syncProfileUrlsFromStorage() {
    try {
        console.log('🔄 IMPORT UI: Syncing profile URLs from storage...');
        
        // Load pending profiles (background script removes completed ones)
        const { pendingImportProfiles = [] } = await chrome.storage.local.get('pendingImportProfiles');
        
        const input = document.getElementById('profile-urls-input');
        const countEl = document.getElementById('profile-count');
        
        if (input) {
            input.value = pendingImportProfiles.join('\n');
        }
        if (countEl) {
            countEl.textContent = pendingImportProfiles.length;
        }
        importedProfiles = pendingImportProfiles;
        
        console.log('✅ IMPORT UI: Synced', pendingImportProfiles.length, 'pending profiles from storage');
        updateImportedProfilesDisplay();
        
        // Also load import history to show latest entries
        loadImportHistory();
        
        // Check if automation is still running and update progress bar
        const { importProgressState, importAutomationActive } = await chrome.storage.local.get(['importProgressState', 'importAutomationActive']);
        
        if (importAutomationActive && importProgressState) {
            console.log('🔄 IMPORT UI: Automation still running, updating progress bar');
            const currentEl = document.getElementById('combined-current');
            const totalEl = document.getElementById('combined-total');
            const progressBarEl = document.getElementById('combined-progress-bar');
            const percentageEl = document.getElementById('combined-percentage');
            
            if (currentEl) currentEl.textContent = importProgressState.current || 0;
            if (totalEl) totalEl.textContent = importProgressState.total || 0;
            
            if (progressBarEl && importProgressState.total > 0) {
                const pct = Math.round((importProgressState.current / importProgressState.total) * 100);
                progressBarEl.style.width = `${pct}%`;
                if (percentageEl) percentageEl.textContent = `${pct}%`;
            }
        }
    } catch (error) {
        console.error('❌ IMPORT UI: Failed to sync profile URLs:', error);
    }
}

/**
 * Remove a processed profile URL from storage and textarea
 */
async function removeProcessedProfile(profileUrl) {
    try {
        console.log('💾 IMPORT UI: removeProcessedProfile called for:', profileUrl);
        const { pendingImportProfiles = [] } = await chrome.storage.local.get('pendingImportProfiles');
        console.log('💾 IMPORT UI: Current pending profiles in storage:', pendingImportProfiles.length);
        
        // Normalize URL for comparison
        const normalizeUrl = (url) => url?.replace(/\/$/, '').toLowerCase().trim();
        const normalizedTarget = normalizeUrl(profileUrl);
        
        const updatedProfiles = pendingImportProfiles.filter(url => {
            const normalizedUrl = normalizeUrl(url);
            return normalizedUrl !== normalizedTarget && 
                   !normalizedUrl.includes(normalizedTarget) && 
                   !normalizedTarget.includes(normalizedUrl);
        });
        
        console.log('💾 IMPORT UI: After filtering, remaining:', updatedProfiles.length);
        
        await chrome.storage.local.set({ pendingImportProfiles: updatedProfiles });
        
        // Also update the textarea
        const input = document.getElementById('profile-urls-input');
        const countEl = document.getElementById('profile-count');
        
        if (input) {
            input.value = updatedProfiles.join('\n');
        }
        if (countEl) {
            countEl.textContent = updatedProfiles.length;
        }
        importedProfiles = updatedProfiles;
        
        console.log('✅ IMPORT UI: Removed processed profile from storage, remaining:', updatedProfiles.length);
    } catch (error) {
        console.error('❌ IMPORT UI: Failed to remove processed profile:', error);
    }
}

/**
 * Handle CSV file upload
 */
function handleCsvUpload(event) {
    const file = event.target.files[0];
    const statusEl = document.getElementById('csv-status');
    
    if (!file || !statusEl) return;
    
    if (!file.name.toLowerCase().endsWith('.csv')) {
        statusEl.innerHTML = '<span style="color: #dc3545;">Please select a valid CSV file</span>';
        return;
    }
    
    const reader = new FileReader();
    reader.onload = function(e) {
        try {
            const csv = e.target.result;
            console.log('📄 CSV Content:', csv.substring(0, 500)); // Log first 500 chars

            // Handle different line endings (Windows \r\n, Unix \n, Mac \r)
            const lines = csv.split(/\r?\n/).filter(line => line.trim());
            console.log('📊 Total lines:', lines.length);

            const profiles = [];

            lines.forEach((line, index) => {
                const trimmedLine = line.trim();
                console.log(`Processing line ${index}:`, trimmedLine.substring(0, 100));

                // Skip empty lines
                if (!trimmedLine) {
                    console.log('⏭️ Skipping empty line');
                    return;
                }

                // Only skip header if it's the FIRST line AND looks like a header
                // AND doesn't contain a LinkedIn URL
                if (index === 0 &&
                    !trimmedLine.includes('linkedin.com/in/') &&
                    !trimmedLine.includes('linkedin.com/') &&
                    (trimmedLine.toLowerCase().includes('url') ||
                     trimmedLine.toLowerCase().includes('profile') ||
                     trimmedLine.toLowerCase().includes('name') ||
                     trimmedLine.toLowerCase().includes('linkedin'))) {
                    console.log('⏭️ Skipping header row');
                    return;
                }

                // Check if the entire line is a LinkedIn URL (for line-separated format)
                if (trimmedLine.includes('linkedin.com/in/') || trimmedLine.includes('linkedin.com/')) {
                    profiles.push(trimmedLine);
                    console.log('✅ Valid profile URL found (line format):', trimmedLine);
                    return;
                }

                // Try comma-separated format
                const columns = trimmedLine.split(',');
                const url = columns[0]?.trim().replace(/"/g, '');

                console.log(`Column 0: "${url}"`);

                // Check for LinkedIn profile URLs with various patterns
                if (url && (url.includes('linkedin.com/in/') || url.includes('linkedin.com/'))) {
                    profiles.push(url);
                    console.log('✅ Valid profile URL found (CSV format):', url);
                } else {
                    console.log('❌ Not a valid LinkedIn URL:', trimmedLine.substring(0, 50));
                }
            });

            console.log('🎯 Total profiles found:', profiles.length);

            importedProfiles = profiles;
            statusEl.innerHTML = `<span style="color: #28a745;">✅ Loaded ${profiles.length} profiles</span>`;

            // Update profile count and display
            const countEl = document.getElementById('profile-count');
            if (countEl) countEl.textContent = profiles.length;

            // Also paste URLs into the input box
            const profileInput = document.getElementById('profile-urls-input');
            if (profileInput) {
                profileInput.value = profiles.join('\n');
            }

            updateImportedProfilesDisplay();

        } catch (error) {
            statusEl.innerHTML = '<span style="color: #dc3545;">❌ Error reading CSV file</span>';
            console.error('CSV parsing error:', error);
        }
    };
    
    reader.readAsText(file);
}

/**
 * Update imported profiles display
 */
function updateImportedProfilesDisplay() {
    const section = document.getElementById('imported-profiles-section');
    const countEl = document.getElementById('imported-count');
    const listEl = document.getElementById('imported-profiles-list');
    
    if (!section || !countEl || !listEl) return;
    
    if (importedProfiles.length === 0) {
        section.style.display = 'none';
        return;
    }
    
    section.style.display = 'block';
    countEl.textContent = importedProfiles.length;
    
    listEl.innerHTML = importedProfiles.map((profile, index) => `
        <div style="display: flex; align-items: center; justify-content: space-between; padding: 5px 0; border-bottom: 1px solid #e0e0e0;">
            <span style="font-size: 11px; color: #666;">${index + 1}.</span>
            <span style="font-size: 11px; flex: 1; margin-left: 8px; word-break: break-all;">${profile}</span>
            <button onclick="removeProfile(${index})" 
                    style="background: none; border: none; color: #dc3545; cursor: pointer; font-size: 11px;">❌</button>
        </div>
    `).join('');
}

/**
 * Remove profile from imported list
 */
window.removeProfile = function(index) {
    importedProfiles.splice(index, 1);
    updateImportedProfilesDisplay();
    
    // Update count display
    const countEl = document.getElementById('profile-count');
    if (countEl) countEl.textContent = importedProfiles.length;
};

/**
 * Start connection requests automation
 */
window.startConnectionRequests = async function startConnectionRequests() {
    console.log('🔄 IMPORT: startConnectionRequests function called!');
    
    // CHECK FEATURE PERMISSION FIRST
    const canUseImport = await featureChecker.checkFeature('importProfiles');
    if (!canUseImport) {
        console.warn('🚫 Import feature access denied - not available in current plan');
        showToast('⬆️ Import Profiles Auto Engagement requires a paid plan. Please upgrade!', 'error');
        
        // Show plan modal for upgrade
        const planModal = document.getElementById('plan-modal');
        if (planModal) {
            planModal.style.display = 'flex';
            loadPlans();
        }
        return;
    }
    
    if (isConnectionProcessing) {
        showToast('Connection requests are already in progress', 'warning');
        return;
    }
    
    if (importedProfiles.length === 0) {
        showToast('Please import some profiles first', 'warning');
        return;
    }
    
    // CHECK IMPORT CREDITS BEFORE STARTING
    console.log('💳 IMPORT: Checking import credits...');
    const creditsCheck = await creditsService.checkCreditsAvailable(importedProfiles.length);
    if (!creditsCheck.hasCredits) {
        showToast(`❌ Insufficient import credits! You need ${creditsCheck.needed} credits but only have ${creditsCheck.remaining} remaining.`, 'error');
        return;
    }
    console.log(`✅ IMPORT: Credits available - ${creditsCheck.remaining}/${creditsCheck.total}`);
    
    isConnectionProcessing = true;
    
    // Show status bar
    logStatus('import', 'starting');
    
    const btn = document.getElementById('start-connection-requests');
    const stopBtn = document.getElementById('stop-connection-requests');
    const progressSection = document.getElementById('connection-progress');
    document.getElementById('connection-current');
    const totalEl = document.getElementById('connection-total');
    document.getElementById('connection-progress-bar');
    
    if (btn) {
        btn.disabled = true;
        btn.textContent = '🔄 Processing...';
        btn.style.background = '#ff9800';
    }
    if (stopBtn) {
        stopBtn.style.display = 'block';
    }
    
    // Show processing message
    logStatus('import', 'loading-profiles', { count: importedProfiles.length });
    showToast('🔄 Processing connection requests in background...', 'info');
    
    if (progressSection) progressSection.style.display = 'block';
    if (totalEl) totalEl.textContent = importedProfiles.length;
    
    const extractContactInfo = document.getElementById('extract-contact-info')?.checked || false;
    console.log('📧 IMPORT: Extract Contact Info checkbox state:', extractContactInfo);
    const sessionData = {
        id: Date.now().toString(),
        startTime: Date.now(),
        type: 'connection_requests',
        profiles: importedProfiles.length,
        extractContactInfo
    };
    
    try {
        // Send to background - it will save history automatically
        console.log('📤 IMPORT: Sending connection request to background...');
        console.log('📤 IMPORT: Profiles to send:', importedProfiles);
        console.log('📤 IMPORT: Options to send:', { extractContactInfo });
        
        const response = await chrome.runtime.sendMessage({
            action: 'startImportConnections',
            profiles: importedProfiles,
            options: { extractContactInfo }
        });
        
        console.error('🔥🔥🔥 IMPORT POPUP: Processing response:', response);
        console.error('🔥 IMPORT POPUP: Response type:', typeof response);
        console.error('🔥 IMPORT POPUP: Response success:', response?.success);
        
        if (response && response.success) {
            const result = response.result;
            console.error('🔥 IMPORT POPUP: Result object:', result);
            console.error('🔥 IMPORT POPUP: Result.successful:', result.successful);
            console.error('🔥 IMPORT POPUP: Result.failed:', result.failed);
            
            showToast(`Connection requests completed! Successful: ${result.successful}, Failed: ${result.failed}`, 'success');
            
            // Wait a moment for background to finish saving
            await new Promise(resolve => setTimeout(resolve, 500));
            
            // Background has already saved the history, just reload it
            console.error('📊 IMPORT POPUP: Reloading history from storage (saved by background)...');
            await loadImportHistory();
            console.error('✅ IMPORT POPUP: History reloaded');
        } else {
            throw new Error(response.error);
        }
        
    } catch (error) {
        console.error('📥 IMPORT: Connection requests failed:', error);
        console.error('📥 IMPORT: Error details:', error);
        showToast('Connection requests failed: ' + error.message, 'error');
        
        sessionData.status = 'failed';
        sessionData.error = error.message;
        sessionData.endTime = Date.now();
        sessionData.duration = sessionData.endTime - sessionData.startTime;
        await saveImportSession(sessionData);
    } finally {
        isConnectionProcessing = false;
        logStatus('import', 'completed');
        setTimeout(() => hideStatusBar('import'), 3000);
        
        if (btn) {
            btn.disabled = false;
            btn.textContent = '🚀 Start Connection Requests';
            btn.style.background = '';
        }
        if (stopBtn) {
            stopBtn.style.display = 'none';
            stopBtn.textContent = '🛑 Stop';
            stopBtn.disabled = false;
        }
        if (progressSection) progressSection.style.display = 'none';
    }
};
console.log('✅ IMPORT MODULE: window.startConnectionRequests assigned');

// Connection requests are now handled in background script

/**
 * Start post engagement automation
 */
window.startPostEngagement = async function startPostEngagement() {
    // CHECK FEATURE PERMISSION FIRST
    const canUseImport = await featureChecker.checkFeature('importProfiles');
    if (!canUseImport) {
        console.warn('🚫 Import feature access denied - not available in current plan');
        showToast('⬆️ Import Profiles Auto Engagement requires a paid plan. Please upgrade!', 'error');
        
        // Show plan modal for upgrade
        const planModal = document.getElementById('plan-modal');
        if (planModal) {
            planModal.style.display = 'flex';
            loadPlans();
        }
        return;
    }
    
    if (isEngagementProcessing) {
        showToast('Post engagement is already in progress', 'warning');
        return;
    }
    
    if (importedProfiles.length === 0) {
        showToast('Please import some profiles first', 'warning');
        return;
    }
    
    isEngagementProcessing = true;
    const btn = document.getElementById('start-post-engagement');
    const stopBtn = document.getElementById('stop-post-engagement');
    const progressSection = document.getElementById('engagement-progress');
    document.getElementById('engagement-current');
    const totalEl = document.getElementById('engagement-total');
    document.getElementById('engagement-progress-bar');
    
    if (btn) {
        btn.disabled = true;
        btn.textContent = '🔄 Processing...';
    }
    if (stopBtn) {
        stopBtn.style.display = 'block';
    }
    
    if (progressSection) progressSection.style.display = 'block';
    if (totalEl) totalEl.textContent = importedProfiles.length;
    
    // Get engagement settings
    const enableLikes = document.getElementById('enable-likes')?.checked || false;
    const enableComments = document.getElementById('enable-comments')?.checked || false;
    const enableShares = document.getElementById('enable-shares')?.checked || false;
    const enableFollows = document.getElementById('enable-follows')?.checked || false;
    const enableRandomMode = document.getElementById('enable-random-mode')?.checked || false;
    const postsPerProfile = parseInt(document.getElementById('posts-per-profile')?.value) || 2;
    
    const sessionData = {
        id: Date.now().toString(),
        startTime: Date.now(),
        type: 'post_engagement',
        profiles: importedProfiles.length,
        postsPerProfile,
        enableLikes,
        enableComments,
        enableShares,
        enableFollows
    };
    
    try {
        // Call background script
        const response = await chrome.runtime.sendMessage({
            action: 'startImportEngagement',
            profiles: importedProfiles,
            options: {
                postsPerProfile,
                randomMode: enableRandomMode,
                actions: {
                    likes: enableLikes,
                    comments: enableComments,
                    shares: enableShares,
                    follows: enableFollows
                }
            }
        });
        
        if (response.success) {
            const result = response.result;
            showToast(`Post engagement completed! Likes: ${result.totalLikes}, Comments: ${result.totalComments}, Shares: ${result.totalShares}, Follows: ${result.totalFollows}`, 'success');
            
            // Save session data
            sessionData.likes = result.totalLikes;
            sessionData.comments = result.totalComments;
            sessionData.shares = result.totalShares;
            sessionData.follows = result.totalFollows;
            sessionData.status = 'completed';
            sessionData.endTime = Date.now();
            sessionData.duration = sessionData.endTime - sessionData.startTime;
            
            await saveImportSession(sessionData);
            await loadImportHistory();
        } else {
            throw new Error(response.error);
        }
        
    } catch (error) {
        console.error('Post engagement failed:', error);
        showToast('Post engagement failed: ' + error.message, 'error');
        
        sessionData.status = 'failed';
        sessionData.error = error.message;
        sessionData.endTime = Date.now();
        sessionData.duration = sessionData.endTime - sessionData.startTime;
        await saveImportSession(sessionData);
    } finally {
        isEngagementProcessing = false;
        if (btn) {
            btn.disabled = false;
            btn.textContent = '🎯 Start Post Engagement';
        }
        if (stopBtn) {
            stopBtn.style.display = 'none';
            stopBtn.textContent = '🛑 Stop';
            stopBtn.disabled = false;
        }
        if (progressSection) progressSection.style.display = 'none';
    }
};

// Post engagement is now handled in background script

// Contact info extraction is now handled in background script

// Lead saving is now handled in background script

// Name extraction is now handled in background script

/**
 * Start combined automation (connection requests + post engagement)
 */
window.startCombinedAutomation = async function startCombinedAutomation() {
    // CHECK FEATURE PERMISSION FIRST
    const canUseImport = await featureChecker.checkFeature('importProfiles');
    if (!canUseImport) {
        console.warn('🚫 Import feature access denied - not available in current plan');
        showToast('⬆️ Import Profiles Auto Engagement requires a paid plan. Please upgrade!', 'error');
        
        // Show plan modal for upgrade
        const planModal = document.getElementById('plan-modal');
        if (planModal) {
            planModal.style.display = 'flex';
            loadPlans();
        }
        return;
    }
    
    // Check daily limits before starting
    const limits = await checkAllDailyLimits();
    const remainingActions = await getRemainingActions();
    
    if (limits.anyLimitReached) {
        let limitMessages = [];
        if (!limits.comments.canProceed) limitMessages.push(`Comments: ${limits.comments.used}/${limits.comments.limit}`);
        if (!limits.likes.canProceed) limitMessages.push(`Likes: ${limits.likes.used}/${limits.likes.limit}`);
        if (!limits.shares.canProceed) limitMessages.push(`Shares: ${limits.shares.used}/${limits.shares.limit}`);
        if (!limits.follows.canProceed) limitMessages.push(`Follows: ${limits.follows.used}/${limits.follows.limit}`);
        if (!limits.connections.canProceed) limitMessages.push(`Connections: ${limits.connections.used}/${limits.connections.limit}`);
        
        const proceed = confirm(
            `⚠️ Daily Limit(s) Reached!\n\n` +
            `${limitMessages.join('\n')}\n\n` +
            `Some actions may be skipped due to limits.\n` +
            `Do you still want to proceed?\n\n` +
            `💡 Tip: Adjust daily limits in the Limits tab.`
        );
        if (!proceed) return;
    }
    
    // Log remaining actions for this session
    console.log('📊 IMPORT: Remaining daily actions:', remainingActions);
    
    if (isConnectionProcessing || isEngagementProcessing) {
        showToast('Another automation is already in progress', 'warning');
        return;
    }
    
    if (importedProfiles.length === 0) {
        showToast('Please import some profiles first', 'warning');
        return;
    }
    
    isConnectionProcessing = true;
    isEngagementProcessing = true;
    
    // Save processing state to storage for persistence across popup reopens
    await chrome.storage.local.set({ importAutomationActive: true, importAutomationType: 'combined' });
    
    const btn = document.getElementById('start-combined-automation');
    const progressSection = document.getElementById('combined-progress');
    const stopBtn = document.getElementById('stop-combined-automation');
    document.getElementById('combined-current');
    const totalEl = document.getElementById('combined-total');
    document.getElementById('combined-progress-bar');
    
    if (btn) {
        btn.disabled = true;
        btn.textContent = '🔄 Processing...';
    }
    if (stopBtn) {
        stopBtn.style.display = 'block';
    }
    
    if (progressSection) progressSection.style.display = 'block';
    if (totalEl) totalEl.textContent = importedProfiles.length;
    
    // Get settings
    const sendConnections = document.getElementById('combined-send-connections')?.checked ?? true;
    const extractContactInfo = document.getElementById('combined-extract-contact-info')?.checked || false;
    const enableLikes = document.getElementById('combined-enable-likes')?.checked || false;
    const enableComments = document.getElementById('combined-enable-comments')?.checked || false;
    const enableShares = document.getElementById('combined-enable-shares')?.checked || false;
    const enableFollows = document.getElementById('combined-enable-follows')?.checked || false;
    const enableRandomMode = document.getElementById('combined-enable-random-mode')?.checked || false;
    const postsPerProfile = parseInt(document.getElementById('combined-posts-per-profile')?.value) || 2;
    
    const sessionData = {
        id: Date.now().toString(),
        startTime: Date.now(),
        type: 'combined_automation',
        profiles: importedProfiles.length,
        sendConnections,
        extractContactInfo,
        postsPerProfile,
        enableLikes,
        enableComments,
        enableShares,
        enableFollows
    };
    
    try {
        // Call background script
        const response = await chrome.runtime.sendMessage({
            action: 'startImportCombined',
            profiles: importedProfiles,
            options: {
                sendConnections,
                extractContactInfo,
                postsPerProfile,
                randomMode: enableRandomMode,
                actions: {
                    likes: enableLikes,
                    comments: enableComments,
                    shares: enableShares,
                    follows: enableFollows
                }
            }
        });
        
        if (response.success) {
            const result = response.result;
            showToast(`Combined automation completed! Connections: ${result.connectionsSuccessful}/${result.connectionsSuccessful + result.connectionsFailed}, Likes: ${result.totalLikes}, Comments: ${result.totalComments}, Shares: ${result.totalShares}, Follows: ${result.totalFollows}`, 'success');
            
            // Save session data
            sessionData.connectionsSuccessful = result.connectionsSuccessful;
            sessionData.connectionsFailed = result.connectionsFailed;
            sessionData.likes = result.totalLikes;
            sessionData.comments = result.totalComments;
            sessionData.shares = result.totalShares;
            sessionData.follows = result.totalFollows;
            sessionData.status = 'completed';
            sessionData.endTime = Date.now();
            sessionData.duration = sessionData.endTime - sessionData.startTime;
            
            await saveImportSession(sessionData);
            await loadImportHistory();
        } else {
            throw new Error(response.error);
        }
        
    } catch (error) {
        console.error('Combined automation failed:', error);
        showToast('Combined automation failed: ' + error.message, 'error');
        
        sessionData.status = 'failed';
        sessionData.error = error.message;
        sessionData.endTime = Date.now();
        sessionData.duration = sessionData.endTime - sessionData.startTime;
        await saveImportSession(sessionData);
    } finally {
        isConnectionProcessing = false;
        isEngagementProcessing = false;
        // Clear processing state from storage
        await chrome.storage.local.set({ importAutomationActive: false, importAutomationType: null });
        if (btn) {
            btn.disabled = false;
            btn.textContent = '🚀 Launch Automation';
        }
        if (stopBtn) {
            stopBtn.style.display = 'none';
            stopBtn.textContent = '🛑 Stop';
            stopBtn.disabled = false;
        }
        if (progressSection) progressSection.style.display = 'none';
    }
};

/**
 * Save import session to history (legacy - for processing history)
 */
async function saveImportSession(sessionData) {
    try {
        console.log('💾 IMPORT: Saving session data:', sessionData);
        // Save to import history
        const { importHistory = [] } = await chrome.storage.local.get('importHistory');
        importHistory.unshift(sessionData);
        
        // Keep only last 50 sessions
        if (importHistory.length > 50) {
            importHistory.splice(50);
        }
        
        await chrome.storage.local.set({ importHistory });
        console.log('💾 IMPORT: Saved to importHistory, total sessions:', importHistory.length);
        
        // Also save to main processing history for Analytics tab
        const { processingHistory = [] } = await chrome.storage.local.get('processingHistory');
        
        // Convert import session to processing history format
        const processingSession = {
            id: sessionData.id,
            startTime: sessionData.startTime,
            endTime: sessionData.endTime,
            duration: sessionData.duration,
            type: sessionData.type,
            status: sessionData.status,
            processed: sessionData.profiles || 0,
            successful: sessionData.successful || sessionData.connectionsSuccessful || 0,
            target: sessionData.profiles || 0,
            query: `Import (${sessionData.profiles} profiles)`,
            options: {
                extractContactInfo: sessionData.extractContactInfo,
                postsPerProfile: sessionData.postsPerProfile,
                enableLikes: sessionData.enableLikes,
                enableComments: sessionData.enableComments,
                enableShares: sessionData.enableShares,
                enableFollows: sessionData.enableFollows
            },
            // Add import-specific data
            likes: sessionData.likes || 0,
            comments: sessionData.comments || 0,
            shares: sessionData.shares || 0,
            follows: sessionData.follows || 0,
            connectionsFailed: sessionData.connectionsFailed || sessionData.failed || 0
        };
        
        processingHistory.unshift(processingSession);
        
        // Keep only last 100 sessions
        if (processingHistory.length > 100) {
            processingHistory.splice(100);
        }
        
        await chrome.storage.local.set({ processingHistory });
        
        console.log('💾 Import session saved to both histories:', sessionData);
        
    } catch (error) {
        console.error('Failed to save import session:', error);
    }
}

/**
 * Load import history
 */
async function loadImportHistory() {
    try {
        console.log('📊 IMPORT: Loading import history...');
        const { importHistory = [] } = await chrome.storage.local.get('importHistory');
        console.log('📊 IMPORT: Found', importHistory.length, 'sessions in storage');
        
        // Check if "Show Posts" is enabled
        const showPostDetails = document.getElementById('show-post-details')?.checked || false;
        
        // Update statistics
        const totalProfiles = importHistory.length;
        const totalConnections = importHistory.reduce((sum, record) => 
            sum + (record.connectionsSent || 0), 0);
        const totalPosts = importHistory.reduce((sum, record) => 
            sum + ((record.likes || 0) + (record.comments || 0) + (record.shares || 0)), 0);
        const totalCommentsGenerated = importHistory.reduce((sum, record) => 
            sum + ((record.postDetails || []).filter(p => p.generatedComment).length), 0);
        const successfulProfiles = importHistory.filter(record => 
            record.status === 'completed' || record.status === 'Success').length;
        const successRate = totalProfiles > 0 ? 
            Math.round((successfulProfiles / totalProfiles) * 100) : 0;
        
        // Update UI elements
        updateElement$1('total-import-sessions', totalProfiles);
        updateElement$1('total-connections-sent', totalConnections);
        updateElement$1('total-posts-engaged', totalPosts);
        updateElement$1('total-comments-generated', totalCommentsGenerated);
        updateElement$1('import-success-rate', successRate + '%');
        
        // Get search term
        const searchInput = document.getElementById('import-history-search');
        const searchTerm = searchInput?.value?.toLowerCase() || '';
        
        // Filter history by search term
        const filteredHistory = searchTerm ? importHistory.filter(record => {
            const profileName = (record.profileName || '').toLowerCase();
            const profileUrl = (record.profileUrl || '').toLowerCase();
            return profileName.includes(searchTerm) || profileUrl.includes(searchTerm);
        }) : importHistory;
        
        // Update history table
        const tbody = document.getElementById('import-history-table-body');
        if (tbody) {
            if (filteredHistory.length === 0) {
                tbody.innerHTML = `
                    <tr>
                        <td colspan="10" style="padding: 20px; text-align: center; color: #999;">
                            ${searchTerm ? 'No matching profiles found.' : 'No import actions yet. Start automation to see history here.'}
                        </td>
                    </tr>
                `;
            } else {
                let tableHtml = '';
                filteredHistory.forEach((record, idx) => {
                    const date = record.date || new Date(record.timestamp).toLocaleString('en-GB', { 
                        day: '2-digit', month: '2-digit', year: '2-digit', hour: '2-digit', minute: '2-digit' 
                    });
                    const profileLink = record.profileUrl || 'N/A';
                    const profileName = record.profileName || 'Unknown';
                    const hasPostDetails = (record.postDetails || []).length > 0;
                    
                    const profileDisplay = profileLink !== 'N/A' ? 
                        `<a href="${profileLink}" target="_blank" style="color: #0a66c2;">🔗</a>` : '-';
                    
                    const statusBg = record.status === 'completed' || record.status === 'Success' ? '#28a745' : 
                                    record.status === 'failed' ? '#dc3545' : '#6c757d';
                    
                    // Main profile row (removed email column)
                    tableHtml += `
                        <tr style="background: ${idx % 2 === 0 ? '#fff' : '#f9f9f9'};">
                            <td style="padding: 5px; border-bottom: 1px solid #eee; font-size: 9px;">${date}</td>
                            <td style="padding: 5px; border-bottom: 1px solid #eee; font-weight: 600; font-size: 10px;">${profileName}</td>
                            <td style="padding: 5px; border-bottom: 1px solid #eee; text-align: center;">${profileDisplay}</td>
                            <td style="padding: 5px; border-bottom: 1px solid #eee; text-align: center;">${record.connectionsSent || 0}</td>
                            <td style="padding: 5px; border-bottom: 1px solid #eee; text-align: center;">${record.likes || 0}</td>
                            <td style="padding: 5px; border-bottom: 1px solid #eee; text-align: center;">${record.comments || 0}</td>
                            <td style="padding: 5px; border-bottom: 1px solid #eee; text-align: center;">${record.shares || 0}</td>
                            <td style="padding: 5px; border-bottom: 1px solid #eee; text-align: center;">${record.follows || 0}</td>
                            <td style="padding: 5px; border-bottom: 1px solid #eee; text-align: center;">
                                <span style="background: ${statusBg}; color: white; padding: 1px 4px; border-radius: 3px; font-size: 8px;">
                                    ${record.status === 'completed' ? '✓' : record.status === 'failed' ? '✗' : record.status}
                                </span>
                            </td>
                            <td style="padding: 5px; border-bottom: 1px solid #eee; text-align: center;">
                                ${hasPostDetails ? `<button onclick="togglePostDetails('${record.id}')" style="background: #693fe9; color: white; border: none; padding: 2px 6px; border-radius: 3px; font-size: 9px; cursor: pointer;">${(record.postDetails || []).length}</button>` : '-'}
                            </td>
                        </tr>
                    `;
                    
                    // Post details rows (shown if toggle is on and has post details)
                    if (showPostDetails && hasPostDetails) {
                        (record.postDetails || []).forEach(post => {
                            const postUrl = post.postLink || '';
                            const postLink = postUrl ? `<a href="${postUrl}" target="_blank" style="color: #693fe9; font-size: 9px;">View</a>` : '-';
                            const truncate = (text, max) => text && text.length > max ? text.substring(0, max) + '...' : (text || '-');
                            
                            tableHtml += `
                                <tr style="background: #f0f4ff;">
                                    <td colspan="2" style="padding: 4px 5px 4px 20px; border-bottom: 1px solid #ddd; font-size: 9px; color: #666;">↳ Post by: <strong>${post.authorName || 'Unknown'}</strong></td>
                                    <td style="padding: 4px; border-bottom: 1px solid #ddd; text-align: center;">${postLink}</td>
                                    <td colspan="3" style="padding: 4px; border-bottom: 1px solid #ddd; font-size: 9px; color: #333;" title="${(post.postContent || '').replace(/"/g, '&quot;')}">${truncate(post.postContent, 40)}</td>
                                    <td colspan="4" style="padding: 4px; border-bottom: 1px solid #ddd; font-size: 9px; color: #693fe9;" title="${(post.generatedComment || '').replace(/"/g, '&quot;')}">${truncate(post.generatedComment, 40)}</td>
                                </tr>
                            `;
                        });
                    }
                });
                tbody.innerHTML = tableHtml;
            }
        }
        
    } catch (error) {
        console.error('📊 IMPORT: Failed to load import history:', error);
    }
}

// Toggle post details for a specific profile
window.togglePostDetails = function(profileId) {
    const showPostsCheckbox = document.getElementById('show-post-details');
    if (showPostsCheckbox) {
        showPostsCheckbox.checked = !showPostsCheckbox.checked;
        loadImportHistory();
    }
};

/**
 * Clear import history
 */
async function clearImportHistory() {
    if (!confirm('Are you sure you want to clear all import history? This action cannot be undone.')) {
        return;
    }
    
    try {
        await chrome.storage.local.set({ importHistory: [] });
        await loadImportHistory();
        showToast('Import history cleared', 'success');
        
    } catch (error) {
        console.error('Failed to clear import history:', error);
        showToast('Failed to clear import history', 'error');
    }
}

/**
 * Export import history to CSV with post details
 */
async function exportImportHistoryToCSV() {
    try {
        const { importHistory = [] } = await chrome.storage.local.get('importHistory');
        
        if (importHistory.length === 0) {
            showToast('No data to export', 'warning');
            return;
        }
        
        // CSV headers - including post details columns
        const headers = ['Date', 'Profile Name', 'Profile Link', 'Email', 'Phone', 'Connections', 'Likes', 'Comments', 'Shares', 'Follows', 'Status', 'Post Author', 'Post Text', 'AI Comment Generated', 'Post Link'];
        
        // Convert data to CSV rows - one row per post detail or one row per profile if no posts
        const rows = [];
        
        importHistory.forEach(record => {
            const baseRow = [
                record.date || new Date(record.timestamp).toLocaleString(),
                record.profileName || 'Unknown',
                record.profileUrl || 'N/A',
                record.email || 'N/A',
                record.phone || 'N/A',
                record.connectionsSent || 0,
                record.likes || 0,
                record.comments || 0,
                record.shares || 0,
                record.follows || 0,
                record.status || 'unknown'
            ];
            
            // If there are post details, create a row for each post
            if (record.postDetails && record.postDetails.length > 0) {
                record.postDetails.forEach((post, index) => {
                    const postRow = [
                        ...baseRow,
                        post.authorName || 'Unknown',
                        (post.postContent || '').replace(/"/g, '""').replace(/\n/g, ' '), // Escape quotes and newlines
                        (post.generatedComment || '').replace(/"/g, '""').replace(/\n/g, ' '),
                        post.postLink || 'N/A'
                    ];
                    rows.push(postRow);
                });
            } else {
                // No post details, add empty columns
                rows.push([...baseRow, 'N/A', 'N/A', 'N/A', 'N/A']);
            }
        });
        
        // Create CSV content
        const csvContent = [
            headers.join(','),
            ...rows.map(row => row.map(cell => `"${cell}"`).join(','))
        ].join('\n');
        
        // Create and download file
        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.setAttribute('href', url);
        link.setAttribute('download', `import-history-${Date.now()}.csv`);
        link.style.display = 'none';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
        
        showToast(`Exported ${rows.length} records to CSV`, 'success');
        
    } catch (error) {
        console.error('Failed to export CSV:', error);
        showToast('Failed to export CSV', 'error');
    }
}

/**
 * Helper functions
 */
function updateElement$1(id, value) {
    const element = document.getElementById(id);
    if (element) {
        element.textContent = value;
    }
}

function getStatusColor(status) {
    const statusLower = status?.toLowerCase() || '';
    switch (statusLower) {
        case 'success':
        case 'completed':
            return '#28a745'; // Green
        case 'failed':
            return '#dc3545'; // Red
        case 'stopped':
        case 'pending':
            return '#ffc107'; // Yellow
        default:
            return '#6c757d'; // Gray
    }
}

/**
 * Load import credits and update UI
 */
async function loadImportCredits() {
    try {
        console.log('💳 IMPORT: Loading import credits...');
        const credits = await creditsService.getImportCredits();
        creditsService.updateCreditsUI(credits);
        console.log('✅ IMPORT: Credits loaded successfully');
    } catch (error) {
        console.error('❌ IMPORT: Failed to load credits:', error);
        // Show default values if not authenticated
        creditsService.updateCreditsUI({
            remaining: 0,
            total: 0,
            used: 0,
            planName: 'Free'
        });
    }
}

/**
 * Check and restore import automation state on popup open
 */
async function checkImportAutomationState() {
    try {
        const result = await chrome.storage.local.get(['importAutomationActive', 'importAutomationType', 'importProgress']);
        const isActive = result.importAutomationActive || false;
        const automationType = result.importAutomationType || 'combined';
        const progress = result.importProgress || { current: 0, total: 0 };

        console.log('POPUP: Import automation state:', { isActive, automationType, progress });

        const btn = document.getElementById('start-combined-automation');
        const stopBtn = document.getElementById('stop-combined-automation');
        const progressSection = document.getElementById('combined-progress');
        const currentEl = document.getElementById('combined-current');
        const totalEl = document.getElementById('combined-total');
        const progressBarEl = document.getElementById('combined-progress-bar');
        const percentageEl = document.getElementById('combined-percentage');

        if (isActive) {
            // Show stop button, hide start button
            if (btn) {
                btn.style.display = 'none';
            }
            if (stopBtn) {
                stopBtn.style.display = 'block';
            }
            if (progressSection) {
                progressSection.style.display = 'block';
            }
            // Update progress display
            if (currentEl) currentEl.textContent = progress.current || 0;
            if (totalEl) totalEl.textContent = progress.total || 0;
            if (progressBarEl && progress.total > 0) {
                const pct = Math.round((progress.current / progress.total) * 100);
                progressBarEl.style.width = `${pct}%`;
                if (percentageEl) percentageEl.textContent = `${pct}%`;
            }
            console.log('POPUP: Restored Import automation stop button state');
        } else {
            // Show start button, hide stop button
            if (btn) {
                btn.style.display = 'block';
                btn.disabled = false;
                btn.textContent = '🚀 Launch Automation';
            }
            if (stopBtn) {
                stopBtn.style.display = 'none';
            }
            if (progressSection) {
                progressSection.style.display = 'none';
            }
        }
    } catch (error) {
        console.error('POPUP: Error checking Import automation state:', error);
    }
}

/**
 * Remove a profile from the input box and importedProfiles array by URL
 */
function removeProfileByUrl(profileUrl) {
    console.log('🗑️ IMPORT UI: removeProfileByUrl called for:', profileUrl);
    console.log('🗑️ IMPORT UI: Current profiles count:', importedProfiles.length);
    
    // Normalize URL for comparison (remove trailing slashes, etc.)
    const normalizeUrl = (url) => url?.replace(/\/$/, '').toLowerCase().trim();
    const normalizedTarget = normalizeUrl(profileUrl);
    
    const index = importedProfiles.findIndex(p => {
        const normalizedP = normalizeUrl(p);
        return normalizedP === normalizedTarget || normalizedP.includes(normalizedTarget) || normalizedTarget.includes(normalizedP);
    });
    
    console.log('🗑️ IMPORT UI: Found at index:', index);
    
    if (index !== -1) {
        const removed = importedProfiles.splice(index, 1);
        console.log('🗑️ IMPORT UI: Removed profile:', removed[0]);
        console.log('🗑️ IMPORT UI: Remaining profiles:', importedProfiles.length);
        
        // Update the input box
        const profileInput = document.getElementById('profile-urls-input');
        if (profileInput) {
            profileInput.value = importedProfiles.join('\n');
            console.log('🗑️ IMPORT UI: Updated input box');
        }
        
        // Update count display
        const countEl = document.getElementById('profile-count');
        if (countEl) {
            countEl.textContent = importedProfiles.length;
            console.log('🗑️ IMPORT UI: Updated count display');
        }
        
        // Update imported profiles display
        updateImportedProfilesDisplay();
    } else {
        console.log('⚠️ IMPORT UI: Profile not found in array. Available profiles:', importedProfiles.slice(0, 3));
    }
}

/**
 * Add a row to import history table for live updates
 */
function addLiveHistoryRow(record) {
    const tableBody = document.getElementById('import-history-table-body');
    if (!tableBody) return;
    
    // Remove "no data" placeholder if present
    const placeholderRow = tableBody.querySelector('tr td[colspan]');
    if (placeholderRow) {
        placeholderRow.parentElement.remove();
    }
    
    const dateStr = new Date(record.timestamp || Date.now()).toLocaleString();
    const profileName = record.profileName || extractNameFromUrl(record.profileUrl || '');
    const profileUrl = record.profileUrl || '';
    const email = record.email || '-';
    const connectionSent = record.connectionSent ? '✅' : (record.connectionPending ? '⏳' : '-');
    const likes = record.likes || 0;
    const comments = record.comments || 0;
    const shares = record.shares || 0;
    const follows = record.follows || 0;
    const status = record.status || 'pending';
    const statusColor = getStatusColor(status);
    
    const row = document.createElement('tr');
    row.id = `import-row-${record.id || Date.now()}`;
    row.style.background = status === 'processing' ? '#fff8e1' : '';
    row.innerHTML = `
        <td style="padding: 6px; font-size: 10px;">${dateStr}</td>
        <td style="padding: 6px; font-size: 10px;">${profileName}</td>
        <td style="padding: 6px; text-align: center;"><a href="${profileUrl}" target="_blank" style="color: #693fe9;">🔗</a></td>
        <td style="padding: 6px; font-size: 10px;">${email}</td>
        <td style="padding: 6px; text-align: center;">${connectionSent}</td>
        <td style="padding: 6px; text-align: center;">${likes}</td>
        <td style="padding: 6px; text-align: center;">${comments}</td>
        <td style="padding: 6px; text-align: center;">${shares}</td>
        <td style="padding: 6px; text-align: center;">${follows}</td>
        <td style="padding: 6px; text-align: center;"><span style="color: ${statusColor}; font-weight: 600;">${status}</span></td>
        <td style="padding: 6px; text-align: center;">-</td>
    `;
    
    // Insert at top of table
    tableBody.insertBefore(row, tableBody.firstChild);
}

/**
 * Update an existing live history row
 */
function updateLiveHistoryRow(rowId, updates) {
    const row = document.getElementById(`import-row-${rowId}`);
    if (!row) return;
    
    // Update status and other fields as needed
    if (updates.status) {
        const statusCell = row.querySelector('td:nth-child(10) span');
        if (statusCell) {
            statusCell.textContent = updates.status;
            statusCell.style.color = getStatusColor(updates.status);
        }
        row.style.background = updates.status === 'completed' ? '#e8f5e9' : 
                               updates.status === 'failed' ? '#ffebee' : '';
    }
    if (updates.connectionSent !== undefined) {
        const connCell = row.querySelector('td:nth-child(5)');
        if (connCell) connCell.textContent = updates.connectionSent ? '✅' : '-';
    }
    if (updates.likes !== undefined) {
        const likesCell = row.querySelector('td:nth-child(6)');
        if (likesCell) likesCell.textContent = updates.likes;
    }
    if (updates.comments !== undefined) {
        const commentsCell = row.querySelector('td:nth-child(7)');
        if (commentsCell) commentsCell.textContent = updates.comments;
    }
}

/**
 * Extract name from LinkedIn profile URL
 */
function extractNameFromUrl(url) {
    if (!url) return 'Unknown';
    const match = url.match(/linkedin\.com\/in\/([^\/\?]+)/);
    if (match && match[1]) {
        return match[1].replace(/-/g, ' ').replace(/\d+$/, '').trim();
    }
    return 'Unknown';
}

/**
 * Set up storage change listener for live history updates
 */
function setupLiveHistoryUpdates() {
    // Listen for storage changes to update table in real-time
    chrome.storage.onChanged.addListener((changes, areaName) => {
        if (areaName === 'local') {
            // If importHistory changes, reload the table
            if (changes.importHistory) {
                console.log('📊 IMPORT: Storage changed - reloading history table');
                loadImportHistory();
            }
            
            // If pending profiles change, update the textarea
            if (changes.pendingImportProfiles) {
                const newProfiles = changes.pendingImportProfiles.newValue || [];
                const input = document.getElementById('profile-urls-input');
                const countEl = document.getElementById('profile-count');
                
                if (input && input !== document.activeElement) {
                    input.value = newProfiles.join('\n');
                }
                if (countEl) {
                    countEl.textContent = newProfiles.length;
                }
                importedProfiles = newProfiles;
            }
        }
    });
    
    console.log('📊 IMPORT: Live history updates listener set up');
}

/**
 * Start periodic refresh during processing
 */
let historyRefreshInterval = null;

function startLiveHistoryRefresh() {
    if (historyRefreshInterval) return;
    
    historyRefreshInterval = setInterval(() => {
        loadImportHistory();
    }, 2000); // Refresh every 2 seconds during processing
    
    console.log('📊 IMPORT: Started live history refresh');
}

function stopLiveHistoryRefresh() {
    if (historyRefreshInterval) {
        clearInterval(historyRefreshInterval);
        historyRefreshInterval = null;
        console.log('📊 IMPORT: Stopped live history refresh');
    }
}

// ========== IMPORT SCHEDULER FUNCTIONALITY ==========

let importCountdownInterval = null;

/**
 * Initialize import scheduler
 */
async function initializeImportScheduler() {
    console.log('🕐 IMPORT: Initializing scheduler...');
    
    // Load saved schedules
    loadImportSchedules();
    
    // Set up event listeners
    const addScheduleBtn = document.getElementById('add-import-schedule');
    const schedulerEnabledToggle = document.getElementById('import-scheduler-enabled');
    const profilesPerDaySelect = document.getElementById('import-profiles-per-day');
    
    if (addScheduleBtn) {
        addScheduleBtn.addEventListener('click', addImportSchedule);
    }
    
    if (schedulerEnabledToggle) {
        schedulerEnabledToggle.addEventListener('change', async (e) => {
            // Notify background scheduler
            try {
                await chrome.runtime.sendMessage({
                    action: 'setImportSchedulerEnabled',
                    enabled: e.target.checked
                });
            } catch (err) {
                console.error('IMPORT: Failed to update scheduler enabled state:', err);
            }
            
            if (e.target.checked) {
                startImportCountdown();
            } else {
                stopImportCountdown();
            }
        });
        
        // Load saved state
        chrome.storage.local.get(['importSchedulerEnabled'], (result) => {
            schedulerEnabledToggle.checked = result.importSchedulerEnabled || false;
            if (result.importSchedulerEnabled) {
                startImportCountdown();
            }
        });
    }
    
    if (profilesPerDaySelect) {
        // Load saved value
        chrome.storage.local.get(['importProfilesPerDay'], (result) => {
            if (result.importProfilesPerDay) {
                profilesPerDaySelect.value = result.importProfilesPerDay;
            }
        });
        
        profilesPerDaySelect.addEventListener('change', async (e) => {
            const count = parseInt(e.target.value);
            // Notify background scheduler
            try {
                await chrome.runtime.sendMessage({
                    action: 'setImportProfilesPerDay',
                    count: count
                });
            } catch (err) {
                console.error('IMPORT: Failed to update profiles per day:', err);
            }
        });
    }
    
    // Reload background scheduler to sync state
    try {
        await chrome.runtime.sendMessage({ action: 'reloadImportScheduler' });
        console.log('IMPORT: Background scheduler reloaded');
    } catch (err) {
        console.error('IMPORT: Failed to reload background scheduler:', err);
    }
    
    console.log('✅ IMPORT: Scheduler initialized');
}

/**
 * Add a new import schedule - communicates with background scheduler
 * Saves current automation options with the schedule
 */
async function addImportSchedule() {
    const timeInput = document.getElementById('import-schedule-time-input');
    if (!timeInput || !timeInput.value) {
        showToast('Please select a time', 'error');
        return;
    }
    
    const time = timeInput.value;
    
    // Get current automation options from UI
    const sendConnections = document.getElementById('combined-send-connections')?.checked ?? false;
    const extractContactInfo = document.getElementById('combined-extract-contact-info')?.checked ?? false;
    const enableLikes = document.getElementById('combined-enable-likes')?.checked ?? false;
    const enableComments = document.getElementById('combined-enable-comments')?.checked ?? false;
    const enableFollows = document.getElementById('combined-enable-follows')?.checked ?? false;
    const enableShares = document.getElementById('combined-enable-shares')?.checked ?? false;
    const enableRandomMode = document.getElementById('combined-enable-random-mode')?.checked ?? false;
    const postsPerProfile = parseInt(document.getElementById('combined-posts-per-profile')?.value) || 2;
    
    const options = {
        sendConnections,
        extractContactInfo,
        postsPerProfile,
        randomMode: enableRandomMode,
        actions: {
            like: enableLikes,
            comment: enableComments,
            follow: enableFollows,
            share: enableShares
        }
    };
    
    console.log('IMPORT: Adding schedule with options:', options);
    
    try {
        // Send to background scheduler with options
        const response = await chrome.runtime.sendMessage({
            action: 'addImportSchedule',
            time: time,
            options: options
        });
        
        if (response.success) {
            // Clear input
            timeInput.value = '';
            
            // Reload schedules display
            loadImportSchedules();
            
            // Start countdown if enabled
            const enabledToggle = document.getElementById('import-scheduler-enabled');
            if (enabledToggle && enabledToggle.checked) {
                startImportCountdown();
            }
            
            showToast('Schedule added with current settings', 'success');
        } else {
            showToast(response.error || 'Failed to add schedule', 'error');
        }
    } catch (error) {
        console.error('IMPORT: Error adding schedule:', error);
        showToast('Failed to add schedule', 'error');
    }
}

/**
 * Remove an import schedule - communicates with background scheduler
 */
async function removeImportSchedule(time) {
    try {
        const response = await chrome.runtime.sendMessage({
            action: 'removeImportSchedule',
            time: time
        });
        
        if (response.success) {
            loadImportSchedules();
            showToast('Schedule removed', 'info');
        } else {
            showToast(response.error || 'Failed to remove schedule', 'error');
        }
    } catch (error) {
        console.error('IMPORT: Error removing schedule:', error);
        showToast('Failed to remove schedule', 'error');
    }
}

/**
 * Load and display import schedules with their saved options
 */
async function loadImportSchedules() {
    const listEl = document.getElementById('import-schedule-list');
    if (!listEl) return;
    
    const result = await chrome.storage.local.get(['importSchedules']);
    const schedules = result.importSchedules || [];
    
    if (schedules.length === 0) {
        listEl.innerHTML = '<small style="color: #999;">No schedules</small>';
        return;
    }
    
    // Helper to format schedule options as tags
    const formatOptions = (schedule) => {
        if (typeof schedule === 'string') return ''; // Old format, no options
        
        const opts = schedule.options;
        if (!opts) return '';
        
        const tags = [];
        if (opts.sendConnections) tags.push('📤 Connect');
        if (opts.actions?.comment) tags.push('💬 Comment');
        if (opts.actions?.like) tags.push('❤️ Like');
        if (opts.actions?.follow) tags.push('👤 Follow');
        if (opts.actions?.share) tags.push('🔄 Share');
        if (opts.extractContactInfo) tags.push('📧 Extract');
        
        if (tags.length === 0) return '<span style="color: #999; font-size: 10px;">No actions</span>';
        
        return tags.map(t => `<span style="background: #f0f0f0; padding: 1px 4px; border-radius: 3px; font-size: 9px; margin-right: 2px;">${t}</span>`).join('');
    };
    
    listEl.innerHTML = schedules.map(schedule => {
        const time = typeof schedule === 'string' ? schedule : schedule.time;
        const optionsTags = formatOptions(schedule);
        
        return `
            <div style="display: flex; flex-direction: column; padding: 6px 8px; background: white; border-radius: 6px; margin-bottom: 6px; border: 1px solid #e0e0e0;">
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <span style="font-weight: 600; color: #693fe9; font-size: 14px;">⏰ ${time}</span>
                    <button class="import-schedule-remove-btn" data-time="${time}" 
                            style="background: none; border: none; color: #dc3545; cursor: pointer; font-size: 14px; padding: 2px 6px;">×</button>
                </div>
                ${optionsTags ? `<div style="margin-top: 4px; display: flex; flex-wrap: wrap; gap: 2px;">${optionsTags}</div>` : ''}
            </div>
        `;
    }).join('');
    
    // Add event listeners for remove buttons (CSP compliant)
    listEl.querySelectorAll('.import-schedule-remove-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const time = btn.getAttribute('data-time');
            if (time) removeImportSchedule(time);
        });
    });
}

/**
 * Start countdown timer for next scheduled import
 */
function startImportCountdown() {
    stopImportCountdown(); // Clear existing
    
    updateImportCountdown(); // Initial update
    
    importCountdownInterval = setInterval(updateImportCountdown, 1000);
}

/**
 * Stop countdown timer
 */
function stopImportCountdown() {
    if (importCountdownInterval) {
        clearInterval(importCountdownInterval);
        importCountdownInterval = null;
    }
    
    const nextTimeEl = document.getElementById('import-next-execution-time');
    const countdownEl = document.getElementById('import-countdown-timer');
    
    if (nextTimeEl) nextTimeEl.textContent = '--';
    if (countdownEl) countdownEl.textContent = '--:--:--';
}

/**
 * Update countdown display
 */
async function updateImportCountdown() {
    const result = await chrome.storage.local.get(['importSchedules', 'importSchedulerEnabled']);
    const schedules = result.importSchedules || [];
    const enabled = result.importSchedulerEnabled;
    
    if (!enabled || schedules.length === 0) {
        stopImportCountdown();
        return;
    }
    
    const nextTimeEl = document.getElementById('import-next-execution-time');
    const countdownEl = document.getElementById('import-countdown-timer');
    
    // Find next scheduled time
    const now = new Date();
    const currentTime = now.getHours() * 60 + now.getMinutes();
    
    let nextSchedule = null;
    let nextScheduleMinutes = Infinity;
    
    for (const time of schedules) {
        const [hours, minutes] = time.split(':').map(Number);
        let scheduleMinutes = hours * 60 + minutes;
        
        // If schedule is past for today, add 24 hours
        if (scheduleMinutes <= currentTime) {
            scheduleMinutes += 24 * 60;
        }
        
        if (scheduleMinutes < nextScheduleMinutes) {
            nextScheduleMinutes = scheduleMinutes;
            nextSchedule = time;
        }
    }
    
    if (nextSchedule && nextTimeEl) {
        nextTimeEl.textContent = nextSchedule;
    }
    
    if (countdownEl) {
        const diffMinutes = nextScheduleMinutes - currentTime;
        const hours = Math.floor(diffMinutes / 60);
        const minutes = diffMinutes % 60;
        const seconds = 59 - now.getSeconds();
        
        countdownEl.textContent = `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
        
        // Check if it's time to run
        if (diffMinutes === 0 && seconds === 0) {
            triggerScheduledImport();
        }
    }
}

/**
 * Trigger scheduled import automation
 */
async function triggerScheduledImport() {
    console.log('⏰ IMPORT: Scheduled import triggered!');
    
    const result = await chrome.storage.local.get(['importProfilesPerDay', 'pendingImportProfiles']);
    const profilesPerDay = result.importProfilesPerDay || 20;
    const allProfiles = result.pendingImportProfiles || [];
    
    if (allProfiles.length === 0) {
        console.log('⚠️ IMPORT: No profiles to process');
        showToast('No profiles to process', 'warning');
        return;
    }
    
    // Get only the number of profiles we should process today
    const profilesToProcess = allProfiles.slice(0, profilesPerDay);
    
    console.log(`🚀 IMPORT: Processing ${profilesToProcess.length} of ${allProfiles.length} profiles`);
    
    // Store the profiles to process and trigger automation
    importedProfiles = profilesToProcess;
    
    // Trigger the combined automation
    if (window.startCombinedAutomation) {
        window.startCombinedAutomation();
    }
    
    showToast(`Starting scheduled import: ${profilesToProcess.length} profiles`, 'success');
}

// --- PROGRESS ANALYTICS --- //
async function loadProgressAnalytics() {
    try {
        // Get current usage stats and limits
        const storage = await chrome.storage.local.get(['dailyCounts', 'userData']);
        const dailyCounts = storage.dailyCounts || {};
        const userData = storage.userData || {};
        const plan = userData.plan || {};

        // Daily Comments
        const commentsUsed = dailyCounts.comments || 0;
        const commentsLimit = plan.monthlyComments || 1500;
        const commentsPercentage = commentsLimit > 0 ? Math.min((commentsUsed / commentsLimit) * 100, 100) : 0;
        
        const dailyCommentsBar = document.getElementById('daily-comments-bar');
        const dailyCommentsProgress = document.getElementById('daily-comments-progress');
        if (dailyCommentsBar && dailyCommentsProgress) {
            dailyCommentsBar.style.width = `${commentsPercentage}%`;
            dailyCommentsProgress.textContent = `${commentsUsed}/${commentsLimit}`;
        }

        // Daily Likes
        const likesUsed = dailyCounts.likes || 0;
        const likesLimit = plan.monthlyLikes || 3000;
        const likesPercentage = likesLimit > 0 ? Math.min((likesUsed / likesLimit) * 100, 100) : 0;
        
        const dailyLikesBar = document.getElementById('daily-likes-bar');
        const dailyLikesProgress = document.getElementById('daily-likes-progress');
        if (dailyLikesBar && dailyLikesProgress) {
            dailyLikesBar.style.width = `${likesPercentage}%`;
            dailyLikesProgress.textContent = `${likesUsed}/${likesLimit}`;
        }

        // Weekly Target (sum of all actions)
        const weeklyUsed = (dailyCounts.comments || 0) + (dailyCounts.likes || 0) + (dailyCounts.shares || 0) + (dailyCounts.follows || 0);
        const weeklyGoal = 300; // Can be made dynamic
        const weeklyPercentage = weeklyGoal > 0 ? Math.min((weeklyUsed / weeklyGoal) * 100, 100) : 0;
        
        const weeklyProgressBar = document.getElementById('weekly-progress-bar');
        const weeklyProgressText = document.getElementById('weekly-progress-text');
        if (weeklyProgressBar && weeklyProgressText) {
            weeklyProgressBar.style.width = `${weeklyPercentage}%`;
            weeklyProgressText.textContent = `${weeklyUsed}/${weeklyGoal}`;
        }

        // Monthly Goal
        const monthlyUsed = weeklyUsed * 4; // Rough estimate
        const monthlyGoal = 1000;
        const monthlyPercentage = monthlyGoal > 0 ? Math.min((monthlyUsed / monthlyGoal) * 100, 100) : 0;
        
        const monthlyProgressBar = document.getElementById('monthly-progress-bar');
        const monthlyProgressText = document.getElementById('monthly-progress-text');
        if (monthlyProgressBar && monthlyProgressText) {
            monthlyProgressBar.style.width = `${monthlyPercentage}%`;
            monthlyProgressText.textContent = `${monthlyUsed}/${monthlyGoal}`;
        }

        // Success Rate (actions completed vs attempted)
        const totalActions = weeklyUsed;
        const successRate = totalActions > 0 ? 85 : 0; // Can be calculated from actual success/failure stats
        
        const successRateBar = document.getElementById('success-rate-bar');
        const successRateText = document.getElementById('success-rate-text');
        if (successRateBar && successRateText) {
            successRateBar.style.width = `${successRate}%`;
            successRateText.textContent = `${successRate}%`;
        }

        console.log('Progress analytics loaded with real data:', { commentsUsed, likesUsed, weeklyUsed, monthlyUsed });
    } catch (error) {
        console.error('Failed to load progress analytics:', error);
    }
}

// --- LIVE PROGRESS MONITORING --- //
let progressMonitorInterval$1 = null;

function startProgressMonitoring$1() {
    // Clear any existing interval
    if (progressMonitorInterval$1) {
        clearInterval(progressMonitorInterval$1);
    }

    // Start monitoring
    progressMonitorInterval$1 = setInterval(async () => {
        try {
            const result = await chrome.storage.local.get('liveProgress');
            const progress = result.liveProgress;

            const progressSection = document.getElementById('live-progress-section');
            const statusText = document.getElementById('live-status-text');
            const currentStep = document.getElementById('live-current-step');
            const progressBar = document.getElementById('live-progress-bar');
            const progressPercentage = document.getElementById('live-progress-percentage');
            const progressDetail = document.getElementById('live-progress-detail');

            if (progress && progress.active) {
                // Show progress section
                if (progressSection) progressSection.style.display = 'block';

                // Update status
                if (statusText) {
                    const statusLabel = progress.type === 'bulk_processing' ? '🤖 Bulk Processing' : '🤝 People Search';
                    statusText.textContent = statusLabel;
                    statusText.style.color = '#28a745';
                }

                // Update current step
                if (currentStep) {
                    currentStep.textContent = progress.currentStep || 'Processing...';
                }

                // Update progress bar
                const percentage = progress.percentage || 0;
                if (progressBar) {
                    progressBar.style.width = `${percentage}%`;
                }
                if (progressPercentage) {
                    progressPercentage.textContent = `${percentage}%`;
                }

                // Update detail
                if (progressDetail) {
                    progressDetail.textContent = `${progress.current || 0}/${progress.total || 0} completed`;
                }
            } else {
                // Hide progress section when not active
                if (progressSection) progressSection.style.display = 'none';
            }
        } catch (error) {
            console.error('Error monitoring progress:', error);
        }
    }, 1000); // Update every second

    console.log('✅ Live progress monitoring started');
}

// --- PROGRESS BAR MANAGEMENT --- //
function showProgressBar() {
    const container = document.getElementById('progress-container');
    if (container) {
        container.style.display = 'block';
    }
}

function hideProgressBar() {
    const container = document.getElementById('progress-container');
    if (container) {
        container.style.display = 'none';
    }
    // Reset progress start time for next run
    window.progressStartTime = null;
}

function updateProgressBar$1(current, total, keywordIndex, totalKeywords, actionsCompleted, currentAction) {
    const progressBar = document.getElementById('progress-bar');
    const progressText = document.getElementById('progress-text');
    const progressStats = document.getElementById('progress-stats');
    const progressKeywords = document.getElementById('progress-keywords');
    const progressActions = document.getElementById('progress-actions');

    if (!progressBar) return;

    const percentage = total > 0 ? (current / total) * 100 : 0;
    progressBar.style.width = `${percentage}%`;

    // Calculate time estimates
    const now = Date.now();
    if (!window.progressStartTime) {
        window.progressStartTime = now;
    }

    let timeEstimate = '';

    if (progressText) {
        progressText.textContent = (currentAction) + timeEstimate;
    }

    if (progressStats) {
        progressStats.textContent = `${current}/${total} posts (${percentage.toFixed(1)}%)`;
    }

    if (progressKeywords) {
        progressKeywords.textContent = `Keyword: ${keywordIndex}/${totalKeywords}`;
    }

    if (progressActions) {
        progressActions.textContent = `Actions: ${actionsCompleted} completed`;
    }

    console.log(`PROGRESS: ${percentage.toFixed(1)}% - ${current}/${total} posts, keyword ${keywordIndex}/${totalKeywords}, actions: ${actionsCompleted}`);
}

/**
 * Sync local storage statistics to backend API
 * This ensures backend always has the latest local values
 */
async function syncLocalStatsToBackend() {
    try {
        console.log('📤 DASHBOARD: Syncing local stats to backend...');
        
        const storage = await chrome.storage.local.get([
            'authToken',
            'apiBaseUrl',
            'engagementStatistics'
        ]);
        
        const token = storage.authToken;
        const apiUrl = storage.apiBaseUrl || API_CONFIG.BASE_URL;
        const localStats = storage.engagementStatistics;
        
        if (!token) {
            console.log('⚠️ DASHBOARD: No auth token, skipping sync');
            return false;
        }
        
        if (!localStats || !localStats.dailyStats) {
            console.log('⚠️ DASHBOARD: No local stats to sync');
            return false;
        }
        
        // Get today's date key
        const now = new Date();
        const dateKey = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
        
        // Get today's stats from local storage
        const todayStats = localStats.dailyStats?.[dateKey] || {};
        const localLikes = todayStats.likes || 0;
        const localComments = todayStats.comments || 0;
        const localShares = todayStats.shares || 0;
        const localFollows = todayStats.follows || 0;
        const localConnections = todayStats.connections || 0;
        
        // Also get AI stats if available
        const localAiPosts = todayStats.aiPosts || 0;
        const localAiComments = todayStats.aiComments || 0;
        const localAiTopics = todayStats.aiTopicLines || 0;
        
        console.log('📊 DASHBOARD: Local stats for', dateKey, '-', {
            likes: localLikes,
            comments: localComments,
            shares: localShares,
            follows: localFollows,
            connections: localConnections,
            aiPosts: localAiPosts,
            aiComments: localAiComments,
            aiTopics: localAiTopics
        });
        
        // Sync to backend API - SET the values to match local
        const response = await fetch(`${apiUrl}/api/usage/sync`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                likes: localLikes,
                comments: localComments,
                shares: localShares,
                follows: localFollows,
                connections: localConnections,
                aiPosts: localAiPosts,
                aiComments: localAiComments,
                aiTopicLines: localAiTopics,
                date: dateKey
            })
        });
        
        if (response.ok) {
            const result = await response.json();
            console.log('✅ DASHBOARD: Local stats synced to backend successfully', result);
            
            // Save last sync timestamp
            await chrome.storage.local.set({ 
                lastSyncTimestamp: Date.now(),
                lastSyncedStats: {
                    likes: localLikes,
                    comments: localComments,
                    shares: localShares,
                    follows: localFollows,
                    connections: localConnections
                }
            });
            
            return true;
        } else {
            // Silently fail for 405 (Method Not Allowed) - endpoint may not be implemented
            if (response.status !== 405) {
                const errorText = await response.text();
                console.warn('⚠️ DASHBOARD: Sync response not OK:', response.status, errorText);
            }
            return false;
        }
        
    } catch (error) {
        console.error('❌ DASHBOARD: Failed to sync local stats to backend:', error);
        return false;
    }
}

// --- ACTIVE WORKINGS FUNCTIONS --- //
async function updateActiveWorkings() {
    try {
        const storage = await chrome.storage.local.get([
            'bulkProcessingActive',
            'peopleSearchActive',
            'importAutomationActive',
            'importProgress'
        ]);
        
        const activeWorkingsSection = document.getElementById('active-workings-section');
        const activeCommenter = document.getElementById('active-commenter');
        const activeNetworking = document.getElementById('active-networking');
        const activeImport = document.getElementById('active-import');
        
        let hasAnyActive = false;
        
        // Update Commenter
        if (activeCommenter) {
            if (storage.bulkProcessingActive) {
                activeCommenter.style.display = 'block';
                hasAnyActive = true;
            } else {
                activeCommenter.style.display = 'none';
            }
        }
        
        // Update Networking
        if (activeNetworking) {
            if (storage.peopleSearchActive) {
                activeNetworking.style.display = 'block';
                hasAnyActive = true;
            } else {
                activeNetworking.style.display = 'none';
            }
        }
        
        // Update Import
        if (activeImport) {
            if (storage.importAutomationActive) {
                activeImport.style.display = 'block';
                hasAnyActive = true;
                // Update status text
                const statusEl = document.getElementById('active-import-status');
                if (statusEl && storage.importProgress) {
                    statusEl.textContent = `Processing: ${storage.importProgress.current || 0}/${storage.importProgress.total || 0}`;
                }
            } else {
                activeImport.style.display = 'none';
            }
        }
        
        // Show/hide the whole section
        if (activeWorkingsSection) {
            activeWorkingsSection.style.display = hasAnyActive ? 'block' : 'none';
        }
        
    } catch (error) {
        console.error('Failed to update active workings:', error);
    }
}

// Set up dashboard stop button listeners
function setupDashboardStopButtons() {
    const stopCommenter = document.getElementById('stop-commenter-dashboard');
    const stopNetworking = document.getElementById('stop-networking-dashboard');
    const stopImport = document.getElementById('stop-import-dashboard');
    
    if (stopCommenter) {
        stopCommenter.addEventListener('click', async () => {
            chrome.runtime.sendMessage({ action: 'stopBulkProcessing' }, (response) => {
                if (response && response.success) {
                    showNotification('✅ Bulk commenting stopped', 'success');
                }
            });
            await chrome.storage.local.set({ bulkProcessingActive: false });
            updateActiveWorkings();
        });
    }
    
    if (stopNetworking) {
        stopNetworking.addEventListener('click', async () => {
            chrome.runtime.sendMessage({ action: 'stopPeopleSearch' }, (response) => {
                if (response && response.success) {
                    showNotification('✅ Networking stopped', 'success');
                }
            });
            await chrome.storage.local.set({ peopleSearchActive: false });
            updateActiveWorkings();
        });
    }
    
    if (stopImport) {
        stopImport.addEventListener('click', async () => {
            chrome.runtime.sendMessage({ action: 'stopImportAutomation' }, (response) => {
                if (response && response.success) {
                    showNotification('✅ Import automation stopped', 'success');
                }
            });
            await chrome.storage.local.set({ importAutomationActive: false, importAutomationType: null });
            updateActiveWorkings();
        });
    }
}

// --- DASHBOARD FUNCTIONS --- //
async function loadDashboard() {
    try {
        console.log('📊 DASHBOARD: Loading stats from local storage...');
        
        // Update active workings display
        updateActiveWorkings();
        const storage = await chrome.storage.local.get(['authToken', 'apiBaseUrl', 'userData', 'engagementStatistics']);
        const token = storage.authToken;
        const apiUrl = storage.apiBaseUrl || API_CONFIG.BASE_URL;
        const localStats = storage.engagementStatistics;
        console.log('📊 DASHBOARD: Local stats:', localStats);

        if (!token) {
            console.error('No auth token found');
            return;
        }
        
        // STEP 1: Show local stats immediately for instant feedback (with daily limits)
        // Get daily limits from storage
        const limitsStorage = await chrome.storage.local.get(['dailyLimits']);
        const dailyLimits = limitsStorage.dailyLimits || {
            comments: 30,
            likes: 60,
            shares: 15,
            follows: 30
        };
        
        // Update daily limits display
        const dailyCommentsLimitEl = document.getElementById('daily-comments-limit');
        const dailyLikesLimitEl = document.getElementById('daily-likes-limit');
        const dailySharesLimitEl = document.getElementById('daily-shares-limit');
        const dailyFollowsLimitEl = document.getElementById('daily-follows-limit');
        const dailyConnectionsLimitEl = document.getElementById('daily-connections-limit');
        
        if (dailyCommentsLimitEl) dailyCommentsLimitEl.textContent = dailyLimits.comments || 30;
        if (dailyLikesLimitEl) dailyLikesLimitEl.textContent = dailyLimits.likes || 60;
        if (dailySharesLimitEl) dailySharesLimitEl.textContent = dailyLimits.shares || 15;
        if (dailyFollowsLimitEl) dailyFollowsLimitEl.textContent = dailyLimits.follows || 30;
        if (dailyConnectionsLimitEl) dailyConnectionsLimitEl.textContent = dailyLimits.connections || 50;
        
        if (localStats) {
            const now = new Date();
            const dateKey = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
            const todayStats = localStats.dailyStats?.[dateKey] || {};
            
            // Update local activity boxes (just numbers, limits already set above)
            const localCommentsEl = document.getElementById('local-comments');
            const localLikesEl = document.getElementById('local-likes');
            const localSharesEl = document.getElementById('local-shares');
            const localFollowsEl = document.getElementById('local-follows');
            const localConnectionsEl = document.getElementById('local-connections');
            
            if (localCommentsEl) localCommentsEl.textContent = todayStats.comments || 0;
            if (localLikesEl) localLikesEl.textContent = todayStats.likes || 0;
            if (localSharesEl) localSharesEl.textContent = todayStats.shares || 0;
            if (localFollowsEl) localFollowsEl.textContent = todayStats.follows || 0;
            if (localConnectionsEl) localConnectionsEl.textContent = todayStats.connections || 0;
            
            console.log('⚡ DASHBOARD: Showing local stats instantly with daily limits:', dailyLimits);
        }
        
        // STEP 2: Sync local stats to backend
        await syncLocalStatsToBackend();

        // Fetch daily usage from backend
        const response = await fetch(`${apiUrl}/api/usage/daily`, {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });

        if (!response.ok) {
            throw new Error('Failed to fetch usage data');
        }

        const usageData = await response.json();

        if (!usageData.success) {
            throw new Error(usageData.error || 'Failed to load usage');
        }

        // Update dashboard with backend data
        const usage = usageData.usage;
        const limits = usageData.limits;
        const plan = storage.userData?.plan;

        // Update dashboard numbers with limits
        const todayComments = usage.comments || 0;
        const todayLikes = usage.likes || 0;
        const todayShares = usage.shares || 0;
        const todayFollows = usage.follows || 0;
        const todayConnections = usage.connections || 0;
        const todayAiPosts = usage.aiPosts || 0;
        const todayAiComments = usage.aiComments || 0;
        const todayBonusAiComments = usage.bonusAiComments || 0;
        const todayAiTopics = usage.aiTopicLines || 0;

        // Update API usage progress bars with backend data
        const apiCommentsProgress = document.getElementById('api-comments-progress');
        const apiCommentsBar = document.getElementById('api-comments-bar');
        const apiLikesProgress = document.getElementById('api-likes-progress');
        const apiLikesBar = document.getElementById('api-likes-bar');
        const apiSharesProgress = document.getElementById('api-shares-progress');
        const apiSharesBar = document.getElementById('api-shares-bar');
        const apiFollowsProgress = document.getElementById('api-follows-progress');
        const apiFollowsBar = document.getElementById('api-follows-bar');
        const apiConnectionsProgress = document.getElementById('api-connections-progress');
        const apiConnectionsBar = document.getElementById('api-connections-bar');
        const apiAiPostsProgress = document.getElementById('api-ai-posts-progress');
        const apiAiPostsBar = document.getElementById('api-ai-posts-bar');
        const apiAiCommentsProgress = document.getElementById('api-ai-comments-progress');
        const apiAiCommentsBar = document.getElementById('api-ai-comments-bar');
        const apiAiTopicsProgress = document.getElementById('api-ai-topics-progress');
        const apiAiTopicsBar = document.getElementById('api-ai-topics-bar');
        
        // Helper function to get limit value (handles 0 as valid value)
        const getLimit = (value, fallback) => value !== undefined && value !== null ? value : fallback;
        
        // Comments
        const commentsLimit = getLimit(limits.comments, 0);
        if (apiCommentsProgress) apiCommentsProgress.textContent = `${todayComments}/${commentsLimit}`;
        if (apiCommentsBar) apiCommentsBar.style.width = commentsLimit > 0 ? `${Math.min((todayComments / commentsLimit) * 100, 100)}%` : '0%';
        
        // Likes
        const likesLimit = getLimit(limits.likes, 0);
        if (apiLikesProgress) apiLikesProgress.textContent = `${todayLikes}/${likesLimit}`;
        if (apiLikesBar) apiLikesBar.style.width = likesLimit > 0 ? `${Math.min((todayLikes / likesLimit) * 100, 100)}%` : '0%';
        
        // Shares
        const sharesLimit = getLimit(limits.shares, 0);
        if (apiSharesProgress) apiSharesProgress.textContent = `${todayShares}/${sharesLimit}`;
        if (apiSharesBar) apiSharesBar.style.width = sharesLimit > 0 ? `${Math.min((todayShares / sharesLimit) * 100, 100)}%` : '0%';
        
        // Follows
        const followsLimit = getLimit(limits.follows, 0);
        if (apiFollowsProgress) apiFollowsProgress.textContent = `${todayFollows}/${followsLimit}`;
        if (apiFollowsBar) apiFollowsBar.style.width = followsLimit > 0 ? `${Math.min((todayFollows / followsLimit) * 100, 100)}%` : '0%';
        
        // Connections
        const connectionsLimit = getLimit(limits.connections, 0);
        if (apiConnectionsProgress) apiConnectionsProgress.textContent = `${todayConnections}/${connectionsLimit}`;
        if (apiConnectionsBar) apiConnectionsBar.style.width = connectionsLimit > 0 ? `${Math.min((todayConnections / connectionsLimit) * 100, 100)}%` : '0%';
        
        // AI Posts
        const aiPostsLimit = getLimit(limits.aiPosts, 0);
        if (apiAiPostsProgress) apiAiPostsProgress.textContent = `${todayAiPosts}/${aiPostsLimit}`;
        if (apiAiPostsBar) apiAiPostsBar.style.width = aiPostsLimit > 0 ? `${Math.min((todayAiPosts / aiPostsLimit) * 100, 100)}%` : '0%';
        
        // AI Comments
        const aiCommentsLimit = getLimit(limits.aiComments, 0);
        const totalAvailableAiComments = aiCommentsLimit + todayBonusAiComments;
        if (apiAiCommentsProgress) apiAiCommentsProgress.textContent = `${todayAiComments}/${totalAvailableAiComments}`;
        if (apiAiCommentsBar) apiAiCommentsBar.style.width = totalAvailableAiComments > 0 ? `${Math.min((todayAiComments / totalAvailableAiComments) * 100, 100)}%` : '0%';
        
        // AI Topics
        const aiTopicsLimit = getLimit(limits.aiTopicLines, 0);
        if (apiAiTopicsProgress) apiAiTopicsProgress.textContent = `${todayAiTopics}/${aiTopicsLimit}`;
        if (apiAiTopicsBar) apiAiTopicsBar.style.width = aiTopicsLimit > 0 ? `${Math.min((todayAiTopics / aiTopicsLimit) * 100, 100)}%` : '0%';

        // Import Profiles
        const apiImportProfilesProgress = document.getElementById('api-import-profiles-progress');
        const apiImportProfilesBar = document.getElementById('api-import-profiles-bar');
        const todayImportProfiles = usage.importProfiles || 0;
        const importProfilesLimit = getLimit(limits.importProfiles, 0);
        if (apiImportProfilesProgress) apiImportProfilesProgress.textContent = `${todayImportProfiles}/${importProfilesLimit}`;
        if (apiImportProfilesBar) apiImportProfilesBar.style.width = `${Math.min((todayImportProfiles / importProfilesLimit) * 100, 100)}%`;

        // Calculate weekly total (approximate from today's usage)
        const weekTotal = (todayComments + todayLikes + todayShares + todayFollows) * 7;
        if (elements.weekTotal) elements.weekTotal.textContent = weekTotal;

        // Calculate response rate based on engagement
        const totalEngagements = todayComments + todayLikes + todayShares + todayFollows;
        const responseRate = totalEngagements > 0 ? Math.min(Math.round((todayComments / totalEngagements) * 100), 100) : 0;
        if (elements.responseRate) elements.responseRate.textContent = `${responseRate}%`;

        // Display plan name
        if (plan && elements.accountPlan) {
            elements.accountPlan.textContent = plan.name;
        }

        // Show upgrade prompt if limits reached
        checkAndShowUpgradePrompts(usage, limits, usageData.features);

        console.log('✅ DASHBOARD: Backend data loaded (synced from local) -', {
            today: { comments: todayComments, likes: todayLikes, shares: todayShares, follows: todayFollows, connections: todayConnections },
            limits,
            plan: plan?.name,
            features: usageData.features
        });
        
        // Load scheduled posts display
        loadScheduledPosts$1();

    } catch (error) {
        console.error('Failed to load dashboard:', error);
    }
}

// --- SCHEDULED POSTS FUNCTIONS --- //

/**
 * Load and display scheduled posts on dashboard
 */
async function loadScheduledPosts$1() {
    try {
        console.log('📅 DASHBOARD: Loading scheduled posts...');
        const storage = await chrome.storage.local.get(['scheduledPosts', 'contentCalendar', 'postSchedulerActive', 'postSchedulerStatus', 'outsideBusinessHoursNotification']);
        
        // Merge scheduledPosts and contentCalendar (Content Calendar from Writer tab)
        const scheduledPosts = storage.scheduledPosts || [];
        const contentCalendar = storage.contentCalendar || [];
        
        // Convert contentCalendar items to match scheduledPosts format
        const calendarPosts = contentCalendar
            .filter(event => event.status === 'scheduled' && event.type === 'post')
            .map(event => ({
                id: event.id,
                content: event.content || event.description || event.title,
                scheduledFor: event.scheduledDate,
                scheduledDate: event.scheduledDate,
                status: 'pending',
                source: 'contentCalendar'
            }));
        
        // Combine both sources
        const allScheduledPosts = [...scheduledPosts, ...calendarPosts];
        
        console.log('📅 DASHBOARD: Found scheduled posts:', allScheduledPosts.length, '(scheduledPosts:', scheduledPosts.length, ', contentCalendar:', calendarPosts.length, ')');
        
        const section = document.getElementById('scheduled-posts-section');
        const countEl = document.getElementById('scheduled-posts-count');
        const listEl = document.getElementById('scheduled-posts-list');
        
        // Always show the section
        if (section) {
            section.style.display = 'block';
        }
        
        // Filter to show only pending posts from all sources
        const pendingPosts = allScheduledPosts.filter(p => !p.status || p.status === 'pending' || p.status === 'rescheduled' || p.status === 'scheduled');
        
        if (countEl) countEl.textContent = pendingPosts.length;
        
        if (listEl) {
            if (pendingPosts.length > 0) {
                listEl.innerHTML = pendingPosts.map(post => {
                    const scheduledDate = new Date(post.scheduledFor || post.scheduledDate);
                    const now = new Date();
                    const timeUntil = scheduledDate - now;
                    
                    let timeText = '';
                    if (timeUntil <= 0) {
                        timeText = '<span style="color: #f59e0b;">Due now</span>';
                    } else if (timeUntil < 60000) {
                        timeText = '<span style="color: #22c55e;">< 1 min</span>';
                    } else if (timeUntil < 3600000) {
                        timeText = `<span style="color: #693fe9;">${Math.round(timeUntil / 60000)} min</span>`;
                    } else if (timeUntil < 86400000) {
                        const hours = Math.floor(timeUntil / 3600000);
                        const mins = Math.round((timeUntil % 3600000) / 60000);
                        timeText = `<span style="color: #666;">${hours}h ${mins}m</span>`;
                    } else {
                        const days = Math.floor(timeUntil / 86400000);
                        const hours = Math.floor((timeUntil % 86400000) / 3600000);
                        timeText = `<span style="color: #999;">${days}d ${hours}h</span>`;
                    }
                    
                    const contentPreview = (post.content || '').substring(0, 60) + (post.content?.length > 60 ? '...' : '');
                    const statusBadge = post.status === 'rescheduled' ? '<span style="background: #fff3cd; color: #856404; padding: 2px 6px; border-radius: 4px; font-size: 9px; margin-left: 5px;">Rescheduled</span>' : '';
                    
                    return `
                        <div style="padding: 10px; background: #f8f9fa; border-radius: 8px; margin-bottom: 8px; border-left: 3px solid #a855f7;">
                            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 4px;">
                                <span style="font-size: 10px; color: #666;">
                                    <span class="icon icon-calendar"></span> ${scheduledDate.toLocaleDateString()} ${scheduledDate.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                                    ${statusBadge}
                                </span>
                                <span style="font-size: 11px; font-weight: 600;">${timeText}</span>
                            </div>
                            <div style="font-size: 11px; color: #333; line-height: 1.4;">${contentPreview}</div>
                        </div>
                    `;
                }).join('');
            } else {
                listEl.innerHTML = `
                    <div style="padding: 15px; background: #f8f9fa; border-radius: 8px; text-align: center; color: #999; font-size: 11px;">
                        <span class="icon icon-calendar" style="font-size: 20px; display: block; margin-bottom: 6px; opacity: 0.5;"></span>
                        No scheduled posts yet.<br>
                        <span style="font-size: 10px;">Go to Writer tab to schedule posts.</span>
                    </div>
                `;
            }
        }
        
        // Update post scheduler active status
        updatePostSchedulerStatus(storage);
        
        // Update business hours warning
        updateBusinessHoursWarning(storage);
        
    } catch (error) {
        console.error('Failed to load scheduled posts:', error);
    }
}

/**
 * Update post scheduler active status on dashboard
 */
function updatePostSchedulerStatus(storage) {
    const activePostScheduler = document.getElementById('active-post-scheduler');
    const activeWorkingsSection = document.getElementById('active-workings-section');
    const statusEl = document.getElementById('active-post-scheduler-status');
    
    if (activePostScheduler) {
        if (storage.postSchedulerActive) {
            activePostScheduler.style.display = 'block';
            if (activeWorkingsSection) activeWorkingsSection.style.display = 'block';
            
            // Update status text based on postSchedulerStatus
            if (statusEl && storage.postSchedulerStatus) {
                const status = storage.postSchedulerStatus;
                if (status.status === 'posting') {
                    statusEl.textContent = `Posting: ${status.content || 'Publishing to LinkedIn...'}`;
                } else if (status.status === 'completed') {
                    statusEl.textContent = 'Post published successfully!';
                } else if (status.status === 'failed') {
                    statusEl.textContent = `Failed: ${status.error || 'Unknown error'}`;
                }
            }
        } else {
            activePostScheduler.style.display = 'none';
        }
    }
}

/**
 * Update business hours warning display
 */
function updateBusinessHoursWarning(storage) {
    const warningEl = document.getElementById('business-hours-warning');
    const messageEl = document.getElementById('business-hours-message');
    
    if (warningEl && storage.outsideBusinessHoursNotification) {
        const notification = storage.outsideBusinessHoursNotification;
        // Show warning if notification was shown in the last 30 minutes
        if (notification.shown && (Date.now() - notification.timestamp) < 30 * 60 * 1000) {
            warningEl.style.display = 'block';
            if (messageEl) messageEl.textContent = notification.message;
        } else {
            warningEl.style.display = 'none';
        }
    } else if (warningEl) {
        warningEl.style.display = 'none';
    }
}

// --- ANALYTICS FUNCTIONS --- //

/**
 * Load and display automation history (post records)
 */
async function loadAutomationHistory() {
    try {
        const { automationPostRecords = [] } = await chrome.storage.local.get('automationPostRecords');
        const { processingHistory = [] } = await chrome.storage.local.get('processingHistory');
        
        // Filter automation sessions only
        const automationSessions = processingHistory.filter(s => s.type === 'automation');
        
        // Update stats
        const totalSessions = automationSessions.length;
        const totalPosts = automationPostRecords.length;
        const commentsGenerated = automationPostRecords.filter(r => r.generatedComment && r.generatedComment.length > 0).length;
        const successRate = totalPosts > 0 ? Math.round((automationPostRecords.filter(r => r.status === 'success').length / totalPosts) * 100) : 0;
        
        // Update stats display
        const totalSessionsEl = document.getElementById('automation-total-sessions');
        const postsProcessedEl = document.getElementById('automation-posts-processed');
        const commentsGeneratedEl = document.getElementById('automation-comments-generated');
        const successRateEl = document.getElementById('automation-success-rate');
        
        if (totalSessionsEl) totalSessionsEl.textContent = totalSessions;
        if (postsProcessedEl) postsProcessedEl.textContent = totalPosts;
        if (commentsGeneratedEl) commentsGeneratedEl.textContent = commentsGenerated;
        if (successRateEl) successRateEl.textContent = successRate + '%';
        
        // Render table
        const tableBody = document.getElementById('automation-history-table-body');
        if (!tableBody) return;
        
        if (automationPostRecords.length === 0) {
            tableBody.innerHTML = `
                <tr>
                    <td colspan="7" style="padding: 20px; text-align: center; color: #6c757d;">
                        No automation history found. Start Bulk Processing to see post details here.
                    </td>
                </tr>
            `;
            return;
        }
        
        // Get search term and filter status
        const searchInput = document.getElementById('automation-search');
        const searchTerm = searchInput?.value?.toLowerCase() || '';
        const filterStatus = document.getElementById('automation-history-filter-status')?.value || 'all';
        
        let filteredRecords = automationPostRecords;
        if (filterStatus !== 'all') {
            filteredRecords = filteredRecords.filter(r => r.status === filterStatus);
        }
        if (searchTerm) {
            filteredRecords = filteredRecords.filter(r => {
                const keywords = (r.keywords || '').toLowerCase();
                const author = (r.authorName || '').toLowerCase();
                const content = (r.postContent || '').toLowerCase();
                const comment = (r.generatedComment || '').toLowerCase();
                return keywords.includes(searchTerm) || author.includes(searchTerm) || 
                       content.includes(searchTerm) || comment.includes(searchTerm);
            });
        }
        
        tableBody.innerHTML = filteredRecords.slice(0, 100).map(record => {
            const date = new Date(record.timestamp);
            const dateStr = date.toLocaleDateString('en-GB') + ' ' + date.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' });
            
            // Truncate long text
            const truncate = (text, maxLen) => {
                if (!text) return '-';
                return text.length > maxLen ? text.substring(0, maxLen) + '...' : text;
            };
            
            // Format actions with view button if post link exists
            const actionsArr = [];
            if (record.actions?.liked) actionsArr.push('👍');
            if (record.actions?.commented) actionsArr.push('💬');
            if (record.actions?.shared) actionsArr.push('🔄');
            if (record.actions?.followed) actionsArr.push('👤');
            
            // Build post URL from URN
            let postUrl = '';
            if (record.postUrn) {
                const urn = record.postUrn.includes('urn:li:activity:') ? record.postUrn : `urn:li:activity:${record.postUrn}`;
                postUrl = `https://www.linkedin.com/feed/update/${urn}/`;
            }
            
            // Actions column with icons and view button
            const actionsHtml = `
                <span style="margin-right: 4px;">${actionsArr.join(' ')}</span>
                ${postUrl ? `<a href="${postUrl}" target="_blank" style="background: #693fe9; color: white; padding: 2px 6px; border-radius: 3px; font-size: 10px; text-decoration: none;" title="View Post">👁️</a>` : ''}
            `;
            
            const statusIcon = record.status === 'success' ? '✅' : record.status === 'failed' ? '❌' : '⏳';
            
            return `
                <tr style="border-bottom: 1px solid #eee;">
                    <td style="padding: 8px; font-size: 11px;">${truncate(record.keywords, 30)}</td>
                    <td style="padding: 8px; font-size: 11px; font-weight: 600;">${truncate(record.authorName, 20)}</td>
                    <td style="padding: 8px; font-size: 10px; max-width: 180px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;" title="${(record.postContent || '').replace(/"/g, '&quot;')}">${truncate(record.postContent, 50)}</td>
                    <td style="padding: 8px; font-size: 10px; max-width: 180px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; color: #693fe9;" title="${(record.generatedComment || '').replace(/"/g, '&quot;')}">${truncate(record.generatedComment, 50)}</td>
                    <td style="padding: 8px; text-align: center; font-size: 12px;">${actionsHtml}</td>
                    <td style="padding: 8px; text-align: center; font-size: 11px;">${statusIcon}</td>
                    <td style="padding: 8px; font-size: 10px;">${dateStr}</td>
                </tr>
            `;
        }).join('');
        
        console.log('✅ Automation history loaded:', automationPostRecords.length, 'records');
    } catch (error) {
        console.error('Error loading automation history:', error);
    }
}

/**
 * Load and display networking history
 */
async function loadNetworkingHistory() {
    try {
        const { processingHistory = [] } = await chrome.storage.local.get('processingHistory');
        
        // Filter networking sessions only
        const networkingSessions = processingHistory.filter(s => s.type === 'networking');
        
        // Calculate stats
        const totalSessions = networkingSessions.length;
        const connectionsSent = networkingSessions.reduce((sum, s) => sum + (s.successful || 0), 0);
        const profilesFound = networkingSessions.reduce((sum, s) => sum + (s.processed || 0), 0);
        const completedSessions = networkingSessions.filter(s => s.status === 'completed').length;
        const successRate = totalSessions > 0 ? Math.round((completedSessions / totalSessions) * 100) : 0;
        
        // Update stats display
        const totalSessionsEl = document.getElementById('networking-total-sessions');
        const connectionsSentEl = document.getElementById('networking-connections-sent');
        const profilesFoundEl = document.getElementById('networking-profiles-found');
        const successRateEl = document.getElementById('networking-success-rate');
        
        if (totalSessionsEl) totalSessionsEl.textContent = totalSessions;
        if (connectionsSentEl) connectionsSentEl.textContent = connectionsSent;
        if (profilesFoundEl) profilesFoundEl.textContent = profilesFound;
        if (successRateEl) successRateEl.textContent = successRate + '%';
        
        // Render table
        const tableBody = document.getElementById('networking-history-table-body');
        if (!tableBody) return;
        
        // Get search term
        const searchInput = document.getElementById('networking-search');
        const searchTerm = searchInput?.value?.toLowerCase() || '';
        
        // Get filter status
        const filterStatus = document.getElementById('networking-history-filter-status')?.value || 'all';
        
        // Filter sessions by search and status
        let filteredSessions = networkingSessions;
        if (filterStatus !== 'all') {
            filteredSessions = filteredSessions.filter(s => s.status === filterStatus);
        }
        if (searchTerm) {
            filteredSessions = filteredSessions.filter(s => {
                const query = (s.query || s.keywords || '').toLowerCase();
                return query.includes(searchTerm);
            });
        }
        
        if (filteredSessions.length === 0) {
            tableBody.innerHTML = `
                <tr>
                    <td colspan="8" style="padding: 20px; text-align: center; color: #6c757d;">
                        ${searchTerm || filterStatus !== 'all' ? 'No matching sessions found.' : 'No networking history found. Start People Search to see history here.'}
                    </td>
                </tr>
            `;
            return;
        }
        
        tableBody.innerHTML = filteredSessions.slice(0, 50).map(session => {
            const date = new Date(session.startTime || session.endTime);
            const dateStr = date.toLocaleDateString('en-GB') + ' ' + date.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' });
            
            const duration = session.duration ? formatDuration$1(session.duration) : '< 1s';
            const successRate = session.processed > 0 ? Math.round((session.successful / session.processed) * 100) + '%' : '0%';
            
            const statusIcon = session.status === 'completed' ? '✅' : 
                              session.status === 'stopped' ? '⏹️' : 
                              session.status === 'failed' ? '❌' : '⏳';
            
            return `
                <tr style="border-bottom: 1px solid #eee;">
                    <td style="padding: 8px; font-size: 11px;">${session.query || session.keywords || '-'}</td>
                    <td style="padding: 8px; text-align: center; font-size: 11px;">${session.target || 0}</td>
                    <td style="padding: 8px; text-align: center; font-size: 11px;">${session.processed || 0}</td>
                    <td style="padding: 8px; text-align: center; font-size: 11px;">${session.successful || 0}</td>
                    <td style="padding: 8px; text-align: center; font-size: 11px;">${successRate}</td>
                    <td style="padding: 8px; text-align: center; font-size: 11px;">${duration}</td>
                    <td style="padding: 8px; text-align: center; font-size: 11px;">${statusIcon} ${session.status}</td>
                    <td style="padding: 8px; font-size: 10px;">${dateStr}</td>
                </tr>
            `;
        }).join('');
        
        console.log('✅ Networking history loaded:', networkingSessions.length, 'sessions');
    } catch (error) {
        console.error('Error loading networking history:', error);
    }
}

/**
 * Format duration from milliseconds to readable string
 */
function formatDuration$1(ms) {
    if (!ms || ms < 1000) return '< 1s';
    const seconds = Math.floor(ms / 1000);
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    if (minutes > 0) {
        return `${minutes}m ${remainingSeconds}s`;
    }
    return `${seconds}s`;
}

/**
 * Clear automation history
 */
async function clearAutomationHistory() {
    if (!confirm('Are you sure you want to clear all automation post records? This cannot be undone.')) {
        return;
    }
    
    await chrome.storage.local.remove('automationPostRecords');
    
    // Also remove automation sessions from processing history
    const { processingHistory = [] } = await chrome.storage.local.get('processingHistory');
    const filtered = processingHistory.filter(s => s.type !== 'automation');
    await chrome.storage.local.set({ processingHistory: filtered });
    
    alert('Automation history cleared successfully!');
    loadAutomationHistory();
}

/**
 * Clear networking history
 */
async function clearNetworkingHistory() {
    if (!confirm('Are you sure you want to clear all networking history? This cannot be undone.')) {
        return;
    }
    
    // Remove networking sessions from processing history
    const { processingHistory = [] } = await chrome.storage.local.get('processingHistory');
    const filtered = processingHistory.filter(s => s.type !== 'networking');
    await chrome.storage.local.set({ processingHistory: filtered });
    
    alert('Networking history cleared successfully!');
    loadNetworkingHistory();
}

/**
 * Export automation history to CSV
 */
async function exportAutomationHistory() {
    const { automationPostRecords = [] } = await chrome.storage.local.get('automationPostRecords');
    
    if (automationPostRecords.length === 0) {
        alert('No automation records to export.');
        return;
    }
    
    const headers = ['Date', 'Keywords', 'Author', 'Post Content', 'Generated Comment', 'Liked', 'Commented', 'Shared', 'Followed', 'Status'];
    const rows = automationPostRecords.map(r => [
        new Date(r.timestamp).toISOString(),
        r.keywords || '',
        r.authorName || '',
        `"${(r.postContent || '').replace(/"/g, '""')}"`,
        `"${(r.generatedComment || '').replace(/"/g, '""')}"`,
        r.actions?.liked ? 'Yes' : 'No',
        r.actions?.commented ? 'Yes' : 'No',
        r.actions?.shared ? 'Yes' : 'No',
        r.actions?.followed ? 'Yes' : 'No',
        r.status || ''
    ]);
    
    const csv = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `automation-history-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    
    alert('Automation history exported successfully!');
}

/**
 * Export networking history to CSV
 */
async function exportNetworkingHistory() {
    const { processingHistory = [] } = await chrome.storage.local.get('processingHistory');
    const networkingSessions = processingHistory.filter(s => s.type === 'networking');
    
    if (networkingSessions.length === 0) {
        alert('No networking sessions to export.');
        return;
    }
    
    const headers = ['Date', 'Query', 'Target', 'Found', 'Sent', 'Success Rate', 'Duration', 'Status'];
    const rows = networkingSessions.map(s => [
        new Date(s.startTime || s.endTime).toISOString(),
        s.query || s.keywords || '',
        s.target || 0,
        s.processed || 0,
        s.successful || 0,
        s.processed > 0 ? Math.round((s.successful / s.processed) * 100) + '%' : '0%',
        formatDuration$1(s.duration),
        s.status || ''
    ]);
    
    const csv = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `networking-history-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    
    alert('Networking history exported successfully!');
}

// Make delete functions available globally
window.deleteAutomationRecord = async (id) => {
    const { automationPostRecords = [] } = await chrome.storage.local.get('automationPostRecords');
    const filtered = automationPostRecords.filter(r => r.id !== id);
    await chrome.storage.local.set({ automationPostRecords: filtered });
    loadAutomationHistory();
};

window.deleteNetworkingSession = async (id) => {
    const { processingHistory = [] } = await chrome.storage.local.get('processingHistory');
    const filtered = processingHistory.filter(s => s.id !== id);
    await chrome.storage.local.set({ processingHistory: filtered });
    loadNetworkingHistory();
};

window.viewNetworkingSession = (id) => {
    alert('Session details view coming soon!');
};

async function loadAnalytics() {
    try {
        console.log('📊 ANALYTICS: Loading stats from local storage...');
        
        // Trigger background sync to push analytics to website backend
        try {
            chrome.runtime.sendMessage({ action: 'syncAnalytics' }).catch(() => {});
        } catch (e) { /* ignore if background not available */ }
        
        const stats = await chrome.storage.local.get('engagementStatistics');
        let data = stats.engagementStatistics;
        console.log('📊 ANALYTICS: Raw storage data:', data);

        // Initialize if doesn't exist
        if (!data || !data.initialized) {
            console.log('✅ Full extension initialized');
            checkDatabaseStatus();
            data = {
                initialized: true,
                totalComments: 0,
                totalLikes: 0,
                totalShares: 0,
                totalFollows: 0,
                totalPosts: 0,
                dailyStats: {},
                topHashtags: {},
                topEngagedUsers: {},
                lastUpdated: new Date().toISOString()
            };
            await chrome.storage.local.set({ engagementStatistics: data });
        }

        console.log('Analytics: Loading data:', data);
        
        // Get selected period from dropdown
        const periodSelect = document.getElementById('analytics-period');
        const period = parseInt(periodSelect?.value || '7');
        
        // Calculate stats based on period
        let comments = 0, likes = 0, shares = 0, follows = 0;
        
        if (period === 0) {
            // Today only
            const today = new Date().toISOString().split('T')[0];
            const todayStats = data.dailyStats?.[today] || {};
            comments = todayStats.comments || 0;
            likes = todayStats.likes || 0;
            shares = todayStats.shares || 0;
            follows = todayStats.follows || 0;
        } else if (period === 1) {
            // Yesterday only
            const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];
            const yesterdayStats = data.dailyStats?.[yesterday] || {};
            comments = yesterdayStats.comments || 0;
            likes = yesterdayStats.likes || 0;
            shares = yesterdayStats.shares || 0;
            follows = yesterdayStats.follows || 0;
        } else if (data.dailyStats && Object.keys(data.dailyStats).length > 0) {
            // Calculate from daily stats for the period
            const now = new Date();
            const cutoffDate = new Date(now - (period * 86400000));
            
            Object.entries(data.dailyStats).forEach(([dateStr, dayStats]) => {
                const date = new Date(dateStr);
                if (date >= cutoffDate) {
                    comments += dayStats.comments || 0;
                    likes += dayStats.likes || 0;
                    shares += dayStats.shares || 0;
                    follows += dayStats.follows || 0;
                }
            });
        } else {
            // Fallback to total stats
            comments = data.totalComments || 0;
            likes = data.totalLikes || 0;
            shares = data.totalShares || 0;
            follows = data.totalFollows || 0;
        }
        
        // Calculate total engagements
        const totalEngagements = comments + likes + shares + follows;

        // Update totals in Analytics tab - USE DIRECT DOM IDs
        const totalEngagementsEl = document.getElementById('total-engagements');
        const totalCommentsEl = document.getElementById('total-comments');
        const totalLikesEl = document.getElementById('total-likes');
        const totalSharesEl = document.getElementById('total-shares');
        const totalFollowsEl = document.getElementById('total-follows');
        
        if (totalEngagementsEl) totalEngagementsEl.textContent = totalEngagements;
        if (totalCommentsEl) totalCommentsEl.textContent = comments;
        if (totalLikesEl) totalLikesEl.textContent = likes;
        if (totalSharesEl) totalSharesEl.textContent = shares;
        if (totalFollowsEl) totalFollowsEl.textContent = follows;
        
        console.log('Analytics: Updated stats display:', { totalEngagements, comments, likes, shares, follows });

        // Update Dashboard local stats - USE DIRECT DOM IDs
        const localCommentsEl = document.getElementById('local-comments');
        const localLikesEl = document.getElementById('local-likes');
        const localSharesEl = document.getElementById('local-shares');
        const localFollowsEl = document.getElementById('local-follows');
        const localConnectionsEl = document.getElementById('local-connections');
        
        // Get today's stats for dashboard
        const today = new Date().toISOString().split('T')[0];
        const todayStats = data.dailyStats?.[today] || {};
        
        if (localCommentsEl) localCommentsEl.textContent = todayStats.comments || 0;
        if (localLikesEl) localLikesEl.textContent = todayStats.likes || 0;
        if (localSharesEl) localSharesEl.textContent = todayStats.shares || 0;
        if (localFollowsEl) localFollowsEl.textContent = todayStats.follows || 0;
        if (localConnectionsEl) localConnectionsEl.textContent = todayStats.connections || 0;

        // Top hashtags
        if (elements.topHashtags && data.topHashtags) {
            const hashtags = Object.entries(data.topHashtags)
                .sort((a, b) => b[1] - a[1])
                .slice(0, 10);

            if (hashtags.length > 0) {
                elements.topHashtags.innerHTML = hashtags
                    .map(([tag, count]) => `<span class="tag">${tag} (${count})</span>`)
                    .join(' ');
            } else {
                elements.topHashtags.innerHTML = '<p class="empty-state">No hashtag data yet</p>';
            }
        }

        // Top users
        if (elements.topUsers && data.topEngagedUsers) {
            const users = Object.entries(data.topEngagedUsers)
                .sort((a, b) => b[1] - a[1])
                .slice(0, 10);

            if (users.length > 0) {
                elements.topUsers.innerHTML = users
                    .map(([user, count]) => `<div class="content-item"><strong>${user}</strong>: ${count} engagements</div>`)
                    .join('');
            } else {
                elements.topUsers.innerHTML = '<p class="empty-state">No user data yet</p>';
            }
        }
    } catch (error) {
        console.error('Error loading analytics:', error);
    }
}

async function exportStatistics() {
    try {
        // CHECK FEATURE PERMISSION
        const canExport = await featureChecker$1.checkFeature('analytics');
        if (!canExport) {
            console.warn('🚫 CSV Export feature access denied - not available in current plan');
            alert('⬆️ CSV Export requires a paid plan. Please upgrade to export analytics data!');
            
            // Show plan modal for upgrade
            const planModal = document.getElementById('plan-modal');
            if (planModal) {
                planModal.style.display = 'flex';
                loadPlans();
            }
            return;
        }
        
        console.log('📥 EXPORT: Starting statistics export...');
        const stats = await chrome.storage.local.get('engagementStatistics');
        console.log('📥 EXPORT: Retrieved statistics:', stats);

        const data = JSON.stringify(stats.engagementStatistics || {}, null, 2);
        console.log(`📥 EXPORT: Data size: ${data.length} characters`);

        const blob = new Blob([data], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `linkedin-stats-${new Date().toISOString().split('T')[0]}.json`;
        a.click();
        URL.revokeObjectURL(url);

        console.log('✅ EXPORT: Statistics exported successfully');
        alert('Statistics exported successfully!');
    } catch (error) {
        console.error('❌ EXPORT: Error exporting stats:', error);
        alert('Failed to export statistics');
    }
}

async function clearStatistics() {
    console.log('🗑️ CLEAR: User requested to clear statistics');

    if (!confirm('Are you sure you want to clear all statistics? This cannot be undone.')) {
        console.log('🗑️ CLEAR: User cancelled clear operation');
        return;
    }

    console.log('🗑️ CLEAR: Clearing engagement statistics...');
    await chrome.storage.local.remove('engagementStatistics');

    console.log('🗑️ CLEAR: Clearing leads data...');
    await chrome.storage.local.remove('leads');
    await chrome.storage.local.remove('leadsByQuery');

    console.log('✅ CLEAR: All data cleared successfully');
    alert('Statistics and leads cleared successfully');

    console.log('🔄 CLEAR: Refreshing UI...');
    loadAnalytics();
    loadDashboard();
}

// ========== LEADS DATABASE FUNCTIONS ==========

/**
 * Load and display leads from storage
 */
async function loadLeads() {
    try {
        console.log('📊 LOAD LEADS: Starting to load leads from storage...');
        const result = await chrome.storage.local.get(['leads', 'leadsByQuery']);

        console.log('📊 LOAD LEADS: Raw storage result:', result);

        // Handle multiple data formats: array, object, or JSON string
        let leads = result.leads || [];

        console.log('📊 LOAD LEADS: Initial leads value:', leads);
        console.log('📊 LOAD LEADS: Type of leads:', typeof leads);
        console.log('📊 LOAD LEADS: Is array?', Array.isArray(leads));

        // If leads is a string (old JSON format), parse it
        if (typeof leads === 'string') {
            console.log('📊 LOAD LEADS: Leads is a string, parsing JSON...');
            try {
                leads = JSON.parse(leads);
                console.log('📊 LOAD LEADS: Successfully parsed JSON string');
            } catch (e) {
                console.error('❌ LOAD LEADS: Failed to parse JSON string:', e);
                leads = [];
            }
        }

        // If leads is an object with a 'data' property (from storage wrapper), extract it
        if (leads && typeof leads === 'object' && !Array.isArray(leads)) {
            console.log('📊 LOAD LEADS: Leads is an object, checking for data property...');
            if (leads.data && Array.isArray(leads.data)) {
                console.log('📊 LOAD LEADS: Found data array, extracting...');
                leads = leads.data;
            } else {
                console.warn('⚠️ LOAD LEADS: Leads is an object, not an array. Converting to empty array.');
                console.warn('⚠️ LOAD LEADS: Object keys:', Object.keys(leads));
                leads = [];
            }
        }

        // Final safety check - ensure leads is always an array
        if (!Array.isArray(leads)) {
            console.error('❌ LOAD LEADS: Leads is still not an array after conversion! Type:', typeof leads);
            console.error('❌ LOAD LEADS: Value:', leads);
            leads = [];
        }

        let leadsByQuery = result.leadsByQuery || {};

        // Ensure leadsByQuery is an object
        if (typeof leadsByQuery !== 'object' || Array.isArray(leadsByQuery)) {
            // Silent auto-fix: reset to empty object (this is expected on first run)
            leadsByQuery = {};
        }

        console.log(`📊 LOAD LEADS: Found ${leads.length} total leads in storage`);
        console.log('📊 LOAD LEADS: Leads data:', leads);
        console.log('📊 LOAD LEADS: Leads by query:', leadsByQuery);

        // Update statistics - with safety checks
        const totalLeads = leads.length;
        const withEmail = Array.isArray(leads) ? leads.filter(lead => lead && lead.email).length : 0;
        const withPhone = Array.isArray(leads) ? leads.filter(lead => lead && lead.phone).length : 0;
        const connected = Array.isArray(leads) ? leads.filter(lead => lead && (lead.connectionStatus === 'connected' || lead.connectionStatus === 'pending')).length : 0;

        // Update UI elements
        console.log('📊 LOAD LEADS: Updating statistics display...');
        const totalLeadsEl = document.getElementById('total-leads-count');
        if (totalLeadsEl) totalLeadsEl.textContent = totalLeads;

        const leadsWithEmailEl = document.getElementById('leads-with-email');
        if (leadsWithEmailEl) leadsWithEmailEl.textContent = withEmail;

        const leadsWithPhoneEl = document.getElementById('leads-with-phone');
        if (leadsWithPhoneEl) leadsWithPhoneEl.textContent = withPhone;

        const leadsConnectedEl = document.getElementById('leads-connected');
        if (leadsConnectedEl) leadsConnectedEl.textContent = connected;
        console.log(`📊 LOAD LEADS: Stats updated - Total: ${totalLeads}, Email: ${withEmail}, Phone: ${withPhone}, Connected: ${connected}`);

        // Populate query filter dropdown
        const queryFilter = document.getElementById('leads-filter-query');
        if (queryFilter) {
            queryFilter.innerHTML = '<option value="all">All Search Queries</option>';
            Object.keys(leadsByQuery).forEach(query => {
                const count = leadsByQuery[query].length;
                queryFilter.innerHTML += `<option value="${query}">${query} (${count})</option>`;
            });
        }

        // Display leads in table
        console.log('📊 LOAD LEADS: Displaying leads in table...');
        displayLeads(leads);
        console.log('✅ LOAD LEADS: Leads loaded successfully!');

    } catch (error) {
        console.error('❌ LOAD LEADS: Error loading leads:', error);
    }
}

/**
 * Display leads in the table
 */
function displayLeads(leads) {
    console.log(`📋 DISPLAY LEADS: Displaying ${leads.length} leads in table...`);
    const tableBody = document.getElementById('leads-table-body');

    if (!tableBody) {
        console.error('❌ DISPLAY LEADS: Table body element not found!');
        return;
    }

    if (leads.length === 0) {
        console.log('📋 DISPLAY LEADS: No leads to display');
        tableBody.innerHTML = '<tr><td colspan="8" style="padding: 20px; text-align: center; color: #6c757d;">No leads found. Start a People Search to collect leads.</td></tr>';
        return;
    }

    // Check current visibility state of contact columns
    const showContactInfo = document.getElementById('show-contact-info')?.checked || false;
    const contactDisplay = showContactInfo ? 'table-cell' : 'none';
    
    console.log('📋 DISPLAY LEADS: Rendering table rows...');

    tableBody.innerHTML = leads.map(lead => `
        <tr>
            <td style="padding: 8px; border-bottom: 1px solid #dee2e6;">
                <strong>${lead.name || 'Unknown'}</strong>
            </td>
            <td style="padding: 8px; border-bottom: 1px solid #dee2e6; max-width: 200px; overflow: hidden; text-overflow: ellipsis;">
                ${lead.headline || 'N/A'}
            </td>
            <td style="padding: 8px; border-bottom: 1px solid #dee2e6;">
                ${lead.location || 'N/A'}
            </td>
            <td class="contact-column" style="padding: 8px; border-bottom: 1px solid #dee2e6; display: ${contactDisplay};">
                ${lead.email ? `<a href="mailto:${lead.email}" style="color: #0066cc;">${lead.email}</a>` : 'N/A'}
            </td>
            <td class="contact-column" style="padding: 8px; border-bottom: 1px solid #dee2e6; display: ${contactDisplay};">
                ${lead.phone ? `<a href="tel:${lead.phone}" style="color: #0066cc;">${lead.phone}</a>` : 'N/A'}
            </td>
            <td style="padding: 8px; border-bottom: 1px solid #dee2e6;">
                <span style="background: #e3f2fd; padding: 2px 6px; border-radius: 3px; font-size: 11px;">
                    ${lead.searchQuery || 'Unknown'}
                </span>
            </td>
            <td style="padding: 8px; border-bottom: 1px solid #dee2e6; font-size: 11px;">
                ${lead.collectedAt ? new Date(lead.collectedAt).toLocaleDateString() : 'N/A'}
            </td>
            <td style="padding: 8px; border-bottom: 1px solid #dee2e6; text-align: center;">
                <a href="${lead.profileUrl}" target="_blank" style="color: #0066cc; text-decoration: none; font-size: 12px;">
                    🔗 View
                </a>
            </td>
        </tr>
    `).join('');
}

/**
 * Filter leads based on search and query filter
 */
async function filterLeads() {
    try {
        const result = await chrome.storage.local.get(['leads', 'leadsByQuery']);
        let leads = result.leads || [];

        // Handle string format
        if (typeof leads === 'string') {
            try {
                leads = JSON.parse(leads);
            } catch (e) {
                leads = [];
            }
        }

        // Handle object format
        if (leads && typeof leads === 'object' && !Array.isArray(leads)) {
            if (leads.data && Array.isArray(leads.data)) {
                leads = leads.data;
            } else {
                leads = [];
            }
        }

        // Final check
        if (!Array.isArray(leads)) {
            leads = [];
        }

        // Get filter values
        const searchTerm = document.getElementById('leads-search')?.value?.toLowerCase() || '';
        const queryFilter = document.getElementById('leads-filter-query')?.value || 'all';

        // Apply query filter
        if (queryFilter !== 'all') {
            leads = leads.filter(lead => lead.searchQuery === queryFilter);
        }

        // Apply search filter
        if (searchTerm) {
            leads = leads.filter(lead =>
                (lead.name || '').toLowerCase().includes(searchTerm) ||
                (lead.headline || '').toLowerCase().includes(searchTerm) ||
                (lead.location || '').toLowerCase().includes(searchTerm) ||
                (lead.email || '').toLowerCase().includes(searchTerm)
            );
        }

        displayLeads(leads);

    } catch (error) {
        console.error('POPUP: Error filtering leads:', error);
    }
}

/**
 * Export leads to CSV
 */
async function exportLeadsToCSV() {
    try {
        // CHECK FEATURE PERMISSION
        const canExport = await featureChecker$1.checkFeature('analytics');
        if (!canExport) {
            console.warn('🚫 CSV Export feature access denied - not available in current plan');
            alert('⬆️ CSV Export requires a paid plan. Please upgrade to export leads data!');
            
            // Show plan modal for upgrade
            const planModal = document.getElementById('plan-modal');
            if (planModal) {
                planModal.style.display = 'flex';
                loadPlans();
            }
            return;
        }
        
        const result = await chrome.storage.local.get('leads');
        let leads = result.leads || [];

        // Handle string format
        if (typeof leads === 'string') {
            try {
                leads = JSON.parse(leads);
            } catch (e) {
                leads = [];
            }
        }

        // Handle object format
        if (leads && typeof leads === 'object' && !Array.isArray(leads)) {
            if (leads.data && Array.isArray(leads.data)) {
                leads = leads.data;
            } else {
                leads = [];
            }
        }

        // Final check
        if (!Array.isArray(leads)) {
            leads = [];
        }

        if (leads.length === 0) {
            alert('No leads to export');
            return;
        }

        // Create CSV content
        const headers = ['Name', 'Headline', 'Location', 'Email', 'Phone', 'Search Query', 'Date Collected', 'Profile URL'];
        const csvContent = [
            headers.join(','),
            ...leads.map(lead => [
                `"${(lead.name || '').replace(/"/g, '""')}"`,
                `"${(lead.headline || '').replace(/"/g, '""')}"`,
                `"${(lead.location || '').replace(/"/g, '""')}"`,
                lead.email || '',
                lead.phone || '',
                `"${(lead.searchQuery || '').replace(/"/g, '""')}"`,
                lead.collectedAt ? new Date(lead.collectedAt).toLocaleDateString() : '',
                lead.profileUrl || ''
            ].join(','))
        ].join('\n');

        // Download CSV
        const blob = new Blob([csvContent], { type: 'text/csv' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `linkedin-leads-${new Date().toISOString().split('T')[0]}.csv`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);

        console.log('POPUP: Exported', leads.length, 'leads to CSV');

    } catch (error) {
        console.error('POPUP: Error exporting leads:', error);
        alert('Error exporting leads: ' + error.message);
    }
}

/**
 * Toggle visibility of email and phone columns
 */
function toggleContactColumns() {
    const checkbox = document.getElementById('show-contact-info');
    const contactColumns = document.querySelectorAll('.contact-column');
    const isChecked = checkbox?.checked || false;
    
    contactColumns.forEach(column => {
        column.style.display = isChecked ? 'table-cell' : 'none';
    });
    
    console.log('📊 LEADS: Contact columns visibility:', isChecked ? 'shown' : 'hidden');
}

/**
 * Clear all leads from storage
 */
async function clearAllLeads() {
    if (!confirm('Are you sure you want to clear ALL leads data? This action cannot be undone.')) {
        return;
    }
    
    try {
        await chrome.storage.local.remove(['leads', 'leadsByQuery']);
        
        // Reload the leads display
        await loadLeads();
        
        console.log('🗑️ LEADS: All leads cleared');
        alert('✅ All leads data has been cleared.');
        
    } catch (error) {
        console.error('❌ LEADS: Error clearing leads:', error);
        alert('Error clearing leads: ' + error.message);
    }
}

// --- BUSINESS HOURS CHECK ---
async function checkBusinessHoursBeforeProcessing$1() {
    try {
        const response = await chrome.runtime.sendMessage({ action: 'getBusinessHoursStatus' });
        if (response && response.success) {
            const status = response.status;
            
            // If business hours is enabled and we're outside business hours
            if (status.enabled && !status.withinBusinessHours) {
                const proceed = confirm(
                    `⚠️ Outside Business Hours!\n\n` +
                    `Current time: ${status.currentHour}:00\n` +
                    `Business hours: ${status.businessStart}:00 - ${status.businessEnd}:00\n\n` +
                    `Do you still want to proceed?\n\n` +
                    `💡 Tip: Adjust business hours in Settings tab.`
                );
                return proceed;
            }
        }
        return true; // Proceed if check fails or business hours disabled
    } catch (error) {
        console.warn('Failed to check business hours:', error);
        return true; // Proceed on error
    }
}

// --- PEOPLE SEARCH AUTOMATION ---
async function startPeopleSearchAutomation() {
    // Check business hours first
    const canProceed = await checkBusinessHoursBeforeProcessing$1();
    if (!canProceed) {
        return;
    }
    
    // Check which search source is selected (keyword or URL)
    const searchByUrl = document.getElementById('search-by-url');
    const isUsingUrl = searchByUrl?.checked || false;
    
    let keyword = '';
    let searchUrl = '';
    
    if (isUsingUrl) {
        // Using direct URL mode
        const urlInput = document.getElementById('people-search-url');
        searchUrl = urlInput?.value.trim() || '';
        
        if (!searchUrl) {
            alert('Please paste a LinkedIn people search URL');
            return;
        }
        
        if (!searchUrl.includes('linkedin.com/search/results/people')) {
            alert('Please enter a valid LinkedIn people search URL\n\nExample: https://www.linkedin.com/search/results/people/?keywords=...');
            return;
        }
        
        console.log('NETWORKING: Using URL mode with URL:', searchUrl);
    } else {
        // Using keyword mode
        keyword = elements.searchKeyword.value.trim();
        
        if (!keyword) {
            alert('Please enter a search keyword');
            return;
        }
        
        console.log('NETWORKING: Using keyword mode with keyword:', keyword);
    }
    
    const quota = parseInt(elements.connectQuota.value, 10);

    if (quota < 1 || quota > 50) {
        alert('Please enter a quota between 1 and 50');
        return;
    }

    // Parse exclude terms - only use what user entered, no defaults
    const excludeTermsStr = elements.excludeHeadlineTerms.value.trim();
    const excludeHeadlineTerms = excludeTermsStr
        ? excludeTermsStr.split(',').map(t => t.trim()).filter(Boolean)
        : []; // Empty array if user didn't enter anything

    // Get checkbox values - these are now mutually exclusive
    const sendWithNote = elements.sendWithNote.checked;
    const sendConnectionRequest = elements.sendConnectionRequest?.checked ?? false;
    
    // Validation: Only one option should be selected
    if (!sendWithNote && !sendConnectionRequest) {
        alert('Please select either "Send with Note" or "Send Connection Request"');
        return;
    }
    
    if (sendWithNote && sendConnectionRequest) {
        alert('Please select only one option: either "Send with Note" OR "Send Connection Request"');
        return;
    }
    
    console.log('NETWORKING: sendWithNote:', sendWithNote);
    console.log('NETWORKING: sendConnectionRequest:', sendConnectionRequest);
    
    const options = {
        useBooleanLogic: elements.useBooleanSearch.checked,
        filterNetwork: elements.filterNetwork.checked,
        sendWithNote: sendWithNote,
        sendConnectionRequest: sendConnectionRequest,
        extractContactInfo: elements.extractContactInfo.checked,
        excludeHeadlineTerms: excludeHeadlineTerms,
        connectionMessage: elements.connectionMessage.value.trim()
    };
    
    console.log('NETWORKING: Options being sent:', options);

    // Show status bar and status
    logStatus('networking', 'starting');
    elements.peopleSearchStatus.textContent = 'Starting people search automation...';
    elements.peopleSearchStatus.style.color = '#ffc107';

    // Show stop button, hide start button (both top and bottom)
    elements.startPeopleSearch.style.display = 'none';
    elements.stopPeopleSearch.style.display = 'block';
    if (elements.startPeopleSearchBottom) elements.startPeopleSearchBottom.style.display = 'none';
    if (elements.stopPeopleSearchBottom) elements.stopPeopleSearchBottom.style.display = 'block';

    // Save processing state to storage
    await chrome.storage.local.set({ peopleSearchActive: true });

    try {
        // Send message with timeout protection (10 seconds)
        const searchSource = isUsingUrl ? 'url' : 'keyword';
        console.log('NETWORKING: Starting people search with source:', searchSource);
        
        const response = await Promise.race([
            new Promise((resolve) => {
                chrome.runtime.sendMessage({
                    action: 'startPeopleSearch',
                    source: searchSource,  // 'url' or 'keyword'
                    keyword: isUsingUrl ? '' : keyword,
                    searchUrl: isUsingUrl ? searchUrl : '',
                    quota,
                    options,
                    message: elements.connectionMessage.value.trim()
                }, resolve);
            }),
            new Promise((_, reject) => 
                setTimeout(() => reject(new Error('Start automation timeout')), 10000)
            )
        ]);

        if (response && response.success) {
            elements.peopleSearchStatus.textContent =
                `✅ Automation started! Processing ${quota} connections...`;
            elements.peopleSearchStatus.style.color = '#28a745';
            
            // Let user know it's running
            console.log('NETWORKING: Automation started successfully');
        } else {
            throw new Error(response?.error || 'Failed to start automation');
        }
    } catch (error) {
        console.error('NETWORKING: Failed to start automation:', error);
        
        // Show error
        elements.peopleSearchStatus.textContent = `❌ Failed: ${error.message}`;
        elements.peopleSearchStatus.style.color = '#dc3545';
        
        // Restore buttons (both top and bottom)
        elements.startPeopleSearch.style.display = 'block';
        elements.stopPeopleSearch.style.display = 'none';
        if (elements.startPeopleSearchBottom) elements.startPeopleSearchBottom.style.display = 'block';
        if (elements.stopPeopleSearchBottom) elements.stopPeopleSearchBottom.style.display = 'none';
        
        // Clear processing state
        await chrome.storage.local.set({ peopleSearchActive: false });
        
        alert(`Failed to start automation: ${error.message}`);
        return;
    }
}

async function stopPeopleSearchAutomation() {
    console.log('POPUP: Stopping people search...');
    logStatus('networking', 'stopped');

    // Send stop message to background script
    chrome.runtime.sendMessage({
        action: 'stopPeopleSearch'
    }, (response) => {
        console.log('POPUP: Stop response:', response);

        // Hide stop button, show start button (both top and bottom)
        elements.stopPeopleSearch.style.display = 'none';
        elements.startPeopleSearch.style.display = 'block';
        if (elements.stopPeopleSearchBottom) elements.stopPeopleSearchBottom.style.display = 'none';
        if (elements.startPeopleSearchBottom) elements.startPeopleSearchBottom.style.display = 'block';

        // Hide status bar
        hideStatusBar('networking');

        // Clear processing state from storage
        chrome.storage.local.set({ peopleSearchActive: false });

        if (response && response.success) {
            elements.peopleSearchStatus.textContent = '⏸️ People search stopped';
            elements.peopleSearchStatus.style.color = '#6c757d';
            alert('✅ People search stopped successfully!');
        } else {
            alert('⚠️ Stop signal sent. Processing will stop after current profile.');
        }
    });
}

// --- KEYWORD ALERTS ---

async function addKeywordAlert() {
    const keyword = elements.newKeyword.value.trim();
    if (!keyword) {
        alert('Please enter a keyword');
        return;
    }

    const alerts = await chrome.storage.local.get('keywordAlerts');
    const alertsList = alerts.keywordAlerts || [];

    alertsList.push({
        id: Date.now(),
        keyword: keyword.toLowerCase(),
        enabled: true,
        createdAt: new Date().toISOString()
    });

    await chrome.storage.local.set({ keywordAlerts: alertsList });
    elements.newKeyword.value = '';
    loadKeywordAlerts();
}

async function loadKeywordAlerts() {
    try {
        const alerts = await chrome.storage.local.get('keywordAlerts');
        const alertsList = alerts.keywordAlerts || [];

        if (alertsList.length > 0 && elements.keywordList) {
            elements.keywordList.innerHTML = alertsList.map(alert => `
                    <div class="content-item">
                        <div class="content-item-header">
                            <span class="content-item-title">${alert.keyword}</span>
                            <button class="content-item-action" data-id="${alert.id}">Delete</button>
                        </div>
                    </div>
                `).join('');

            // Add event listeners to delete buttons
            elements.keywordList.querySelectorAll('.content-item-action').forEach(btn => {
                btn.addEventListener('click', async () => {
                    const id = parseInt(btn.dataset.id);
                    await deleteKeywordAlert(id);
                });
            });
        } else if (elements.keywordList) {
            elements.keywordList.innerHTML = '<p class="empty-state">No keyword alerts</p>';
        }
    } catch (error) {
        console.error('Error loading keyword alerts:', error);
    }
}

async function deleteKeywordAlert(id) {
    const alerts = await chrome.storage.local.get('keywordAlerts');
    const alertsList = alerts.keywordAlerts || [];
    const updated = alertsList.filter(a => a.id !== id);
    await chrome.storage.local.set({ keywordAlerts: updated });
    loadKeywordAlerts();
}

// --- COMPETITOR TRACKING ---

async function addCompetitor() {
    const url = elements.competitorUrl.value.trim();
    if (!url) {
        alert('Please enter a competitor LinkedIn URL');
        return;
    }

    if (!url.includes('linkedin.com')) {
        alert('Please enter a valid LinkedIn URL');
        return;
    }

    const competitors = await chrome.storage.local.get('competitors');
    const competitorsList = competitors.competitors || [];

    competitorsList.push({
        id: Date.now(),
        url: url,
        name: url.split('/').pop() || 'Unknown',
        addedAt: new Date().toISOString()
    });

    await chrome.storage.local.set({ competitors: competitorsList });
    elements.competitorUrl.value = '';
    loadCompetitors();
    alert('Competitor added successfully!');
}

async function loadCompetitors() {
    try {
        const competitors = await chrome.storage.local.get('competitors');
        const competitorsList = competitors.competitors || [];

        if (competitorsList.length > 0 && elements.competitorList) {
            elements.competitorList.innerHTML = competitorsList.map(comp => `
                    <div class="content-item">
                        <div class="content-item-header">
                            <span class="content-item-title">${comp.name}</span>
                            <button class="content-item-action" data-id="${comp.id}">Delete</button>
                        </div>
                        <small><a href="${comp.url}" target="_blank">${comp.url.substring(0, 50)}...</a></small>
                    </div>
                `).join('');

            // Add event listeners to delete buttons
            elements.competitorList.querySelectorAll('.content-item-action').forEach(btn => {
                btn.addEventListener('click', async () => {
                    const id = parseInt(btn.dataset.id);
                    await deleteCompetitor(id);
                });
            });
        } else if (elements.competitorList) {
            elements.competitorList.innerHTML = '<p class="empty-state">No competitors tracked</p>';
        }
    } catch (error) {
        console.error('Error loading competitors:', error);
    }
}

async function deleteCompetitor(id) {
    const competitors = await chrome.storage.local.get('competitors');
    const competitorsList = competitors.competitors || [];
    const updated = competitorsList.filter(c => c.id !== id);
    await chrome.storage.local.set({ competitors: updated });
    loadCompetitors();
}

async function checkPeopleSearchState() {
    try {
        const result = await chrome.storage.local.get('peopleSearchActive');
        const isActive = result.peopleSearchActive || false;

        console.log('POPUP: People search active state:', isActive);

        if (isActive) {
            // Show stop button, hide start button (both top and bottom)
            if (elements.startPeopleSearch) elements.startPeopleSearch.style.display = 'none';
            if (elements.stopPeopleSearch) elements.stopPeopleSearch.style.display = 'block';
            if (elements.startPeopleSearchBottom) elements.startPeopleSearchBottom.style.display = 'none';
            if (elements.stopPeopleSearchBottom) elements.stopPeopleSearchBottom.style.display = 'block';
            console.log('POPUP: Restored People Search stop button state');
        } else {
            // Show start button, hide stop button (both top and bottom)
            if (elements.startPeopleSearch) elements.startPeopleSearch.style.display = 'block';
            if (elements.stopPeopleSearch) elements.stopPeopleSearch.style.display = 'none';
            if (elements.startPeopleSearchBottom) elements.startPeopleSearchBottom.style.display = 'block';
            if (elements.stopPeopleSearchBottom) elements.stopPeopleSearchBottom.style.display = 'none';
        }
    } catch (error) {
        console.error('POPUP: Error checking People Search state:', error);
    }
}

async function loadSavedPosts() {
    try {
        const result = await chrome.storage.local.get('engagementStatistics');
        const stats = result.engagementStatistics || {};
        const saved = stats.savedPosts || [];

        if (elements.savedCount) elements.savedCount.textContent = saved.length;

        if (saved.length > 0 && elements.savedPostsList) {
            elements.savedPostsList.innerHTML = saved.slice(0, 10).map(post => `
                    <div class="content-item">
                        <div class="content-item-header">
                            <span class="content-item-title">${post.author || 'Unknown'}</span>
                        </div>
                        <p style="font-size: 11px; margin: 4px 0;">${post.content.substring(0, 100)}...</p>
                        <small>${new Date(post.savedAt).toLocaleDateString()}</small>
                    </div>
                `).join('');
        }
    } catch (error) {
        console.error('Error loading saved posts:', error);
    }
}

async function schedulePost() {
    try {
        // CHECK FEATURE PERMISSION
        const canSchedule = await featureChecker$1.checkFeature('scheduling');
        if (!canSchedule) {
            console.warn('🚫 Post Scheduling feature access denied - not available in current plan');
            const statusDiv = elements.scheduleStatus;
            if (statusDiv) {
                statusDiv.style.display = 'block';
                statusDiv.style.backgroundColor = '#f8d7da';
                statusDiv.style.color = '#721c24';
                statusDiv.textContent = '⬆️ Post Scheduling requires a paid plan. Please upgrade!';
            }
            
            // Show plan modal for upgrade
            const planModal = document.getElementById('plan-modal');
            if (planModal) {
                planModal.style.display = 'flex';
                loadPlans();
            }
            return;
        }
        
        const content = elements.postContent?.value?.trim();
        const topic = elements.postTopic?.value?.trim();
        const scheduleDate = elements.scheduleDate?.value;
        const scheduleTime = elements.scheduleTime?.value;
        const statusDiv = elements.scheduleStatus;

        // Validation
        if (!content) {
            statusDiv.style.display = 'block';
            statusDiv.style.backgroundColor = '#f8d7da';
            statusDiv.style.color = '#721c24';
            statusDiv.textContent = '❌ Please generate or write post content first';
            return;
        }

        if (!scheduleDate || !scheduleTime) {
            statusDiv.style.display = 'block';
            statusDiv.style.backgroundColor = '#fff3cd';
            statusDiv.style.color = '#856404';
            statusDiv.textContent = '⚠️ Please select both date and time';
            return;
        }

        // Combine date and time
        const scheduledFor = new Date(`${scheduleDate}T${scheduleTime}`);
        const now = new Date();

        if (scheduledFor <= now) {
            statusDiv.style.display = 'block';
            statusDiv.style.backgroundColor = '#f8d7da';
            statusDiv.style.color = '#721c24';
            statusDiv.textContent = '❌ Scheduled time must be in the future';
            return;
        }

        const post = {
            id: Date.now().toString(),
            content,
            topic: topic || 'Untitled Post',
            scheduledFor: scheduledFor.toISOString(),
            createdAt: new Date().toISOString(),
            status: 'scheduled'
        };

        // Get existing posts
        const storage = await chrome.storage.local.get('scheduledPosts');
        const posts = storage.scheduledPosts || [];
        posts.push(post);

        // Save back to storage
        await chrome.storage.local.set({ scheduledPosts: posts });

        // Show success message
        statusDiv.style.display = 'block';
        statusDiv.style.backgroundColor = '#d4edda';
        statusDiv.style.color = '#155724';
        statusDiv.textContent = `✅ Post scheduled for ${scheduledFor.toLocaleString()}`;

        // Clear inputs
        elements.scheduleDate.value = '';
        elements.scheduleTime.value = '';

        // Refresh scheduled posts list
        loadScheduledPosts();

        // Hide success message after 3 seconds
        setTimeout(() => {
            statusDiv.style.display = 'none';
        }, 3000);

    } catch (error) {
        console.error('Error scheduling post:', error);
        const statusDiv = elements.scheduleStatus;
        statusDiv.style.display = 'block';
        statusDiv.style.backgroundColor = '#f8d7da';
        statusDiv.style.color = '#721c24';
        statusDiv.textContent = '❌ Failed to schedule post';
    }
}

async function loadScheduledPosts() {
    try {
        console.log('📅 Displaying scheduled posts');

        // Fetch and render posts
        const storage = await chrome.storage.local.get('scheduledPosts');
        let posts = storage.scheduledPosts || [];
        const container = elements.upcomingPosts;

        if (!container) return;

        container.innerHTML = '';

        if (posts.length === 0) {
            container.innerHTML = '<div style="padding: 15px; text-align: center; color: #666; font-size: 13px;">No scheduled posts</div>';
            return;
        }

        // Sort by date (earliest first)
        posts.sort((a, b) => new Date(a.scheduledFor) - new Date(b.scheduledFor));

        posts.forEach(post => {
            const scheduledDate = new Date(post.scheduledFor);
            const now = new Date();
            const isPast = scheduledDate < now;

            const item = document.createElement('div');
            item.className = 'content-item';
            item.style.cssText = `
                padding: 10px;
                border: 1px solid ${isPast ? '#ffc107' : '#e0e0e0'};
                border-left: 3px solid ${isPast ? '#ff9800' : '#693fe9'};
                border-radius: 6px;
                margin-bottom: 8px;
                background: ${isPast ? '#fffbf0' : 'white'};
                box-shadow: 0 1px 3px rgba(0,0,0,0.05);
                transition: box-shadow 0.2s;
            `;
            
            item.onmouseenter = () => item.style.boxShadow = '0 2px 6px rgba(0,0,0,0.1)';
            item.onmouseleave = () => item.style.boxShadow = '0 1px 3px rgba(0,0,0,0.05)';

            const contentPreview = post.content.length > 80
                ? post.content.substring(0, 80) + '...'
                : post.content;

            item.innerHTML = `
                <div style="display: flex; justify-content: space-between; align-items: center; gap: 8px;">
                    <div style="flex: 1; min-width: 0; overflow: hidden;">
                        <div style="font-weight: 600; font-size: 12px; color: #693fe9; margin-bottom: 4px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                            ${post.topic || 'Untitled Post'}
                        </div>
                        <div style="display: flex; align-items: center; gap: 4px; font-size: 10px; margin-bottom: 4px; flex-wrap: wrap;">
                            <span style="background: ${isPast ? '#ff9800' : '#693fe9'}; color: white; padding: 2px 6px; border-radius: 3px; font-weight: 500; white-space: nowrap;">
                                📅 ${scheduledDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                            </span>
                            <span style="background: ${isPast ? '#ff9800' : '#693fe9'}; color: white; padding: 2px 6px; border-radius: 3px; font-weight: 500; white-space: nowrap;">
                                🕐 ${scheduledDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                            </span>
                            ${isPast ? '<span style="background: #dc3545; color: white; padding: 2px 6px; border-radius: 3px; font-weight: 600; font-size: 9px; white-space: nowrap;">⚠️ Past Due</span>' : ''}
                        </div>
                        <div style="font-size: 11px; color: #666; line-height: 1.3; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                            ${contentPreview}
                        </div>
                    </div>
                    <button class="action-button secondary" 
                            style="padding: 5px 8px; font-size: 10px; min-width: 55px; max-width: 55px; flex-shrink: 0; background: #dc3545; color: white; border: none; font-weight: 600; border-radius: 4px;" 
                            data-post-id="${post.id}">
                        🗑️
                    </button>
                </div>
            `;

            // Add delete event listener
            const deleteBtn = item.querySelector('button');
            deleteBtn.addEventListener('click', () => deleteScheduledPost(post.id));

            container.appendChild(item);
        });

    } catch (error) {
        console.error('Error displaying scheduled posts:', error);
    }
}

async function deleteScheduledPost(id) {
    try {
        const storage = await chrome.storage.local.get('scheduledPosts');
        let posts = storage.scheduledPosts || [];
        posts = posts.filter(p => p.id !== id);
        await chrome.storage.local.set({ scheduledPosts: posts });
        loadScheduledPosts(); // Refresh view

        // Show notification
        const statusDiv = elements.scheduleStatus;
        if (statusDiv) {
            statusDiv.style.display = 'block';
            statusDiv.style.backgroundColor = '#d4edda';
            statusDiv.style.color = '#155724';
            statusDiv.textContent = '🗑️ Post deleted successfully';
            setTimeout(() => {
                statusDiv.style.display = 'none';
            }, 2000);
        }
    } catch (error) {
        console.error('Error deleting post:', error);
    }
}

// ========== SCHEDULER FUNCTIONS ==========

/**
 * Add bulk processing schedule
 */
async function addBulkSchedule() {
    // ⚠️ STRICT CHECK: Automation Scheduling feature is REQUIRED for scheduling
    const canScheduleAutomation = await featureChecker$1.checkFeature('automationScheduling');
    if (!canScheduleAutomation) {
        console.error('🚫 BLOCKED: Automation Scheduling feature not available in current plan');
        alert('⬆️ Automation Scheduling requires a paid plan.\n\nScheduling automated bulk processing is only available with a paid subscription. Please upgrade to use this feature!');
        
        // Show plan modal for upgrade
        const planModal = document.getElementById('plan-modal');
        if (planModal) {
            planModal.style.display = 'flex';
            loadPlans();
        }
        return;
    }
    
    const time = elements.bulkScheduleTimeInput?.value;
    if (!time) {
        alert('Please select a time for the schedule');
        return;
    }

    // Get current settings from the form
    // Check which source is selected
    const sourceFeed = document.getElementById('source-feed');
    const isUsingFeed = sourceFeed?.checked || false;
    const source = isUsingFeed ? 'feed' : 'keywords';
    
    const keywords = elements.bulkUrls?.value?.trim().split('\n').filter(k => k.trim()) || [];
    const quota = parseInt(elements.bulkQuota?.value, 10) || 20;
    const minLikes = parseInt(elements.bulkMinLikes?.value, 10) || 0;
    const minComments = parseInt(elements.bulkMinComments?.value, 10) || 0;
    const actions = {
        like: elements.bulkLike?.checked || false,
        comment: elements.bulkComment?.checked || false,
        likeOrComment: elements.bulkLikeOrComment?.checked || false,
        share: elements.bulkShare?.checked || false,
        follow: elements.bulkFollow?.checked || false
    };

    // Validate based on source
    if (!isUsingFeed && keywords.length === 0) {
        alert('Please enter keywords in the "Keywords to Process" field, or switch to Feed mode');
        return;
    }

    // Get ignore keywords from UI
    const ignoreKeywordsText = elements.ignoreKeywords?.value || 'we\'re hiring\nnow hiring\napply now';
    
    const schedule = {
        time,
        source,  // 'feed' or 'keywords'
        keywords: isUsingFeed ? [] : keywords,
        quota,
        minLikes,
        minComments,
        ignoreKeywords: ignoreKeywordsText,
        actions,
        accountType: elements.accountType?.value || 'matured',
        commentDelay: parseInt(elements.commentDelay?.value, 10) || 180
    };

    // Debug logging
    console.log('SCHEDULER UI: Adding schedule with source:', source);
    console.log('SCHEDULER UI: isUsingFeed:', isUsingFeed);
    console.log('SCHEDULER UI: sourceFeed element:', sourceFeed);
    console.log('SCHEDULER UI: Full schedule object:', JSON.stringify(schedule, null, 2));

    try {
        const response = await chrome.runtime.sendMessage({
            action: 'addBulkSchedule',
            schedule
        });

        if (response?.success) {
            elements.bulkScheduleTimeInput.value = '';
            await loadBulkSchedulerStatus();
            const sourceText = source === 'feed' ? 'LinkedIn Feed' : `${keywords.length} keywords`;
            const actionsText = Object.entries(actions).filter(([k,v]) => v).map(([k]) => k).join(', ') || 'none';
            alert(`✅ Schedule added for ${time}\n\nSource: ${sourceText}\nQuota: ${quota} posts\nActions: ${actionsText}`);
        } else {
            alert('Failed to add schedule: ' + (response?.error || 'Unknown error'));
        }
    } catch (error) {
        console.error('Failed to add bulk schedule:', error);
        alert('Failed to add schedule: ' + error.message);
    }
}

/**
 * Add people search schedule
 */
async function addPeopleSchedule() {
    // CHECK NETWORK SCHEDULING PERMISSION
    const canScheduleNetworking = await featureChecker$1.checkFeature('autoFollow');
    if (!canScheduleNetworking) {
        console.warn('🚫 Network Scheduling feature access denied - not available in current plan');
        alert('⬆️ Network Scheduling requires a paid plan. Please upgrade to schedule networking automation!');
        
        // Show plan modal for upgrade
        const planModal = document.getElementById('plan-modal');
        if (planModal) {
            planModal.style.display = 'flex';
            loadPlans();
        }
        return;
    }
    
    const time = elements.peopleScheduleTimeInput?.value;
    if (!time) {
        alert('Please select a time for the schedule');
        return;
    }

    // Get current settings from the form
    // Check which search source is selected
    const searchByUrl = document.getElementById('search-by-url');
    const isUsingUrl = searchByUrl?.checked || false;
    const source = isUsingUrl ? 'url' : 'keyword';
    
    const keyword = elements.searchKeyword?.value?.trim() || '';
    const searchUrl = document.getElementById('people-search-url')?.value?.trim() || '';
    const quota = parseInt(elements.connectQuota?.value, 10) || 10;
    const useBooleanLogic = elements.useBooleanSearch?.checked || false;
    const filterNetwork = elements.filterNetwork?.checked || false;
    const sendWithNote = elements.sendWithNote?.checked || false;
    const sendConnectionRequest = elements.sendConnectionRequest?.checked || false;
    const extractContactInfo = elements.extractContactInfo?.checked || false;
    const excludeHeadlineTerms = elements.excludeHeadlineTerms?.value?.split(',').map(t => t.trim()).filter(t => t) || [];
    const connectionMessage = elements.connectionMessage?.value?.trim() || '';

    // Validate based on source
    if (isUsingUrl) {
        if (!searchUrl) {
            alert('Please paste a LinkedIn people search URL');
            return;
        }
        if (!searchUrl.includes('linkedin.com/search/results/people')) {
            alert('Please enter a valid LinkedIn people search URL');
            return;
        }
    } else {
        if (!keyword) {
            alert('Please enter a search keyword in the "Search Keyword" field, or switch to URL mode');
            return;
        }
    }

    const schedule = {
        time,
        source,  // 'keyword' or 'url'
        keyword: isUsingUrl ? '' : keyword,
        searchUrl: isUsingUrl ? searchUrl : '',
        quota,
        useBooleanLogic,
        filterNetwork,
        sendWithNote,
        sendConnectionRequest,
        extractContactInfo,
        excludeHeadlineTerms,
        connectionMessage
    };

    try {
        const response = await chrome.runtime.sendMessage({
            action: 'addPeopleSchedule',
            schedule
        });

        if (response?.success) {
            elements.peopleScheduleTimeInput.value = '';
            await loadPeopleSchedulerStatus();
            const sourceText = source === 'url' ? `URL: ${searchUrl.substring(0, 40)}...` : `Keyword: "${keyword}"`;
            alert(`✅ Schedule added for ${time}\n\n${sourceText}\nQuota: ${quota} connections`);
        } else {
            alert('Failed to add schedule: ' + (response?.error || 'Unknown error'));
        }
    } catch (error) {
        console.error('Failed to add people schedule:', error);
        alert('Failed to add schedule');
    }
}

/**
 * Load bulk scheduler status
 */
async function loadBulkSchedulerStatus() {
    try {
        const response = await chrome.runtime.sendMessage({
            action: 'getBulkSchedulerStatus'
        });

        if (response?.success) {
            const status = response.status;

            // Update toggle
            if (elements.bulkSchedulerEnabled) {
                elements.bulkSchedulerEnabled.checked = status.enabled;
            }

            // Render schedule list
            renderBulkSchedules(status.schedules || []);

            // Update next execution
            if (status.nextExecution) {
                if (elements.bulkNextExecutionTime) elements.bulkNextExecutionTime.textContent = `${status.nextExecution.time} - ${status.nextExecution.keywords?.length || 0} keywords`;
                startBulkCountdownTimer();
            } else {
                if (elements.bulkNextExecutionTime) elements.bulkNextExecutionTime.textContent = 'Not scheduled';
                if (elements.bulkCountdownTimer) elements.bulkCountdownTimer.textContent = '--:--:--';
            }
        }
    } catch (error) {
        console.error('Failed to load bulk scheduler status:', error);
    }
}

/**
 * Load people scheduler status
 */
async function loadPeopleSchedulerStatus() {
    try {
        const response = await chrome.runtime.sendMessage({
            action: 'getPeopleSchedulerStatus'
        });

        if (response?.success) {
            const status = response.status;

            // Update toggle
            if (elements.peopleSchedulerEnabled) {
                elements.peopleSchedulerEnabled.checked = status.enabled;
            }

            // Render schedule list
            renderPeopleSchedules(status.schedules || []);

            // Update next execution
            if (status.nextExecution) {
                if (elements.peopleNextExecutionTime) elements.peopleNextExecutionTime.textContent = `${status.nextExecution.time} - ${status.nextExecution.keyword}`;
                startPeopleCountdownTimer();
            } else {
                if (elements.peopleNextExecutionTime) elements.peopleNextExecutionTime.textContent = 'Not scheduled';
                if (elements.peopleCountdownTimer) elements.peopleCountdownTimer.textContent = '--:--:--';
            }
        }
    } catch (error) {
        console.error('Failed to load people scheduler status:', error);
    }
}

/**
 * Render bulk schedules list - Compact version with tooltip
 */
function renderBulkSchedules(schedules) {
    if (!elements.bulkScheduleList) return;

    if (schedules.length === 0) {
        elements.bulkScheduleList.innerHTML = '<small style="color: #6c757d;">No schedules</small>';
        return;
    }

    elements.bulkScheduleList.innerHTML = schedules.map((sched, index) => {
        const keywordsDisplay = sched.keywords?.slice(0, 2).join(', ') + (sched.keywords?.length > 2 ? ` +${sched.keywords.length - 2}` : '');
        const actionsDisplay = Object.entries(sched.actions || {}).filter(([k, v]) => v).map(([k]) => k[0].toUpperCase()).join('') || '-';
        const minL = sched.minLikes || 0;
        const minC = sched.minComments || 0;
        const filtersDisplay = (minL > 0 || minC > 0) ? ` L${minL}C${minC}` : '';
        
        // Build tooltip content
        const allKeywords = sched.keywords?.join(', ') || 'None';
        const allActions = Object.entries(sched.actions || {}).filter(([k, v]) => v).map(([k]) => k).join(', ') || 'None';
        const tooltipText = `Time: ${sched.time}
Keywords: ${allKeywords}
Quota: ${sched.quota} posts
Actions: ${allActions}
Min Likes: ${minL}
Min Comments: ${minC}
Account Type: ${sched.accountType || 'matured'}`;

        return `
                <div style="background: #fff; padding: 6px 8px; border: 1px solid #dee2e6; border-radius: 4px; margin-bottom: 4px; display: flex; align-items: center; gap: 8px; cursor: help;" title="${tooltipText.replace(/"/g, '&quot;')}">
                    <strong style="font-size: 11px; color: #693fe9; min-width: 45px;">⏰ ${sched.time}</strong>
                    <div style="flex: 1; font-size: 9px; color: #666; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                        ${keywordsDisplay || '-'} • ${sched.quota}p • ${actionsDisplay}${filtersDisplay}
                    </div>
                    <button class="remove-bulk-schedule-btn" data-index="${index}" style="background: none; border: none; cursor: pointer; font-size: 12px; padding: 0; color: #dc3545;">✕</button>
                </div>
            `;
    }).join('');

    // Add event listeners
    document.querySelectorAll('.remove-bulk-schedule-btn').forEach(btn => {
        btn.addEventListener('click', async () => {
            const index = parseInt(btn.dataset.index);
            await removeBulkSchedule(index);
        });
    });
}

/**
 * Render people schedules list - Compact version with tooltip
 */
function renderPeopleSchedules(schedules) {
    if (!elements.peopleScheduleList) return;

    if (schedules.length === 0) {
        elements.peopleScheduleList.innerHTML = '<small style="color: #6c757d;">No schedules</small>';
        return;
    }

    elements.peopleScheduleList.innerHTML = schedules.map((sched, index) => {
        const keywordShort = sched.keyword?.length > 15 ? sched.keyword.substring(0, 15) + '...' : sched.keyword;
        
        // Build compact flags: B=Boolean, N=Network, M=Message, E=Extract
        let flags = '';
        if (sched.useBooleanLogic) flags += 'B';
        if (sched.filterNetwork) flags += 'N';
        if (sched.sendWithNote) flags += 'M';
        if (sched.extractContactInfo) flags += 'E';
        const flagsDisplay = flags ? ` ${flags}` : '';
        
        // Build tooltip content
        const excludeTerms = sched.excludeHeadlineTerms?.join(', ') || 'None';
        const tooltipText = `Time: ${sched.time}
Keyword: ${sched.keyword}
Connections: ${sched.quota}
Boolean Logic: ${sched.useBooleanLogic ? 'Yes' : 'No'}
2nd/3rd Degree: ${sched.filterNetwork ? 'Yes' : 'No'}
Send with Note: ${sched.sendWithNote ? 'Yes' : 'No'}
Extract Contact: ${sched.extractContactInfo ? 'Yes' : 'No'}
Exclude Terms: ${excludeTerms}
Message: ${sched.connectionMessage ? sched.connectionMessage.substring(0, 50) + '...' : 'None'}`;
        
        return `
                <div style="background: #fff; padding: 6px 8px; border: 1px solid #dee2e6; border-radius: 4px; margin-bottom: 4px; display: flex; align-items: center; gap: 8px; cursor: help;" title="${tooltipText.replace(/"/g, '&quot;')}">
                    <strong style="font-size: 11px; color: #693fe9; min-width: 45px;">⏰ ${sched.time}</strong>
                    <div style="flex: 1; font-size: 9px; color: #666; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                        "${keywordShort}" • ${sched.quota}c${flagsDisplay}
                    </div>
                    <button class="remove-people-schedule-btn" data-index="${index}" style="background: none; border: none; cursor: pointer; font-size: 12px; padding: 0; color: #dc3545;">✕</button>
                </div>
            `;
    }).join('');

    // Add event listeners
    document.querySelectorAll('.remove-people-schedule-btn').forEach(btn => {
        btn.addEventListener('click', async () => {
            const index = parseInt(btn.dataset.index);
            await removePeopleSchedule(index);
        });
    });
}

/**
 * Remove bulk schedule
 */
async function removeBulkSchedule(index) {
    if (!confirm('Remove this schedule?')) return;

    try {
        const response = await chrome.runtime.sendMessage({
            action: 'removeBulkSchedule',
            index
        });

        if (response?.success) {
            await loadBulkSchedulerStatus();
        }
    } catch (error) {
        console.error('Failed to remove bulk schedule:', error);
    }
}

/**
 * Remove people schedule
 */
async function removePeopleSchedule(index) {
    if (!confirm('Remove this schedule?')) return;

    try {
        const response = await chrome.runtime.sendMessage({
            action: 'removePeopleSchedule',
            index
        });

        if (response?.success) {
            await loadPeopleSchedulerStatus();
        }
    } catch (error) {
        console.error('Failed to remove people schedule:', error);
    }
}

/**
 * Toggle bulk scheduler
 */
async function toggleBulkScheduler() {
    // Skip if automation is running
    const automationState = await chrome.storage.local.get(['bulkProcessingActive', 'peopleSearchActive']);
    if (automationState.bulkProcessingActive || automationState.peopleSearchActive) {
        console.log('⏭️ SKIPPED: toggleBulkScheduler (automation is running)');
        return;
    }
    
    const enabled = elements.bulkSchedulerEnabled?.checked;

    try {
        const response = await chrome.runtime.sendMessage({
            action: 'setBulkSchedulerEnabled',
            enabled
        });

        if (response?.success) {
            await loadBulkSchedulerStatus();
            // Silently update - no alert popup
            console.log(enabled ? '✅ Bulk Processing scheduler enabled!' : '⏸️ Bulk Processing scheduler disabled');
        }
    } catch (error) {
        console.error('Failed to toggle bulk scheduler:', error);
        if (elements.bulkSchedulerEnabled) {
            elements.bulkSchedulerEnabled.checked = !enabled;
        }
    }
}

/**
 * Toggle people scheduler
 */
async function togglePeopleScheduler() {
    // Skip if automation is running
    const automationState = await chrome.storage.local.get(['bulkProcessingActive', 'peopleSearchActive']);
    if (automationState.bulkProcessingActive || automationState.peopleSearchActive) {
        console.log('⏭️ SKIPPED: togglePeopleScheduler (automation is running)');
        return;
    }
    
    const enabled = elements.peopleSchedulerEnabled?.checked;

    try {
        const response = await chrome.runtime.sendMessage({
            action: 'setPeopleSchedulerEnabled',
            enabled
        });

        if (response?.success) {
            await loadPeopleSchedulerStatus();
            // Silently update - no alert popup
            console.log(enabled ? '✅ People Search scheduler enabled!' : '⏸️ People Search scheduler disabled');
        }
    } catch (error) {
        console.error('Failed to toggle people scheduler:', error);
        if (elements.peopleSchedulerEnabled) {
            elements.peopleSchedulerEnabled.checked = !enabled;
        }
    }
}

// --- COUNTDOWN TIMER FUNCTIONS --- //
/**
 * Start countdown timers
 */
function startBulkCountdownTimer() {
    if (window.bulkCountdownInterval) {
        clearInterval(window.bulkCountdownInterval);
    }

    window.bulkCountdownInterval = setInterval(async () => {
        try {
            const response = await chrome.runtime.sendMessage({
                action: 'getBulkSchedulerCountdown'
            });

            if (response?.success && elements.bulkCountdownTimer) {
                elements.bulkCountdownTimer.textContent = response.countdown;
            }
        } catch (error) {
            // Ignore
        }
    }, 1000);
}

function startPeopleCountdownTimer() {
    if (window.peopleCountdownInterval) {
        clearInterval(window.peopleCountdownInterval);
    }

    window.peopleCountdownInterval = setInterval(async () => {
        try {
            const response = await chrome.runtime.sendMessage({
                action: 'getPeopleSchedulerCountdown'
            });

            if (response?.success && elements.peopleCountdownTimer) {
                elements.peopleCountdownTimer.textContent = response.countdown;
            }
        } catch (error) {
            // Ignore
        }
    }, 1000);
}

async function checkDailyPostStatus() {
    chrome.runtime.sendMessage({
        action: 'getDailyPostStatus'
    }, (response) => {
        if (response && response.success) {
            const status = response.status;
            if (status.enabled && status.nextRun) {
                const nextRun = new Date(status.nextRun);
                if (elements.dailyPostEnabled) {
                    elements.dailyPostEnabled.textContent =
                        `✅ Enabled (Next: ${nextRun.toLocaleString()})`;
                    elements.dailyPostEnabled.style.color = '#28a745';
                }
                if (elements.dailyPostTime) {
                    elements.dailyPostTime.value = status.postTime;
                }
            } else {
                if (elements.dailyPostEnabled) {
                    elements.dailyPostEnabled.textContent = 'Not Scheduled';
                    elements.dailyPostEnabled.style.color = '#6c757d';
                }
            }
        }
    });
}

// --- AI KEYWORD GENERATION --- //
async function generateKeywords() {
    const intent = elements.keywordIntent.value.trim();
    const keywordCount = parseInt(elements.keywordCountSlider.value, 10);

    if (!intent) {
        alert('Please describe your intent, niche, or target audience first');
        return;
    }

    elements.generateKeywords.disabled = true;
    elements.generateKeywords.textContent = '⏳ Generating...';

    try {
        console.log('POPUP: Sending keyword generation request...');
        
        // Use dedicated keyword generation endpoint
        const response = await chrome.runtime.sendMessage({
            action: 'generateKeywords',
            intent: intent,
            keywordCount: keywordCount
        });

        console.log('POPUP: Received response:', response);

        if (response && response.success) {
            let keywords = response.keywords || [];

            // If backend returned raw content, try to parse it
            if (keywords.length === 0 && response.rawContent) {
                keywords = parseKeywordsFromContent(response.rawContent, keywordCount);
            }

            // Validate and add keywords
            if (keywords.length > 0) {
                keywords = keywords.slice(0, keywordCount);
                const keywordText = keywords.join('\n');

                // Add to existing keywords if any
                const existingKeywords = elements.bulkUrls.value.trim();
                const finalKeywords = existingKeywords
                    ? existingKeywords + '\n' + keywordText
                    : keywordText;

                elements.bulkUrls.value = finalKeywords;

                // Save keywords to persistent storage
                await saveKeywords(finalKeywords);

                alert(`✅ Generated ${keywords.length} keywords successfully!\n\nKeywords added to your list.`);
            } else {
                throw new Error('No keywords generated. Please try again with a different intent.');
            }
        } else {
            throw new Error(response?.error || 'Failed to generate keywords');
        }
    } catch (error) {
        console.error('Keyword generation error:', error);
        alert(`❌ Failed to generate keywords: ${error.message}`);
    } finally {
        elements.generateKeywords.disabled = false;
        elements.generateKeywords.textContent = '🤖 Generate Keywords';
    }
}

// Helper function to parse keywords from raw content
function parseKeywordsFromContent(content, maxCount) {
    let keywords = [];

    try {
        // Clean up content
        content = content.trim().replace(/```json\s*/g, '').replace(/```\s*/g, '');

        // Strategy 1: Try JSON parse
        try {
            const result = JSON.parse(content);
            if (result.keywords && Array.isArray(result.keywords)) {
                keywords = result.keywords;
            } else if (Array.isArray(result)) {
                keywords = result;
            }
        } catch (e) {
            // Not JSON, continue
        }

        // Strategy 2: Extract array from content
        if (keywords.length === 0) {
            const arrayMatch = content.match(/\[([\s\S]*?)\]/);
            if (arrayMatch) {
                keywords = arrayMatch[1]
                    .split(',')
                    .map(k => k.trim().replace(/^["']|["']$/g, ''))
                    .filter(k => k.length > 0 && k.length < 50);
            }
        }

        // Strategy 3: Extract from plain text (line by line)
        if (keywords.length === 0) {
            keywords = content
                .split('\n')
                .map(line => line.trim())
                .filter(line =>
                    line &&
                    line.length > 0 &&
                    line.length < 50 &&
                    !line.includes('{') &&
                    !line.includes('}')
                )
                .map(line => line.replace(/^\d+\.\s*/, '').replace(/^[-*]\s*/, ''))
                .filter(k => k.length > 0);
        }
    } catch (e) {
        console.error('Failed to parse keywords from content:', e);
    }

    return keywords.slice(0, maxCount);
}

async function clearKeywords() {
    if (confirm('Are you sure you want to clear all keywords?')) {
        elements.bulkUrls.value = '';
        elements.keywordIntent.value = '';
        await saveKeywords('');
    }
}

async function saveKeywords(keywords) {
    try {
        await chrome.storage.local.set({
            savedKeywords: keywords,
            keywordsSavedAt: new Date().toISOString()
        });
    } catch (error) {
        console.error('Failed to save keywords:', error);
    }
}

async function loadSavedKeywords() {
    try {
        const result = await chrome.storage.local.get(['savedKeywords']);
        if (result.savedKeywords && elements.bulkUrls) {
            elements.bulkUrls.value = result.savedKeywords;
        }
    } catch (error) {
        console.error('Failed to load saved keywords:', error);
    }
}

function updateKeywordCountDisplay() {
    if (elements.keywordCountDisplay && elements.keywordCountSlider) {
        elements.keywordCountDisplay.textContent = elements.keywordCountSlider.value;
    }
}

// Auto-save keywords when user types
async function onKeywordsChange() {
    const keywords = elements.bulkUrls.value;
    await saveKeywords(keywords);
}

// Update all slider displays
function updateSliderDisplays() {
    // Automation sliders
    if (elements.keywordCountDisplay && elements.keywordCountSlider) {
        elements.keywordCountDisplay.textContent = elements.keywordCountSlider.value;
    }
    if (elements.bulkQuotaDisplay && elements.bulkQuota) {
        elements.bulkQuotaDisplay.textContent = elements.bulkQuota.value;
    }
    if (elements.bulkMinLikesDisplay && elements.bulkMinLikes) {
        elements.bulkMinLikesDisplay.textContent = elements.bulkMinLikes.value;
    }
    if (elements.bulkMinCommentsDisplay && elements.bulkMinComments) {
        elements.bulkMinCommentsDisplay.textContent = elements.bulkMinComments.value;
    }
    
    // Networking sliders
    if (elements.connectQuotaDisplay && elements.connectQuota) {
        elements.connectQuotaDisplay.textContent = elements.connectQuota.value;
    }

    // Daily limits sliders
    if (elements.dailyCommentLimitDisplay && elements.dailyCommentLimitInput) {
        elements.dailyCommentLimitDisplay.textContent = elements.dailyCommentLimitInput.value;
    }
    if (elements.dailyLikeLimitDisplay && elements.dailyLikeLimitInput) {
        elements.dailyLikeLimitDisplay.textContent = elements.dailyLikeLimitInput.value;
    }
    if (elements.dailyShareLimitDisplay && elements.dailyShareLimitInput) {
        elements.dailyShareLimitDisplay.textContent = elements.dailyShareLimitInput.value;
    }
    if (elements.dailyFollowLimitDisplay && elements.dailyFollowLimitInput) {
        elements.dailyFollowLimitDisplay.textContent = elements.dailyFollowLimitInput.value;
    }

    // Start delay sliders (with 's' suffix)
    if (elements.automationStartDelayDisplay && elements.automationStartDelay) {
        elements.automationStartDelayDisplay.textContent = elements.automationStartDelay.value + 's';
    }
    if (elements.networkingStartDelayDisplay && elements.networkingStartDelay) {
        elements.networkingStartDelayDisplay.textContent = elements.networkingStartDelay.value + 's';
    }
    if (elements.importStartDelayDisplay && elements.importStartDelay) {
        elements.importStartDelayDisplay.textContent = elements.importStartDelay.value + 's';
    }

    // Post writer delay sliders (with 's' suffix)
    if (elements.postWriterPageLoadDelayDisplay && elements.postWriterPageLoadDelay) {
        elements.postWriterPageLoadDelayDisplay.textContent = elements.postWriterPageLoadDelay.value + 's';
    }
    if (elements.postWriterClickDelayDisplay && elements.postWriterClickDelay) {
        elements.postWriterClickDelayDisplay.textContent = elements.postWriterClickDelay.value + 's';
    }
    if (elements.postWriterTypingDelayDisplay && elements.postWriterTypingDelay) {
        elements.postWriterTypingDelayDisplay.textContent = elements.postWriterTypingDelay.value + 's';
    }
    if (elements.postWriterSubmitDelayDisplay && elements.postWriterSubmitDelay) {
        elements.postWriterSubmitDelayDisplay.textContent = elements.postWriterSubmitDelay.value + 's';
    }

    // Search delay displays (with proper time formatting)
    if (elements.searchDelayMin && elements.searchDelayMinDisplay) {
        const value = parseInt(elements.searchDelayMin.value);
        elements.searchDelayMinDisplay.textContent = value >= 60 ? Math.round(value / 60) + 'm' : value + 's';
    }
    if (elements.searchDelayMax && elements.searchDelayMaxDisplay) {
        const value = parseInt(elements.searchDelayMax.value);
        elements.searchDelayMaxDisplay.textContent = value >= 60 ? Math.round(value / 60) + 'm' : value + 's';
    }

    // Comment delay displays (with proper time formatting)
    if (elements.commentDelayMin && elements.commentDelayMinDisplay) {
        const value = parseInt(elements.commentDelayMin.value);
        elements.commentDelayMinDisplay.textContent = value >= 60 ? Math.round(value / 60) + 'm' : value + 's';
    }
    if (elements.commentDelayMax && elements.commentDelayMaxDisplay) {
        const value = parseInt(elements.commentDelayMax.value);
        elements.commentDelayMaxDisplay.textContent = value >= 60 ? Math.round(value / 60) + 'm' : value + 's';
    }
    
    // Networking delay displays (with proper time formatting)
    if (elements.networkingDelayMin && elements.networkingDelayMinDisplay) {
        const value = parseInt(elements.networkingDelayMin.value);
        elements.networkingDelayMinDisplay.textContent = value >= 60 ? Math.round(value / 60) + 'm' : value + 's';
    }
    if (elements.networkingDelayMax && elements.networkingDelayMaxDisplay) {
        const value = parseInt(elements.networkingDelayMax.value);
        elements.networkingDelayMaxDisplay.textContent = value >= 60 ? Math.round(value / 60) + 'm' : value + 's';
    }

    // Post action delays (with proper time formatting)
    if (elements.beforeOpeningPostsDelay && elements.beforeOpeningPostsDelayDisplay) {
        const value = parseInt(elements.beforeOpeningPostsDelay.value);
        elements.beforeOpeningPostsDelayDisplay.textContent = value >= 60 ? Math.round(value / 60) + 'm' : value + 's';
    }
    if (elements.postPageLoadDelay && elements.postPageLoadDelayDisplay) {
        const value = parseInt(elements.postPageLoadDelay.value);
        elements.postPageLoadDelayDisplay.textContent = value >= 60 ? Math.round(value / 60) + 'm' : value + 's';
    }
    if (elements.beforeLikeDelay && elements.beforeLikeDelayDisplay) {
        const value = parseInt(elements.beforeLikeDelay.value);
        elements.beforeLikeDelayDisplay.textContent = value >= 60 ? Math.round(value / 60) + 'm' : value + 's';
    }
    if (elements.beforeCommentDelay && elements.beforeCommentDelayDisplay) {
        const value = parseInt(elements.beforeCommentDelay.value);
        elements.beforeCommentDelayDisplay.textContent = value >= 60 ? Math.round(value / 60) + 'm' : value + 's';
    }
    if (elements.beforeShareDelay && elements.beforeShareDelayDisplay) {
        const value = parseInt(elements.beforeShareDelay.value);
        elements.beforeShareDelayDisplay.textContent = value >= 60 ? Math.round(value / 60) + 'm' : value + 's';
    }
    if (elements.beforeFollowDelay && elements.beforeFollowDelayDisplay) {
        const value = parseInt(elements.beforeFollowDelay.value);
        elements.beforeFollowDelayDisplay.textContent = value >= 60 ? Math.round(value / 60) + 'm' : value + 's';
    }
}

// Auto-save all form values to local storage
async function saveAllFormValues() {
    // CRITICAL: Skip if automation is running to prevent message flooding
    const automationState = await chrome.storage.local.get(['bulkProcessingActive', 'peopleSearchActive']);
    if (automationState.bulkProcessingActive || automationState.peopleSearchActive) {
        console.log('⏭️ SKIPPED: saveAllFormValues (automation is running)');
        return; // Bail out immediately
    }
    
    try {
        const formData = {
            // Bulk processing settings
            bulkUrls: elements.bulkUrls?.value || '',
            bulkQuota: elements.bulkQuota?.value || '3',
            bulkMinLikes: elements.bulkMinLikes?.value || '0',
            bulkMinComments: elements.bulkMinComments?.value || '0',
            bulkLike: elements.bulkLike?.checked ?? false,
            bulkComment: elements.bulkComment?.checked ?? true,
            bulkLikeOrComment: elements.bulkLikeOrComment?.checked ?? false,
            bulkShare: elements.bulkShare?.checked ?? false,
            bulkFollow: elements.bulkFollow?.checked ?? false,
            ignoreKeywords: elements.ignoreKeywords?.value || 'hiring\nwe\'re hiring\njob opening\njoin our team\nwe are hiring\nlooking for\nopen position\nnow hiring\napply now',

            // Account and delay settings
            accountType: elements.accountType?.value || 'matured',

            // Search delay settings
            searchDelayMin: elements.searchDelayMin?.value || '30',
            searchDelayMax: elements.searchDelayMax?.value || '60',

            // Comment delay settings
            commentDelayMin: elements.commentDelayMin?.value || '60',
            commentDelayMax: elements.commentDelayMax?.value || '180',

            // Human simulation settings
            humanMouseMovement: elements.humanMouseMovement?.checked || false,
            humanScrolling: elements.humanScrolling?.checked || false,
            humanReadingPause: elements.humanReadingPause?.checked || false,

            // Business hours settings
            businessHoursEnabled: elements.businessHoursEnabled?.checked || false,
            businessStartHour: elements.businessStartHour?.value || '9',
            businessEndHour: elements.businessEndHour?.value || '18',
            allowWeekends: elements.allowWeekends?.checked || false,

            // Daily automation
            enableDailyProcessing: elements.enableDailyProcessing?.checked || false,

            // Keyword generation
            keywordCountSlider: elements.keywordCountSlider?.value || '15',

            // People Search settings
            searchKeyword: elements.searchKeyword?.value || '',
            connectQuota: elements.connectQuota?.value || '10',
            useBooleanSearch: elements.useBooleanSearch?.checked || false,
            filterNetwork: elements.filterNetwork?.checked || false,
            sendWithNote: elements.sendWithNote?.checked || false,
            sendConnectionRequest: elements.sendConnectionRequest?.checked ?? true, // Default true if not found
            extractContactInfo: elements.extractContactInfo?.checked || false,
            excludeHeadlineTerms: elements.excludeHeadlineTerms?.value || '',
            connectionMessage: elements.connectionMessage?.value || 'Hi, [Name]\n\nI just saw your profile, and I\'m amazed with your experience and would love to connect with you.',

            // Post Writer settings
            postTopic: elements.postTopic?.value || '',
            postTemplate: elements.postTemplate?.value || 'custom',
            postTone: elements.postTone?.value || 'professional',
            postLength: elements.postLength?.value || '1500',
            postIncludeHashtags: elements.postIncludeHashtags?.checked ?? false,
            postIncludeEmojis: elements.postIncludeEmojis?.checked !== false,
            postContent: elements.postContent?.value || '',
            scheduleDate: elements.scheduleDate?.value || '',
            scheduleTime: elements.scheduleTime?.value || '',

            // Automation Tab - Comment Settings
            commentGoal: elements.commentGoal?.value || 'value',
            commentTone: elements.commentTone?.value || 'professional',
            commentLength: elements.commentLength?.value || 'short',
            userExpertise: elements.userExpertise?.value || '',
            userBackground: elements.userBackground?.value || '',
            aiAutoPost: elements.aiAutoPost?.value || 'manual',
            openInWindow: elements.openInWindow?.value || 'window',
            keywordIntent: elements.keywordIntent?.value || '',
            bulkLikeOrComment: elements.bulkLikeOrComment?.checked || false,

            // Import Tab Settings
            profileUrlsInput: elements.profileUrlsInput?.value || '',
            importExtractContactInfo: elements.importExtractContactInfo?.checked || false,
            enableLikes: elements.enableLikes?.checked !== false,
            enableComments: elements.enableComments?.checked !== false,
            enableShares: elements.enableShares?.checked || false,
            enableFollows: elements.enableFollows?.checked || false,
            enableRandomMode: elements.enableRandomMode?.checked || false,
            postsPerProfile: elements.postsPerProfile?.value || '2',
            combinedSendConnections: elements.combinedSendConnections?.checked ?? true,
            combinedExtractContactInfo: elements.combinedExtractContactInfo?.checked || false,
            combinedEnableLikes: elements.combinedEnableLikes?.checked !== false,
            combinedEnableComments: elements.combinedEnableComments?.checked !== false,
            combinedEnableShares: elements.combinedEnableShares?.checked || false,
            combinedEnableFollows: elements.combinedEnableFollows?.checked || false,
            combinedEnableRandomMode: elements.combinedEnableRandomMode?.checked || false,
            combinedPostsPerProfile: elements.combinedPostsPerProfile?.value || '2',

            // Timestamp for tracking
            lastSaved: Date.now()
        };

        await chrome.storage.local.set({ formData });
        console.log('POPUP: All form values auto-saved');
    } catch (error) {
        console.error('POPUP: Error auto-saving form values:', error);
    }
}

// Load all saved form values
async function loadAllFormValues() {
    try {
        const result = await chrome.storage.local.get('formData');
        const formData = result.formData;

        if (!formData) {
            console.log('POPUP: No saved form data found');
            return;
        }

        console.log('POPUP: Loading saved form values:', formData);

        // Restore bulk processing settings
        if (elements.bulkUrls) elements.bulkUrls.value = formData.bulkUrls || '';
        if (elements.bulkQuota) elements.bulkQuota.value = formData.bulkQuota || '3';
        if (elements.bulkMinLikes) elements.bulkMinLikes.value = formData.bulkMinLikes || '0';
        if (elements.bulkMinComments) elements.bulkMinComments.value = formData.bulkMinComments || '0';
        if (elements.bulkLike) elements.bulkLike.checked = formData.bulkLike ?? false;
        if (elements.bulkComment) elements.bulkComment.checked = formData.bulkComment ?? true;
        if (elements.bulkLikeOrComment) elements.bulkLikeOrComment.checked = formData.bulkLikeOrComment ?? false;
        if (elements.bulkShare) elements.bulkShare.checked = formData.bulkShare ?? false;
        if (elements.bulkFollow) elements.bulkFollow.checked = formData.bulkFollow ?? false;
        if (elements.ignoreKeywords) elements.ignoreKeywords.value = formData.ignoreKeywords || 'hiring\nwe\'re hiring\njob opening\njoin our team\nwe are hiring\nlooking for\nopen position\nnow hiring\napply now';

        // Restore account and delay settings
        if (elements.accountType) elements.accountType.value = formData.accountType || 'matured';

        // Restore search delay settings
        if (elements.searchDelayMin) elements.searchDelayMin.value = formData.searchDelayMin || '30';
        if (elements.searchDelayMax) elements.searchDelayMax.value = formData.searchDelayMax || '60';

        // Restore comment delay settings
        if (elements.commentDelayMin) elements.commentDelayMin.value = formData.commentDelayMin || '60';
        if (elements.commentDelayMax) elements.commentDelayMax.value = formData.commentDelayMax || '180';

        // Restore human simulation settings
        if (elements.humanMouseMovement) elements.humanMouseMovement.checked = formData.humanMouseMovement || false;
        if (elements.humanScrolling) elements.humanScrolling.checked = formData.humanScrolling || false;
        if (elements.humanReadingPause) elements.humanReadingPause.checked = formData.humanReadingPause || false;

        // Restore business hours settings
        if (elements.businessHoursEnabled) elements.businessHoursEnabled.checked = formData.businessHoursEnabled || false;
        if (elements.businessStartHour) elements.businessStartHour.value = formData.businessStartHour || '9';
        if (elements.businessEndHour) elements.businessEndHour.value = formData.businessEndHour || '18';
        if (elements.allowWeekends) elements.allowWeekends.checked = formData.allowWeekends || false;

        // Restore daily automation
        if (elements.enableDailyProcessing) elements.enableDailyProcessing.checked = formData.enableDailyProcessing || false;

        // Restore keyword generation
        if (elements.keywordCountSlider) elements.keywordCountSlider.value = formData.keywordCountSlider || '15';

        // Restore People Search settings
        if (elements.searchKeyword) elements.searchKeyword.value = formData.searchKeyword || '';
        if (elements.connectQuota) elements.connectQuota.value = formData.connectQuota || '10';
        if (elements.useBooleanSearch) elements.useBooleanSearch.checked = formData.useBooleanSearch || false;
        if (elements.filterNetwork) elements.filterNetwork.checked = formData.filterNetwork || false;
        // Handle mutually exclusive checkboxes - only one should be selected
        const savedSendWithNote = formData.sendWithNote || false;
        const savedSendConnectionRequest = formData.sendConnectionRequest;
        
        if (savedSendWithNote) {
            // If sendWithNote was saved as true, only check that one
            if (elements.sendWithNote) elements.sendWithNote.checked = true;
            if (elements.sendConnectionRequest) elements.sendConnectionRequest.checked = false;
        } else {
            // Default to sendConnectionRequest if neither is specifically saved
            if (elements.sendWithNote) elements.sendWithNote.checked = false;
            if (elements.sendConnectionRequest) elements.sendConnectionRequest.checked = savedSendConnectionRequest ?? true;
        }
        if (elements.extractContactInfo) elements.extractContactInfo.checked = formData.extractContactInfo || false;
        if (elements.excludeHeadlineTerms) elements.excludeHeadlineTerms.value = formData.excludeHeadlineTerms || '';
        if (elements.connectionMessage) elements.connectionMessage.value = formData.connectionMessage || 'Hi, [Name]\n\nI just saw your profile, and I\'m amazed with your experience and would love to connect with you.';

        // Restore Post Writer settings
        if (elements.postTopic) elements.postTopic.value = formData.postTopic || '';
        if (elements.postTemplate) elements.postTemplate.value = formData.postTemplate || 'custom';
        if (elements.postTone) elements.postTone.value = formData.postTone || 'professional';
        if (elements.postLength) elements.postLength.value = formData.postLength || '1500';
        if (elements.postIncludeHashtags) elements.postIncludeHashtags.checked = formData.postIncludeHashtags ?? false;
        if (elements.postIncludeEmojis) elements.postIncludeEmojis.checked = formData.postIncludeEmojis !== false;
        if (elements.postContent) elements.postContent.value = formData.postContent || '';
        if (elements.scheduleDate) elements.scheduleDate.value = formData.scheduleDate || '';
        if (elements.scheduleTime) elements.scheduleTime.value = formData.scheduleTime || '';

        // Restore Automation Tab - Comment Settings
        if (elements.commentGoal) elements.commentGoal.value = formData.commentGoal || 'value';
        if (elements.commentTone) elements.commentTone.value = formData.commentTone || 'professional';
        if (elements.commentLength) elements.commentLength.value = formData.commentLength || 'short';
        if (elements.userExpertise) elements.userExpertise.value = formData.userExpertise || '';
        if (elements.userBackground) elements.userBackground.value = formData.userBackground || '';
        if (elements.aiAutoPost) elements.aiAutoPost.value = formData.aiAutoPost || 'manual';
        if (elements.openInWindow) elements.openInWindow.value = formData.openInWindow || 'window';
        if (elements.keywordIntent) elements.keywordIntent.value = formData.keywordIntent || '';
        if (elements.bulkLikeOrComment) elements.bulkLikeOrComment.checked = formData.bulkLikeOrComment || false;

        // Restore Import Tab Settings
        if (elements.profileUrlsInput) elements.profileUrlsInput.value = formData.profileUrlsInput || '';
        if (elements.importExtractContactInfo) elements.importExtractContactInfo.checked = formData.importExtractContactInfo || false;
        if (elements.enableLikes) elements.enableLikes.checked = formData.enableLikes !== false;
        if (elements.enableComments) elements.enableComments.checked = formData.enableComments !== false;
        if (elements.enableShares) elements.enableShares.checked = formData.enableShares || false;
        if (elements.enableFollows) elements.enableFollows.checked = formData.enableFollows || false;
        if (elements.enableRandomMode) elements.enableRandomMode.checked = formData.enableRandomMode || false;
        if (elements.postsPerProfile) elements.postsPerProfile.value = formData.postsPerProfile || '2';
        if (elements.combinedSendConnections) elements.combinedSendConnections.checked = formData.combinedSendConnections ?? true;
        if (elements.combinedExtractContactInfo) elements.combinedExtractContactInfo.checked = formData.combinedExtractContactInfo || false;
        if (elements.combinedEnableLikes) elements.combinedEnableLikes.checked = formData.combinedEnableLikes !== false;
        if (elements.combinedEnableComments) elements.combinedEnableComments.checked = formData.combinedEnableComments !== false;
        if (elements.combinedEnableShares) elements.combinedEnableShares.checked = formData.combinedEnableShares || false;
        if (elements.combinedEnableFollows) elements.combinedEnableFollows.checked = formData.combinedEnableFollows || false;
        if (elements.combinedEnableRandomMode) elements.combinedEnableRandomMode.checked = formData.combinedEnableRandomMode || false;
        if (elements.combinedPostsPerProfile) elements.combinedPostsPerProfile.value = formData.combinedPostsPerProfile || '2';

        // Update all displays
        updateSliderDisplays();
        updateKeywordCountDisplay();

        console.log('POPUP: Form values restored successfully');
    } catch (error) {
        console.error('POPUP: Error loading saved form values:', error);
    }
}

// --- BUSINESS HOURS MANAGEMENT --- //
async function updateBusinessHours() {
    // Skip if automation is running
    const automationState = await chrome.storage.local.get(['bulkProcessingActive', 'peopleSearchActive']);
    if (automationState.bulkProcessingActive || automationState.peopleSearchActive) {
        console.log('⏭️ SKIPPED: updateBusinessHours (automation is running)');
        return;
    }
    
    const settings = {
        enabled: elements.businessHoursEnabled?.checked || false,
        startHour: parseInt(elements.businessStartHour?.value, 10) || 9,
        endHour: parseInt(elements.businessEndHour?.value, 10) || 18,
        allowWeekends: elements.allowWeekends?.checked || false
    };

    try {
        const response = await chrome.runtime.sendMessage({
            action: 'updateBusinessHours',
            settings: settings
        });

        if (response && response.success) {
            console.log('Business hours updated successfully');
            await updateBusinessHoursStatus();
        }
    } catch (error) {
        console.error('Failed to update business hours:', error);
    }
}

async function updateBusinessHoursStatus() {
    try {
        const response = await chrome.runtime.sendMessage({
            action: 'getBusinessHoursStatus'
        });

        if (response && response.success) {
            const status = response.status;
            const statusText = status.withinBusinessHours
                ? `✅ Active (${status.currentHour}:00 within ${status.businessStart}:00-${status.businessEnd}:00)`
                : `⏰ Inactive (Next: ${status.nextBusinessHours})`;

            if (elements.businessHoursStatus) {
                elements.businessHoursStatus.textContent = statusText;
            }

            // Update daily schedule info
            if (elements.dailyScheduleInfo) {
                const scheduleText = status.dailyScheduleEnabled
                    ? `📅 Daily processing enabled with ${status.dailyKeywords} keywords`
                    : '📅 Daily processing disabled';
                elements.dailyScheduleInfo.textContent = scheduleText;
            }
        }
    } catch (error) {
        console.error('Failed to get business hours status:', error);
    }
}

async function saveDailyScheduleSettings() {
    // Skip if automation is running
    const automationState = await chrome.storage.local.get(['bulkProcessingActive', 'peopleSearchActive']);
    if (automationState.bulkProcessingActive || automationState.peopleSearchActive) {
        console.log('⏭️ SKIPPED: saveDailyScheduleSettings (automation is running)');
        return;
    }
    
    const keywords = elements.bulkUrls.value.trim().split('\n').filter(k => k.trim());
    const isEnabled = elements.dailyScheduleEnabled?.checked || false;

    // Allow disabling even without keywords, but require keywords to enable
    if (isEnabled && keywords.length === 0) {
        alert('Please add some keywords first before enabling daily schedule');
        elements.dailyScheduleEnabled.checked = false;
        return;
    }

    const schedule = {
        enabled: isEnabled,
        keywords: keywords,
        quota: parseInt(elements.bulkQuota?.value, 10) || 20,
        qualification: {
            minLikes: parseInt(elements.bulkMinLikes?.value, 10) || 0,
            minComments: parseInt(elements.bulkMinComments?.value, 10) || 0
        },
        actions: {
            like: elements.bulkLike?.checked || false,
            comment: elements.bulkComment?.checked || false,
            share: elements.bulkShare?.checked || false,
            follow: elements.bulkFollow?.checked || false
        },
        delaySettings: {
            accountType: elements.accountType?.value || 'matured',
            commentDelay: parseInt(elements.commentDelay?.value, 10) || 180
        }
    };

    try {
        const response = await chrome.runtime.sendMessage({
            action: 'updateDailySchedule',
            schedule: schedule
        });

        if (response && response.success) {
            console.log(`✅ Daily schedule ${schedule.enabled ? 'enabled' : 'disabled'} successfully!`);
            await updateBusinessHoursStatus();
        }
    } catch (error) {
        console.error('Failed to save daily schedule:', error);
        alert('❌ Failed to save daily schedule. Check console for errors.');
    }
}

// --- SYSTEM TESTING --- //
async function testAllSystems() {
    if (elements.testSystems) {
        elements.testSystems.disabled = true;
        elements.testSystems.textContent = '🔄 Testing...';
    }

    let allPassed = true;

    // Test 1: Service Worker
    try {
        const response = await chrome.runtime.sendMessage({ action: 'ping' });
        if (elements.serviceWorkerStatus) {
            elements.serviceWorkerStatus.innerHTML = '✅ Active';
            elements.serviceWorkerStatus.style.color = '#28a745';
        }
    } catch (error) {
        allPassed = false;
        if (elements.serviceWorkerStatus) {
            elements.serviceWorkerStatus.innerHTML = '❌ Inactive';
            elements.serviceWorkerStatus.style.color = '#dc3545';
        }
    }

    // Test 2: Business Hours
    try {
        const response = await chrome.runtime.sendMessage({ action: 'getBusinessHoursStatus' });
        if (response && response.success) {
            const status = response.status;
            const indicator = status.withinBusinessHours ? '✅ Active' : '⏰ Outside Hours';
            const color = status.withinBusinessHours ? '#28a745' : '#ffc107';

            if (elements.businessHoursIndicator) {
                elements.businessHoursIndicator.textContent = indicator;
                elements.businessHoursIndicator.style.color = color;
            }
        }
    } catch (error) {
        allPassed = false;
        if (elements.businessHoursIndicator) {
            elements.businessHoursIndicator.innerHTML = '❌ Error';
            elements.businessHoursIndicator.style.color = '#dc3545';
        }
    }

    // Test 3: OpenAI Integration
    try {
        const response = await chrome.runtime.sendMessage({
            action: 'generateWithOpenAI',
            prompt: 'Generate 3 test keywords for LinkedIn marketing',
            maxTokens: 100
        });

        if (response && response.success) {
            if (elements.openaiStatus) {
                elements.openaiStatus.innerHTML = '✅ Working';
                elements.openaiStatus.style.color = '#28a745';
            }
        } else {
            throw new Error('OpenAI test failed');
        }
    } catch (error) {
        allPassed = false;
        if (elements.openaiStatus) {
            elements.openaiStatus.innerHTML = '❌ Error';
            elements.openaiStatus.style.color = '#dc3545';
        }
    }

    // Update timestamp
    if (elements.statusTimestamp) {
        elements.statusTimestamp.textContent = new Date().toLocaleTimeString();
    }

    // Reset button
    if (elements.testSystems) {
        elements.testSystems.disabled = false;
        elements.testSystems.textContent = allPassed ? '✅ All Systems OK' : '⚠️ Issues Found';

        setTimeout(() => {
            elements.testSystems.textContent = '🧪 Test All Systems';
        }, 3000);
    }

    return allPassed;
}

// Auto-test systems on load
async function updateSystemStatus() {
    // Quick status check without user interaction
    try {
        // Check business hours
        const bhResponse = await chrome.runtime.sendMessage({ action: 'getBusinessHoursStatus' });
        if (bhResponse && bhResponse.success && elements.businessHoursIndicator) {
            const status = bhResponse.status;
            const indicator = status.withinBusinessHours ? '✅ Active' : '⏰ Outside Hours';
            const color = status.withinBusinessHours ? '#28a745' : '#ffc107';
            elements.businessHoursIndicator.textContent = indicator;
            elements.businessHoursIndicator.style.color = color;
        }

        // Update timestamp
        if (elements.statusTimestamp) {
            elements.statusTimestamp.textContent = new Date().toLocaleTimeString();
        }
    } catch (error) {
        console.error('System status update failed:', error);
    }
}

function savePreferences() {
    state.preferences.commentTone = elements.commentTone?.value;
    state.preferences.commentLength = elements.commentLength?.value;
    state.preferences.useCheapModel = elements.useCheapModel?.checked || false;
    state.preferences.automationQuota = parseInt(elements.autoQuota?.value, 10);
    state.preferences.automationPostAge = elements.autoPostAge?.value;
    chrome.storage.local.set({ preferences: state.preferences });
}

// --- BUSINESS HOURS CHECK ---
async function checkBusinessHoursBeforeProcessing() {
    try {
        const response = await chrome.runtime.sendMessage({ action: 'getBusinessHoursStatus' });
        if (response && response.success) {
            const status = response.status;
            
            // If business hours is enabled and we're outside business hours
            if (status.enabled && !status.withinBusinessHours) {
                const proceed = confirm(
                    `⚠️ Outside Business Hours!\n\n` +
                    `Current time: ${status.currentHour}:00\n` +
                    `Business hours: ${status.businessStart}:00 - ${status.businessEnd}:00\n\n` +
                    `Do you still want to proceed?\n\n` +
                    `💡 Tip: Adjust business hours in Settings tab.`
                );
                return proceed;
            }
        }
        return true; // Proceed if check fails or business hours disabled
    } catch (error) {
        console.warn('Failed to check business hours:', error);
        return true; // Proceed on error
    }
}

// --- BULK PROCESSING AUTOMATION --- //

async function checkBulkProcessingState() {
    try {
        const result = await chrome.storage.local.get('bulkProcessingActive');
        const isActive = result.bulkProcessingActive || false;

        console.log('POPUP: Bulk processing active state:', isActive);

        if (isActive) {
            // Show stop button, hide start button (both top and bottom)
            if (elements.startBulkProcessing) elements.startBulkProcessing.style.display = 'none';
            if (elements.stopBulkProcessing) elements.stopBulkProcessing.style.display = 'inline-block';
            if (elements.startBulkProcessingBottom) elements.startBulkProcessingBottom.style.display = 'none';
            if (elements.stopBulkProcessingBottom) elements.stopBulkProcessingBottom.style.display = 'inline-block';
            console.log('POPUP: Restored stop button state');
        } else {
            // Show start button, hide stop button (both top and bottom)
            if (elements.startBulkProcessing) elements.startBulkProcessing.style.display = 'inline-block';
            if (elements.stopBulkProcessing) elements.stopBulkProcessing.style.display = 'none';
            if (elements.startBulkProcessingBottom) elements.startBulkProcessingBottom.style.display = 'inline-block';
            if (elements.stopBulkProcessingBottom) elements.stopBulkProcessingBottom.style.display = 'none';
        }
    } catch (error) {
        console.error('POPUP: Error checking processing state:', error);
    }
}

async function stopBulkProcessing() {
    console.log('POPUP: Stopping bulk processing...');
    logStatus('automation', 'stopped');

    // Send stop message to background script
    chrome.runtime.sendMessage({
        action: 'stopBulkProcessing'
    }, (response) => {
        console.log('POPUP: Stop response:', response);

        // Hide stop button, show start button (both top and bottom)
        elements.stopBulkProcessing.style.display = 'none';
        elements.startBulkProcessing.style.display = 'inline-block';
        if (elements.stopBulkProcessingBottom) elements.stopBulkProcessingBottom.style.display = 'none';
        if (elements.startBulkProcessingBottom) elements.startBulkProcessingBottom.style.display = 'inline-block';

        // Hide progress bar and status bar
        hideProgressBar();
        hideStatusBar('automation');

        // Clear processing state from storage
        chrome.storage.local.set({ bulkProcessingActive: false });

        if (response && response.success) {
            alert('✅ Bulk processing stopped successfully!');
        } else {
            alert('⚠️ Stop signal sent. Processing will stop after current post.');
        }
    });
}

async function startBulkProcessing() {
    // Check business hours first
    const canProceed = await checkBusinessHoursBeforeProcessing();
    if (!canProceed) {
        return;
    }
    
    // Check daily limits before starting
    const limits = await checkAllDailyLimits();
    if (limits.anyLimitReached) {
        let limitMessages = [];
        if (!limits.comments.canProceed) limitMessages.push(`Comments: ${limits.comments.used}/${limits.comments.limit}`);
        if (!limits.likes.canProceed) limitMessages.push(`Likes: ${limits.likes.used}/${limits.likes.limit}`);
        if (!limits.shares.canProceed) limitMessages.push(`Shares: ${limits.shares.used}/${limits.shares.limit}`);
        if (!limits.follows.canProceed) limitMessages.push(`Follows: ${limits.follows.used}/${limits.follows.limit}`);
        
        const proceed = confirm(
            `⚠️ Daily Limit(s) Reached!\n\n` +
            `${limitMessages.join('\n')}\n\n` +
            `Some actions may be skipped due to limits.\n` +
            `Do you still want to proceed?\n\n` +
            `💡 Tip: Adjust daily limits in the Limits tab.`
        );
        if (!proceed) return;
    }
    
    // ⚠️ STRICT CHECK: General Automation feature is REQUIRED for ALL bulk processing
    const canUseAutomation = await featureChecker$1.checkFeature('autoLike');
    if (!canUseAutomation) {
        console.error('🚫 BLOCKED: General Automation feature not available in current plan');
        alert('⬆️ General Automation requires a paid plan.\n\nBulk processing is only available with a paid subscription. Please upgrade to use this feature!');
        const planModal = document.getElementById('plan-modal');
        if (planModal) {
            planModal.style.display = 'flex';
            loadPlans();
        }
        return;
    }

    // Check which post source is selected (keywords or feed)
    const sourceFeed = document.getElementById('source-feed');
    const isUsingFeed = sourceFeed?.checked || false;
    
    const keywords = elements.bulkUrls.value.trim().split('\n').filter(k => k.trim());
    const quota = parseInt(elements.bulkQuota?.value, 10) || 20;
    const minLikes = parseInt(elements.bulkMinLikes?.value, 10) || 0;
    const minComments = parseInt(elements.bulkMinComments?.value, 10) || 0;

    // Only require keywords if NOT using feed mode
    if (!isUsingFeed && keywords.length === 0) {
        alert('Please enter at least one keyword to search');
        return;
    }

    if (quota < 1 || quota > 1000) {
        alert('Please enter a quota between 1 and 1000');
        return;
    }

    const doLike = elements.bulkLike.checked;
    const doComment = elements.bulkComment.checked;
    const doLikeOrComment = elements.bulkLikeOrComment.checked;
    const doShare = elements.bulkShare.checked;
    const doFollow = elements.bulkFollow.checked;

    if (!doLike && !doComment && !doLikeOrComment && !doShare && !doFollow) {
        alert('Please select at least one action (Like, Comment, Like+Comment Random, Share, or Follow)');
        return;
    }

    // CHECK ADDITIONAL FEATURE PERMISSIONS FOR SPECIFIC ACTIONS
    if (doLike || doShare || doLikeOrComment) {
        const canUseAutomation = await featureChecker$1.checkFeature('autoLike');
        if (!canUseAutomation) {
            console.warn('🚫 General Automation feature access denied');
            alert('⬆️ General Automation (Like/Share) requires a paid plan. Please upgrade!');
            const planModal = document.getElementById('plan-modal');
            if (planModal) {
                planModal.style.display = 'flex';
                loadPlans();
            }
            return;
        }
    }

    if (doComment || doLikeOrComment) {
        const canUseComment = await featureChecker$1.checkFeature('autoComment');
        if (!canUseComment) {
            console.warn('🚫 AI Comment feature access denied');
            alert('⬆️ AI Comment Generation is required for commenting. Please upgrade or uncheck the Comment option!');
            const planModal = document.getElementById('plan-modal');
            if (planModal) {
                planModal.style.display = 'flex';
                loadPlans();
            }
            return;
        }
    }

    if (doFollow) {
        const canUseFollow = await featureChecker$1.checkFeature('autoFollow');
        if (!canUseFollow) {
            console.warn('🚫 Networking (Follow) feature access denied');
            alert('⬆️ Networking Features (Follow) requires a paid plan. Please upgrade or uncheck the Follow option!');
            const planModal = document.getElementById('plan-modal');
            if (planModal) {
                planModal.style.display = 'flex';
                loadPlans();
            }
            return;
        }
    }

    // Get current delay settings from Daily Limits
    const accountType = elements.accountType?.value || 'matured';
    const commentDelay = parseInt(elements.commentDelay?.value, 10) || 180;

    // Get ignore keywords (one per line) - reduced list to avoid over-filtering
    const ignoreKeywordsText = elements.ignoreKeywords?.value || 'we\'re hiring\nnow hiring\napply now';
    const ignoreKeywords = ignoreKeywordsText.split('\n').map(k => k.trim()).filter(k => k.length > 0);

    console.log('Bulk processing keywords:', keywords);
    console.log('Total quota:', quota);
    console.log('Post qualification - Min likes:', minLikes, 'Min comments:', minComments);
    console.log('Ignore keywords:', ignoreKeywords.length, 'keywords configured');
    console.log('Actions: Like:', doLike, 'Comment:', doComment, 'Like/Comment Random:', doLikeOrComment, 'Share:', doShare, 'Follow:', doFollow);
    console.log('Account type:', accountType, 'Comment delay:', commentDelay);

    // Show progress UI (both top and bottom buttons)
    if (elements.startBulkProcessing) {
        elements.startBulkProcessing.style.display = 'none';
    }
    if (elements.stopBulkProcessing) {
        elements.stopBulkProcessing.style.display = 'block';
    }
    if (elements.startBulkProcessingBottom) {
        elements.startBulkProcessingBottom.style.display = 'none';
    }
    if (elements.stopBulkProcessingBottom) {
        elements.stopBulkProcessingBottom.style.display = 'block';
    }

    // Show status bar and progress bar immediately
    logStatus('automation', 'starting');
    showProgressBar();
    updateProgressBar$1(0, quota, 0, keywords.length, 0, 'Initializing...');

    // Save processing state to storage
    await chrome.storage.local.set({ bulkProcessingActive: true });

    // Send to background script
    const sourceType = isUsingFeed ? 'feed' : 'keywords';
    console.log('POPUP: Starting bulk processing with source:', sourceType);
    
    chrome.runtime.sendMessage({
        action: 'bulkProcessKeywords',
        source: sourceType,  // 'feed' or 'keywords'
        keywords: isUsingFeed ? [] : keywords,
        quota: quota,
        minLikes: minLikes,
        minComments: minComments,
        ignoreKeywords: ignoreKeywordsText, // Pass as text to be parsed in background
        actions: {
            like: doLike,
            comment: doComment,
            likeOrComment: doLikeOrComment,
            share: doShare,
            follow: doFollow
        },
        accountType: accountType,
        commentDelay: commentDelay
    }, (response) => {
        console.log('POPUP: Bulk processing response:', response);

        if (response && response.success) {
            const qualificationText = (minLikes > 0 || minComments > 0)
                ? `\nPost criteria: ${minLikes}+ likes, ${minComments}+ comments`
                : '';

            const sourceText = isUsingFeed ? 'Source: LinkedIn Feed' : `Keywords: ${keywords.length}`;
            response.message || 'Bulk processing started successfully!';
            alert(`Bulk processing will start in 30 seconds!\n\n${sourceText}\nTarget posts: ${quota}${qualificationText}\n\nDo not close LinkedIn!`);

            // Don't clear keywords - they are now persistent
            window.close();
        } else {
            hideProgressBar();
            const errorMsg = response?.error || 'Unknown error occurred';
            console.error('POPUP: Bulk processing failed:', errorMsg);
            alert(`Failed to start bulk processing:\n\n${errorMsg}`);
        }
    });
}

async function startAutomationFromPage() {
    savePreferences();

    const [currentTab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const isLinkedInPage = currentTab.url && (currentTab.url.includes('linkedin.com/search/results') || currentTab.url.includes('linkedin.com/feed/hashtag'));

    if (!isLinkedInPage) {
        elements.automationError.style.display = 'block';
        setTimeout(() => { elements.automationError.style.display = 'none'; }, 3000);
        return;
    }

    await chrome.storage.local.set({
        'AutomationPageState': 'On',
        'AutomationQuota': parseInt(elements.autoQuota.value, 10),
        'AutomationPostAgeLimit': elements.autoPostAge.value
    });

    chrome.runtime.sendMessage({
        action: "startPageAutopilot",
        url: currentTab.url
    });

    window.close();
}

async function startAdvancedAutomation(type) {
    const quotas = {
        like: parseInt(elements.autoLikeQuota?.value, 10) || 20,
        share: parseInt(elements.autoShareQuota?.value, 10) || 5,
        follow: parseInt(elements.autoFollowQuota?.value, 10) || 10
    };

    console.log(`Starting ${type} automation with quota:`, quotas[type]);

    chrome.runtime.sendMessage({
        action: 'startAdvancedAutomation',
        type,
        quota: quotas[type]
    }, (response) => {
        if (response && response.success) {
            alert(`${type.charAt(0).toUpperCase() + type.slice(1)} automation started!`);
        } else {
            alert(`Failed to start ${type} automation. Check console for errors.`);
        }
    });

    window.close();
}

/**
 * AI Comment Settings Management
 * Handles save/load/sync of comment generation settings
 */

// Save comment settings to storage
async function saveCommentSettings() {
    const goal = document.getElementById('comment-goal')?.value;
    const tone = document.getElementById('comment-tone')?.value;
    const commentLength = document.getElementById('comment-length')?.value;
    const commentStyle = document.getElementById('comment-style')?.value;
    const userExpertise = document.getElementById('user-expertise')?.value;
    const userBackground = document.getElementById('user-background')?.value;
    const aiAutoPost = document.getElementById('ai-auto-post')?.value;
    
    const settings = {
        goal: goal || 'AddValue',
        tone: tone || 'Friendly',
        commentLength: commentLength || 'Short',
        commentStyle: commentStyle || 'direct',
        userExpertise: userExpertise || '',
        userBackground: userBackground || '',
        aiAutoPost: aiAutoPost || 'manual'
    };
    
    await chrome.storage.local.set({ commentSettings: settings });
    console.log('💾 Comment settings saved:', settings);
    
    return settings;
}

// Load comment settings from storage
async function loadCommentSettings() {
    const result = await chrome.storage.local.get('commentSettings');
    const settings = result.commentSettings || {
        goal: 'AddValue',
        tone: 'Friendly',
        commentLength: 'Short',
        commentStyle: 'direct',
        userExpertise: '',
        userBackground: '',
        aiAutoPost: 'manual'
    };
    
    // Update UI elements
    const goalSelect = document.getElementById('comment-goal');
    const toneSelect = document.getElementById('comment-tone');
    const lengthSelect = document.getElementById('comment-length');
    const styleSelect = document.getElementById('comment-style');
    const expertiseInput = document.getElementById('user-expertise');
    const backgroundTextarea = document.getElementById('user-background');
    const aiAutoPostSelect = document.getElementById('ai-auto-post');
    
    if (goalSelect) goalSelect.value = settings.goal;
    if (toneSelect) toneSelect.value = settings.tone;
    if (lengthSelect) lengthSelect.value = settings.commentLength || 'Short';
    if (styleSelect) styleSelect.value = settings.commentStyle || 'direct';
    if (expertiseInput) expertiseInput.value = settings.userExpertise || '';
    if (backgroundTextarea) backgroundTextarea.value = settings.userBackground || '';
    if (aiAutoPostSelect) aiAutoPostSelect.value = settings.aiAutoPost || 'manual';
    
    console.log('📂 Comment settings loaded:', settings);
    
    return settings;
}

// Initialize comment settings listeners
function initCommentSettings() {
    console.log('🎯 Initializing comment settings...');
    
    // Load settings on init
    loadCommentSettings();
    
    // Add change listeners for auto-save
    const goalSelect = document.getElementById('comment-goal');
    const toneSelect = document.getElementById('comment-tone');
    const lengthSelect = document.getElementById('comment-length');
    const styleSelect = document.getElementById('comment-style');
    const expertiseInput = document.getElementById('user-expertise');
    const backgroundTextarea = document.getElementById('user-background');
    
    if (goalSelect) {
        goalSelect.addEventListener('change', saveCommentSettings);
    }
    
    if (toneSelect) {
        toneSelect.addEventListener('change', saveCommentSettings);
    }
    
    if (lengthSelect) {
        lengthSelect.addEventListener('change', saveCommentSettings);
    }
    
    if (styleSelect) {
        styleSelect.addEventListener('change', saveCommentSettings);
    }
    
    if (expertiseInput) {
        expertiseInput.addEventListener('blur', saveCommentSettings);
        expertiseInput.addEventListener('keyup', debounce(saveCommentSettings, 1000));
    }
    
    if (backgroundTextarea) {
        backgroundTextarea.addEventListener('blur', saveCommentSettings);
        backgroundTextarea.addEventListener('keyup', debounce(saveCommentSettings, 1000));
    }
    
    const aiAutoPostSelect = document.getElementById('ai-auto-post');
    if (aiAutoPostSelect) {
        aiAutoPostSelect.addEventListener('change', saveCommentSettings);
    }
    
    console.log('✅ Comment settings initialized');
}

// Debounce helper for auto-save
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// --- INTELLIGENT CACHING SYSTEM --- //
// Cache data for 15 minutes to speed up popup loading

const CACHE_DURATION = 15 * 60 * 1000; // 15 minutes in milliseconds

/**
 * Get cached data if still valid
 * @param {string} key - Cache key
 * @returns {Promise<any|null>} Cached data or null if expired
 */
async function getCachedData(key) {
    try {
        const cacheKey = `cache_${key}`;
        const timestampKey = `cache_${key}_timestamp`;
        
        const result = await chrome.storage.local.get([cacheKey, timestampKey]);
        
        if (!result[cacheKey] || !result[timestampKey]) {
            return null; // No cache
        }
        
        const now = Date.now();
        const cacheAge = now - result[timestampKey];
        
        if (cacheAge > CACHE_DURATION) {
            // Cache expired
            console.log(`\u23f0 Cache expired for ${key} (age: ${Math.round(cacheAge / 1000)}s)`);
            return null;
        }
        
        console.log(`\u2705 Using cached ${key} (age: ${Math.round(cacheAge / 1000)}s)`);
        return result[cacheKey];
    } catch (error) {
        console.error(`Error getting cached data for ${key}:`, error);
        return null;
    }
}

/**
 * Set cached data with timestamp
 * @param {string} key - Cache key
 * @param {any} data - Data to cache
 */
async function setCachedData(key, data) {
    try {
        const cacheKey = `cache_${key}`;
        const timestampKey = `cache_${key}_timestamp`;
        
        await chrome.storage.local.set({
            [cacheKey]: data,
            [timestampKey]: Date.now()
        });
        
        console.log(`\ud83d\udcbe Cached ${key}`);
    } catch (error) {
        console.error(`Error setting cached data for ${key}:`, error);
    }
}

// --- SIMPLIFIED DASHBOARD PROGRESS TRACKING --- //
// Simple progress bar and stop button only


let progressMonitorInterval = null;
let currentProcessType = null; // 'automation' | 'networking' | null
let hideProgressTimeout = null;
let lastActiveState = { automation: false, networking: false };
let lastUpdateData = {}; // For change detection

/**
 * Initialize dashboard progress monitoring
 */
function initializeDashboardProgress() {
    console.log('🎯 Initializing enhanced dashboard progress...');
    
    // Set up stop button
    const stopBtn = document.getElementById('dashboard-stop-btn');
    if (stopBtn) {
        stopBtn.addEventListener('click', handleDashboardStop);
    }
    
    // Start monitoring
    startProgressMonitoring();
    
    console.log('✅ Dashboard progress initialized');
}

/**
 * Start monitoring for active processes
 */
function startProgressMonitoring() {
    // Clean up any existing intervals or timeouts
    if (progressMonitorInterval) {
        clearInterval(progressMonitorInterval);
    }
    if (hideProgressTimeout) {
        clearTimeout(hideProgressTimeout);
        hideProgressTimeout = null;
    }
    
    progressMonitorInterval = setInterval(async () => {
        await checkActiveProcesses();
    }, 3000); // Check every 3 seconds - simple state check only
}

/**
 * Check for active automation/networking processes (with debouncing to prevent blinking)
 */
async function checkActiveProcesses() {
    try {
        // Check automation state with timeout
        const automationResponse = await sendMessageSafe({ action: 'checkBulkProcessingState' }, 2000);
        const automationActive = automationResponse?.active || false;
        
        // Check networking state with timeout
        const networkingResponse = await sendMessageSafe({ action: 'checkPeopleSearchState' }, 2000);
        const networkingActive = networkingResponse?.active || false;
        
        // Clear any pending hide timeout if processes are active
        if ((automationActive || networkingActive) && hideProgressTimeout) {
            clearTimeout(hideProgressTimeout);
            hideProgressTimeout = null;
        }
        
        // Only update UI if state actually changed
        const stateChanged = (
            lastActiveState.automation !== automationActive || 
            lastActiveState.networking !== networkingActive
        );
        
        if (stateChanged) {
            console.log(`🔄 Process state changed - Automation: ${automationActive}, Networking: ${networkingActive}`);
            
            // Update last known states
            lastActiveState.automation = automationActive;
            lastActiveState.networking = networkingActive;
            
            // Show progress section immediately if processes are active
            if (automationActive && !networkingActive) {
                showProgressSection('automation');
                updateSimpleProgress();
            } else if (networkingActive && !automationActive) {
                showProgressSection('networking');
                updateSimpleProgress();
            } else if (automationActive && networkingActive) {
                // Both running - show automation as primary
                showProgressSection('automation');
                updateSimpleProgress();
            } else if (!automationActive && !networkingActive) {
                // Both inactive - debounce hiding to prevent blinking
                if (hideProgressTimeout) {
                    clearTimeout(hideProgressTimeout);
                }
                hideProgressTimeout = setTimeout(() => {
                    console.log('🔄 Hiding progress section after debounce');
                    hideProgressSection();
                    hideProgressTimeout = null;
                }, 5000); // Wait 5 seconds before hiding to prevent blinking
            }
        }
        
    } catch (error) {
        console.warn('⚠️ Error checking process states:', error);
        // Don't hide progress section on error - keep current state
    }
}

/**
 * Simple progress update - just show a generic progress bar
 */
function updateSimpleProgress() {
    if (currentProcessType === 'automation') {
        updateProgressBar(50); // Show 50% as generic progress
        updateProgressDetail('Automation in progress...');
    } else if (currentProcessType === 'networking') {
        updateProgressBar(50); // Show 50% as generic progress
        updateProgressDetail('Networking in progress...');
    }
}

/**
 * Show progress section based on process type
 */
function showProgressSection(processType) {
    const progressSection = document.getElementById('live-progress-section');
    if (!progressSection) return;
    
    currentProcessType = processType;
    progressSection.style.display = 'block';
    
    // Update section title based on process type
    const statusElement = document.getElementById('live-status-text');
    if (statusElement) {
        if (processType === 'automation') {
            statusElement.textContent = 'Automation Running';
        } else if (processType === 'networking') {
            statusElement.textContent = 'Networking Running';
        }
    }
    
    // Show stop button
    const stopBtn = document.getElementById('dashboard-stop-btn');
    if (stopBtn) {
        stopBtn.style.display = 'inline-block';
    }
}

/**
 * Hide progress section
 */
function hideProgressSection() {
    const progressSection = document.getElementById('live-progress-section');
    if (progressSection) {
        progressSection.style.display = 'none';
    }
    
    // Hide stop button
    const stopBtn = document.getElementById('dashboard-stop-btn');
    if (stopBtn) {
        stopBtn.style.display = 'none';
    }
    
    // Reset status text
    const statusElement = document.getElementById('live-status-text');
    if (statusElement) {
        statusElement.textContent = 'Idle';
    }
    
    currentProcessType = null;
}


/**
 * Update progress bar percentage (with change detection)
 */
function updateProgressBar(percentage) {
    const roundedPercentage = Math.round(percentage);
    
    // Only update if percentage changed
    if (!lastUpdateData.progressPercentage || lastUpdateData.progressPercentage !== roundedPercentage) {
        const progressBar = document.getElementById('live-progress-bar');
        const progressText = document.getElementById('live-progress-percentage');
        
        if (progressBar) {
            progressBar.style.width = `${Math.min(100, Math.max(0, roundedPercentage))}%`;
        }
        
        if (progressText) {
            progressText.textContent = `${roundedPercentage}%`;
        }
        
        lastUpdateData.progressPercentage = roundedPercentage;
    }
}

/**
 * Update progress detail text (with change detection)
 */
function updateProgressDetail(text) {
    // Only update if text changed
    if (!lastUpdateData.progressDetail || lastUpdateData.progressDetail !== text) {
        const element = document.getElementById('live-progress-detail');
        if (element) {
            element.textContent = text;
        }
        lastUpdateData.progressDetail = text;
    }
}

/**
 * Handle dashboard stop button click
 */
async function handleDashboardStop() {
    if (!currentProcessType) return;
    
    const stopBtn = document.getElementById('dashboard-stop-btn');
    if (stopBtn) {
        stopBtn.disabled = true;
        stopBtn.textContent = '⏳ Stopping...';
    }
    
    try {
        if (currentProcessType === 'automation') {
            await sendMessageSafe({ action: 'stopBulkProcessing' }, 3000);
            console.log('🛑 Stopped automation from dashboard');
        } else if (currentProcessType === 'networking') {
            await sendMessageSafe({ action: 'stopPeopleSearch' }, 3000);
            console.log('🛑 Stopped networking from dashboard');
        }
        
        // Hide progress section after short delay
        setTimeout(() => {
            hideProgressSection();
        }, 2000);
        
    } catch (error) {
        console.error('❌ Error stopping process:', error);
    } finally {
        if (stopBtn) {
            stopBtn.disabled = false;
            stopBtn.textContent = '🛑 Stop';
        }
    }
}

// --- PROCESSING HISTORY MANAGER --- //
// Tracks and displays all automation and networking processing sessions

let historyData = [];
let filteredHistory = [];

/**
 * Initialize processing history functionality
 */
function initializeProcessingHistory() {
    console.log('📝 Initializing processing history...');
    
    try {
        // Set up event listeners
        setupHistoryEventListeners();
        
        // Load existing history
        loadProcessingHistory();
        
        // Also refresh periodically to catch new sessions
        setInterval(() => {
            loadProcessingHistory();
        }, 5000);
        
        console.log('✅ Processing history initialized successfully');
    } catch (error) {
        console.error('❌ Error initializing processing history:', error);
        
        // Try to show basic message in UI
        const tbody = document.getElementById('history-table-body');
        if (tbody) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="9" style="padding: 20px; text-align: center; color: #dc3545;">
                        Error initializing processing history: ${error.message}
                    </td>
                </tr>
            `;
        }
    }
}

/**
 * Set up event listeners for history controls
 */
function setupHistoryEventListeners() {
    // Filter controls
    const typeFilter = document.getElementById('history-filter-type');
    const statusFilter = document.getElementById('history-filter-status');
    
    if (typeFilter) {
        typeFilter.addEventListener('change', updateHistoryDisplay);
    }
    
    if (statusFilter) {
        statusFilter.addEventListener('change', updateHistoryDisplay);
    }
    
    // Action buttons
    const refreshBtn = document.getElementById('refresh-history');
    const exportBtn = document.getElementById('export-history');
    const clearBtn = document.getElementById('clear-history');
    
    if (refreshBtn) {
        refreshBtn.addEventListener('click', () => {
            console.log('📝 DEBUG: Manual refresh button clicked');
            loadProcessingHistory();
        });
    }
    
    if (exportBtn) {
        exportBtn.addEventListener('click', exportHistoryCSV);
    }
    
    if (clearBtn) {
        clearBtn.addEventListener('click', clearProcessingHistory);
    }
}

/**
 * Load processing history from storage
 */
async function loadProcessingHistory() {
    try {
        console.log('📝 DEBUG: Starting to load processing history...');
        
        // Check if chrome.storage is available
        if (!chrome || !chrome.storage || !chrome.storage.local) {
            throw new Error('Chrome storage API not available');
        }
        
        const result = await chrome.storage.local.get('processingHistory');
        console.log('📝 DEBUG: Raw storage result:', result);
        
        historyData = result.processingHistory || [];
        
        console.log(`📝 DEBUG: Loaded ${historyData.length} processing sessions from storage`);
        if (historyData.length > 0) {
            console.log('📝 DEBUG: Latest session:', JSON.stringify(historyData[0], null, 2));
            console.log('📝 DEBUG: All sessions:', historyData.map(s => ({ id: s.id, type: s.type, status: s.status, processed: s.processed })));
        } else {
            console.log('📝 DEBUG: No processing history found in storage');
        }
        
        // Update display
        updateHistoryDisplay();
        
    } catch (error) {
        console.error('❌ Error loading processing history:', error);
        historyData = [];
        
        // Show error in UI
        const tbody = document.getElementById('history-table-body');
        if (tbody) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="9" style="padding: 20px; text-align: center; color: #dc3545;">
                        Error loading history: ${error.message}
                    </td>
                </tr>
            `;
        }
    }
}

/**
 * Save processing history to storage
 */
async function saveProcessingHistory() {
    try {
        await chrome.storage.local.set({ processingHistory: historyData });
        console.log(`📝 Saved ${historyData.length} processing sessions to storage`);
    } catch (error) {
        console.error('Error saving processing history:', error);
    }
}

/**
 * Apply filters to history data
 */
function applyFilters() {
    const typeFilter = document.getElementById('history-filter-type')?.value || 'all';
    const statusFilter = document.getElementById('history-filter-status')?.value || 'all';
    
    filteredHistory = historyData.filter(session => {
        const typeMatch = typeFilter === 'all' || session.type === typeFilter;
        const statusMatch = statusFilter === 'all' || session.status === statusFilter;
        return typeMatch && statusMatch;
    });
    
    // Don't call updateHistoryDisplay here - this was causing infinite recursion
}

/**
 * Update the history display with current data
 */
function updateHistoryDisplay() {
    // Apply current filters (without calling updateHistoryDisplay)
    applyFilters();
    
    // Update stats
    updateHistoryStats();
    
    // Update table
    updateHistoryTable();
}

/**
 * Update history statistics
 */
function updateHistoryStats() {
    const totalSessions = historyData.length;
    const automationSessions = historyData.filter(s => s.type === 'automation').length;
    const networkingSessions = historyData.filter(s => s.type === 'networking').length;
    const completedSessions = historyData.filter(s => s.status === 'completed').length;
    const successRate = totalSessions > 0 ? Math.round((completedSessions / totalSessions) * 100) : 0;
    
    // Update UI elements
    updateElement('total-sessions-count', totalSessions);
    updateElement('automation-sessions', automationSessions);
    updateElement('networking-sessions', networkingSessions);
    updateElement('success-rate', `${successRate}%`);
}

/**
 * Update history table with filtered data
 */
function updateHistoryTable() {
    const tbody = document.getElementById('history-table-body');
    if (!tbody) return;
    
    if (filteredHistory.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="9" style="padding: 20px; text-align: center; color: #6c757d;">
                    No processing sessions match the current filters.
                </td>
            </tr>
        `;
        return;
    }
    
    tbody.innerHTML = filteredHistory.map(session => {
        const statusIcon = getStatusIcon(session.status);
        const typeIcon = session.type === 'automation' ? '🤖' : '👔';
        const duration = formatDuration(session.duration);
        const date = new Date(session.startTime).toLocaleDateString() + ' ' + 
                    new Date(session.startTime).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
        
        return `
            <tr>
                <td style="padding: 8px; border-bottom: 1px solid #eee;">
                    ${typeIcon} ${session.type.charAt(0).toUpperCase() + session.type.slice(1)}
                </td>
                <td style="padding: 8px; border-bottom: 1px solid #eee; max-width: 150px; overflow: hidden; text-overflow: ellipsis;" title="${session.query}">
                    ${session.query}
                </td>
                <td style="padding: 8px; border-bottom: 1px solid #eee; text-align: center;">
                    ${session.target}
                </td>
                <td style="padding: 8px; border-bottom: 1px solid #eee; text-align: center;">
                    ${session.processed}
                </td>
                <td style="padding: 8px; border-bottom: 1px solid #eee; text-align: center;">
                    ${session.successRate !== undefined ? session.successRate + '%' : (session.processed > 0 ? Math.round((session.successful / session.processed) * 100) + '%' : '0%')}
                </td>
                <td style="padding: 8px; border-bottom: 1px solid #eee; text-align: center;">
                    ${duration}
                </td>
                <td style="padding: 8px; border-bottom: 1px solid #eee; text-align: center;">
                    ${statusIcon} ${session.status}
                </td>
                <td style="padding: 8px; border-bottom: 1px solid #eee; font-size: 11px;">
                    ${date}
                </td>
                <td style="padding: 8px; border-bottom: 1px solid #eee; text-align: center;">
                    <button onclick="viewSessionDetails('${session.id}')" style="background: none; border: 1px solid #ddd; padding: 2px 6px; border-radius: 3px; font-size: 10px; cursor: pointer;" title="View Details">
                        👁️
                    </button>
                    <button onclick="deleteSession('${session.id}')" style="background: none; border: 1px solid #ddd; padding: 2px 6px; border-radius: 3px; font-size: 10px; cursor: pointer; margin-left: 2px;" title="Delete">
                        🗑️
                    </button>
                </td>
            </tr>
        `;
    }).join('');
}

/**
 * Export history as CSV
 */
function exportHistoryCSV() {
    if (historyData.length === 0) {
        alert('No processing history to export.');
        return;
    }
    
    const headers = ['Type', 'Query/Keywords', 'Target', 'Processed', 'Successful', 'Success Rate', 'Status', 'Duration', 'Start Time', 'End Time'];
    
    const csvContent = [
        headers.join(','),
        ...historyData.map(session => [
            session.type,
            `"${session.query.replace(/"/g, '""')}"`, // Escape quotes
            session.target,
            session.processed,
            session.successful,
            `${session.successRate}%`,
            session.status,
            formatDuration(session.duration),
            new Date(session.startTime).toISOString(),
            new Date(session.endTime).toISOString()
        ].join(','))
    ].join('\n');
    
    // Download CSV
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `processing_history_${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    console.log('📥 Processing history exported as CSV');
}

/**
 * Clear all processing history
 */
async function clearProcessingHistory() {
    if (!confirm('Are you sure you want to clear all processing history? This action cannot be undone.')) {
        return;
    }
    
    historyData = [];
    filteredHistory = [];
    
    await saveProcessingHistory();
    updateHistoryDisplay();
    
    console.log('🗑️ Processing history cleared');
}

function getStatusIcon(status) {
    switch (status) {
        case 'completed': return '✅';
        case 'stopped': return '⏹️';
        case 'failed': return '❌';
        default: return '❓';
    }
}

function formatDuration(milliseconds) {
    if (!milliseconds || milliseconds < 1000) return '< 1s';
    
    const seconds = Math.floor(milliseconds / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    
    if (hours > 0) {
        return `${hours}h ${minutes % 60}m`;
    } else if (minutes > 0) {
        return `${minutes}m ${seconds % 60}s`;
    } else {
        return `${seconds}s`;
    }
}

function updateElement(id, value) {
    const element = document.getElementById(id);
    if (element) {
        element.textContent = value;
    }
}

/**
 * Global functions for button actions (called from HTML)
 */
window.viewSessionDetails = function(sessionId) {
    console.log('👁️ View details clicked for session:', sessionId);
    
    // Try to find session in current data
    let session = historyData.find(s => s.id === sessionId);
    
    // If not found, try to reload from storage
    if (!session) {
        chrome.storage.local.get('processingHistory').then(result => {
            const allSessions = result.processingHistory || [];
            session = allSessions.find(s => s.id === sessionId);
            
            if (session) {
                showSessionDetails(session);
            } else {
                alert('Session not found.');
            }
        });
        return;
    }
    
    showSessionDetails(session);
};

function showSessionDetails(session) {
    const successRate = session.successRate !== undefined ? session.successRate : 
        (session.processed > 0 ? Math.round((session.successful / session.processed) * 100) : 0);
    
    const details = `Session Details:

Type: ${session.type?.charAt(0).toUpperCase() + session.type?.slice(1) || 'Unknown'}
Query/Keywords: ${session.query || 'N/A'}
Target: ${session.target || 0}
Processed: ${session.processed || 0}
Successful: ${session.successful || 0}
Success Rate: ${successRate}%
Status: ${session.status || 'Unknown'}
Duration: ${formatDuration(session.duration)}
Start Time: ${new Date(session.startTime).toLocaleString()}
End Time: ${new Date(session.endTime).toLocaleString()}

${session.actions ? 'Actions: ' + JSON.stringify(session.actions) : ''}
${session.error ? 'Error: ' + session.error : ''}`;

    alert(details);
}

window.deleteSession = function(sessionId) {
    if (!confirm('Are you sure you want to delete this session?')) {
        return;
    }
    
    const index = historyData.findIndex(s => s.id === sessionId);
    if (index !== -1) {
        historyData.splice(index, 1);
        saveProcessingHistory();
        updateHistoryDisplay();
        console.log('🗑️ Processing session deleted');
    }
};

/**
 * Manual test function to add sample data and test the system
 */
async function testProcessingHistory() {
    console.log('🧪 Testing processing history system...');
    
    // Clear existing data
    await chrome.storage.local.set({ processingHistory: [] });
    console.log('🧹 Cleared existing history');
    
    // Add test sessions
    const testSessions = [
        {
            id: 'test-1-' + Date.now(),
            type: 'automation',
            query: 'test SEO keywords',
            target: 10,
            processed: 5,
            successful: 5,
            status: 'stopped',
            startTime: Date.now() - 120000,
            endTime: Date.now() - 90000,
            duration: 30000,
            successRate: 100
        },
        {
            id: 'test-2-' + Date.now(),
            type: 'networking',
            query: 'Marketing Manager',
            target: 15,
            processed: 12,
            successful: 10,
            status: 'completed',
            startTime: Date.now() - 300000,
            endTime: Date.now() - 180000,
            duration: 120000,
            successRate: 83
        }
    ];
    
    // Save test sessions
    await chrome.storage.local.set({ processingHistory: testSessions });
    console.log('📝 Added test sessions:', testSessions);
    
    // Reload and display
    await loadProcessingHistory();
    
    console.log('✅ Test completed. Check the Processing History section.');
}

/**
 * Function to force refresh the processing history UI
 */
async function forceRefreshHistory() {
    console.log('🔄 Force refreshing processing history...');
    await loadProcessingHistory();
}

// Make test functions available globally for console debugging
if (typeof window !== 'undefined') {
    window.testProcessingHistory = testProcessingHistory;
    window.forceRefreshHistory = forceRefreshHistory;
    window.loadProcessingHistory = loadProcessingHistory;
}

/**
 * Walkthrough Module - Compact user onboarding
 * Quick tips positioned top-right, detailed guide in Settings
 */

// Compact walkthrough steps (3-4 lines max each)
const walkthroughSteps = [
    {
        id: 'welcome',
        title: '👋 Welcome!',
        content: 'This quick tour shows you the basics.<br>Detailed guides are in <strong>Settings → Help</strong>.',
        tab: null
    },
    {
        id: 'dashboard',
        title: '📊 Dashboard',
        content: 'Your stats hub. See engagements, usage limits, and quick actions.',
        tab: 'dashboard'
    },
    {
        id: 'post-writer',
        title: '✍️ AI Writer',
        content: 'Generate LinkedIn posts with AI. Enter topic → Generate → Post!',
        tab: 'post-writer'
    },
    {
        id: 'automation',
        title: '🤖 Automation',
        content: 'Auto-engage with posts. Set keywords, choose actions, and start.',
        tab: 'automation'
    },
    {
        id: 'networking',
        title: '🤝 Networking',
        content: 'Auto-connect with people. Search by role, filter, and connect.',
        tab: 'networking'
    },
    {
        id: 'import',
        title: '📥 Import',
        content: 'Import profiles from CSV to engage with specific people.',
        tab: 'import'
    },
    {
        id: 'limits',
        title: '📏 Limits',
        content: 'Set daily limits and delays. Keep your account safe!',
        tab: 'limits'
    },
    {
        id: 'settings',
        title: '⚙️ Settings',
        content: 'Manage account, preferences, and find detailed guides here.',
        tab: 'settings'
    },
    {
        id: 'complete',
        title: '🚀 Ready!',
        content: 'Tour complete! Check <strong>Settings → Help</strong> for full guides.',
        tab: 'dashboard'
    }
];

let currentStepIndex = 0;
let walkthroughOverlay = null;

/**
 * Check if walkthrough has been completed
 */
async function hasCompletedWalkthrough() {
    return new Promise((resolve) => {
        chrome.storage.local.get(['walkthroughCompleted'], (result) => {
            resolve(result.walkthroughCompleted === true);
        });
    });
}

/**
 * Mark walkthrough as completed
 */
async function markWalkthroughCompleted() {
    return new Promise((resolve) => {
        chrome.storage.local.set({ walkthroughCompleted: true }, resolve);
    });
}

/**
 * Reset walkthrough (for settings button)
 */
async function resetWalkthrough() {
    return new Promise((resolve) => {
        chrome.storage.local.set({ walkthroughCompleted: false }, () => {
            resolve();
            startWalkthrough();
        });
    });
}

/**
 * Create compact walkthrough tooltip (top-right)
 */
function createWalkthroughOverlay() {
    const overlay = document.createElement('div');
    overlay.id = 'walkthrough-overlay';
    overlay.innerHTML = `
        <style>
            #walkthrough-overlay {
                position: fixed;
                top: 70px;
                right: 10px;
                z-index: 99999;
                pointer-events: none;
            }
            
            .walkthrough-tooltip {
                background: white;
                border-radius: 12px;
                width: 220px;
                box-shadow: 0 4px 20px rgba(0, 0, 0, 0.25);
                animation: slideIn 0.2s ease;
                pointer-events: auto;
                border: 2px solid #693fe9;
            }
            
            @keyframes slideIn {
                from { opacity: 0; transform: translateX(20px); }
                to { opacity: 1; transform: translateX(0); }
            }
            
            .walkthrough-header {
                background: linear-gradient(135deg, #693fe9 0%, #7c4dff 100%);
                color: white;
                padding: 10px 12px;
                border-radius: 10px 10px 0 0;
            }
            
            .walkthrough-title {
                font-size: 13px;
                font-weight: 700;
                margin: 0;
            }
            
            .walkthrough-progress {
                display: flex;
                gap: 3px;
                margin-top: 6px;
            }
            
            .walkthrough-progress-dot {
                width: 6px;
                height: 6px;
                border-radius: 50%;
                background: rgba(255, 255, 255, 0.3);
            }
            
            .walkthrough-progress-dot.active {
                background: white;
            }
            
            .walkthrough-progress-dot.completed {
                background: #4caf50;
            }
            
            .walkthrough-content {
                padding: 10px 12px;
                font-size: 12px;
                line-height: 1.5;
                color: #333;
            }
            
            .walkthrough-footer {
                padding: 8px 12px;
                border-top: 1px solid #eee;
                display: flex;
                justify-content: space-between;
                align-items: center;
            }
            
            .walkthrough-step-count {
                font-size: 10px;
                color: #999;
            }
            
            .walkthrough-buttons {
                display: flex;
                gap: 6px;
            }
            
            .walkthrough-btn {
                padding: 5px 10px;
                border-radius: 6px;
                font-size: 11px;
                font-weight: 600;
                cursor: pointer;
                border: none;
            }
            
            .walkthrough-btn-back {
                background: #f0f0f0;
                color: #666;
            }
            
            .walkthrough-btn-next {
                background: #693fe9;
                color: white;
            }
            
            .walkthrough-btn:disabled {
                opacity: 0.4;
            }
            
            .walkthrough-btn-skip {
                background: transparent;
                color: #999;
                font-size: 10px;
                padding: 4px 8px;
            }
            
            .walkthrough-btn-skip:hover {
                color: #666;
                background: #f5f5f5;
            }
            
            .walkthrough-skip-container {
                text-align: center;
                padding: 0 12px 8px;
            }
        </style>
        
        <div class="walkthrough-tooltip">
            <div class="walkthrough-header">
                <div class="walkthrough-title" id="walkthrough-title"></div>
                <div class="walkthrough-progress" id="walkthrough-progress"></div>
            </div>
            <div class="walkthrough-content" id="walkthrough-content"></div>
            <div class="walkthrough-footer">
                <span class="walkthrough-step-count" id="walkthrough-step-count"></span>
                <div class="walkthrough-buttons">
                    <button class="walkthrough-btn walkthrough-btn-back" id="walkthrough-back">←</button>
                    <button class="walkthrough-btn walkthrough-btn-next" id="walkthrough-next">Next</button>
                </div>
            </div>
            <div class="walkthrough-skip-container">
                <button class="walkthrough-btn walkthrough-btn-skip" id="walkthrough-skip">Skip Tour</button>
            </div>
        </div>
    `;
    
    return overlay;
}

/**
 * Switch tab directly without circular import
 */
function switchToTab$1(tabId) {
    console.log(`🎯 Walkthrough: Switching to tab: ${tabId}`);
    
    // Update tab buttons
    const allButtons = document.querySelectorAll('.tab-button');
    console.log(`🔍 Walkthrough: Found ${allButtons.length} tab buttons`);
    allButtons.forEach(t => {
        t.classList.remove('active');
        if (t.getAttribute('data-tab') === tabId) {
            t.classList.add('active');
            console.log(`✅ Walkthrough: Activated tab button: ${tabId}`);
        }
    });

    // Update tab contents - use direct style manipulation
    const allContents = document.querySelectorAll('.tab-content');
    console.log(`🔍 Walkthrough: Found ${allContents.length} tab contents`);
    let found = false;
    allContents.forEach(content => {
        const contentTabId = content.id.replace('-content', '');
        if (contentTabId === tabId) {
            content.classList.add('active');
            content.style.display = 'block';
            found = true;
            console.log(`👁️ Walkthrough: SHOWING content: ${content.id}`);
        } else {
            content.classList.remove('active');
            content.style.display = 'none';
        }
    });
    
    if (!found) {
        console.error(`❌ Walkthrough: Could not find tab content for: ${tabId}-content`);
    }
    
    console.log(`📑 Walkthrough switched to tab: ${tabId}`);
}

/**
 * Update walkthrough display for current step
 */
function updateWalkthroughStep() {
    const step = walkthroughSteps[currentStepIndex];
    
    // Update title
    document.getElementById('walkthrough-title').textContent = step.title;
    
    // Update content
    document.getElementById('walkthrough-content').innerHTML = step.content;
    
    // Update progress dots
    const progressContainer = document.getElementById('walkthrough-progress');
    progressContainer.innerHTML = walkthroughSteps.map((s, i) => {
        let className = 'walkthrough-progress-dot';
        if (i < currentStepIndex) className += ' completed';
        if (i === currentStepIndex) className += ' active';
        return `<div class="${className}"></div>`;
    }).join('');
    
    // Update step count
    document.getElementById('walkthrough-step-count').textContent = 
        `${currentStepIndex + 1}/${walkthroughSteps.length}`;
    
    // Update buttons
    const backBtn = document.getElementById('walkthrough-back');
    const nextBtn = document.getElementById('walkthrough-next');
    
    backBtn.disabled = currentStepIndex === 0;
    backBtn.style.visibility = currentStepIndex === 0 ? 'hidden' : 'visible';
    
    if (currentStepIndex === walkthroughSteps.length - 1) {
        nextBtn.textContent = 'Done!';
    } else {
        nextBtn.textContent = 'Next';
    }
    
    // Switch to corresponding tab if specified
    if (step.tab) {
        switchToTab$1(step.tab);
    }
}

/**
 * Start walkthrough
 */
async function startWalkthrough() {
    currentStepIndex = 0;
    
    // Create and show overlay
    walkthroughOverlay = createWalkthroughOverlay();
    document.body.appendChild(walkthroughOverlay);
    
    // Set up button handlers
    document.getElementById('walkthrough-back').addEventListener('click', () => {
        if (currentStepIndex > 0) {
            currentStepIndex--;
            updateWalkthroughStep();
        }
    });
    
    document.getElementById('walkthrough-next').addEventListener('click', async () => {
        if (currentStepIndex < walkthroughSteps.length - 1) {
            currentStepIndex++;
            updateWalkthroughStep();
        } else {
            // Complete walkthrough
            await markWalkthroughCompleted();
            closeWalkthrough();
        }
    });
    
    // Skip button handler
    document.getElementById('walkthrough-skip').addEventListener('click', async () => {
        await markWalkthroughCompleted();
        closeWalkthrough();
        console.log('✅ Walkthrough skipped by user');
    });
    
    // Show first step
    updateWalkthroughStep();
}

/**
 * Close walkthrough overlay
 */
function closeWalkthrough() {
    if (walkthroughOverlay && walkthroughOverlay.parentNode) {
        const overlay = walkthroughOverlay;
        walkthroughOverlay = null; // Prevent double-click issues
        overlay.style.opacity = '0';
        overlay.style.transition = 'opacity 0.3s ease';
        setTimeout(() => {
            if (overlay && overlay.parentNode) {
                overlay.parentNode.removeChild(overlay);
            }
        }, 300);
    }
}

/**
 * Initialize walkthrough for new users
 */
async function initializeWalkthrough() {
    const completed = await hasCompletedWalkthrough();
    if (!completed) {
        // Small delay to let the UI render first
        setTimeout(() => {
            startWalkthrough();
        }, 500);
    }
}

// --- INITIALIZATION --- //
function initializeElements() {
    // Get all UI elements
    Object.assign(elements, {
        // Master switch
        masterSwitch: document.getElementById('master-switch'),

        // Tabs
        tabs: document.querySelectorAll('.tab-button'),
        tabContents: document.querySelectorAll('.tab-content'),

        // Dashboard
        todayComments: document.getElementById('today-comments'),
        todayLikes: document.getElementById('today-likes'),
        todayShares: document.getElementById('today-shares'),
        todayFollows: document.getElementById('today-follows'),
        weekTotal: document.getElementById('week-total'),
        responseRate: document.getElementById('response-rate'),

        // Quick actions
        quickPostWriter: document.getElementById('quick-post-writer'),
        quickAutomation: document.getElementById('quick-automation'),
        quickNetworking: document.getElementById('quick-networking'),
        quickContent: document.getElementById('quick-content'),
        quickImport: document.getElementById('quick-import'),

        // Schedulers
        bulkSchedulerEnabled: document.getElementById('bulk-scheduler-enabled'),
        bulkScheduleTimeInput: document.getElementById('bulk-schedule-time-input'),
        addBulkSchedule: document.getElementById('add-bulk-schedule'),
        bulkScheduleList: document.getElementById('bulk-schedule-list'),
        bulkNextExecutionTime: document.getElementById('bulk-next-execution-time'),
        bulkCountdownTimer: document.getElementById('bulk-countdown-timer'),

        peopleSchedulerEnabled: document.getElementById('people-scheduler-enabled'),
        peopleScheduleTimeInput: document.getElementById('people-schedule-time-input'),
        addPeopleSchedule: document.getElementById('add-people-schedule'),
        peopleScheduleList: document.getElementById('people-schedule-list'),
        peopleNextExecutionTime: document.getElementById('people-next-execution-time'),
        peopleCountdownTimer: document.getElementById('people-countdown-timer'),

        // Post Writer
        postTopic: document.getElementById('post-topic'),
        generateTopicLines: document.getElementById('generate-topic-lines'),
        topicLinesContainer: document.getElementById('topic-lines-container'),
        topicLinesList: document.getElementById('topic-lines-list'),
        postTemplate: document.getElementById('post-template'),
        postTone: document.getElementById('post-tone'),
        postLength: document.getElementById('post-length'),
        postIncludeHashtags: document.getElementById('post-include-hashtags'),
        postIncludeEmojis: document.getElementById('post-include-emojis'),
        targetAudience: document.getElementById('target-audience'),
        keyMessage: document.getElementById('key-message'),
        userBackground: document.getElementById('user-background'),
        postContent: document.getElementById('post-content'),
        scheduleDate: document.getElementById('schedule-date'),
        scheduleTime: document.getElementById('schedule-time'),
        scheduleStatus: document.getElementById('schedule-status'),
        generatePost: document.getElementById('generate-post'),
        analyzePost: document.getElementById('analyze-post'),
        copyPost: document.getElementById('copy-post'),
        saveDraft: document.getElementById('save-draft'),
        postToLinkedIn: document.getElementById('post-to-linkedin'),
        schedulePostBtn: document.getElementById('schedule-post-btn'),
        upcomingPosts: document.getElementById('upcoming-posts'),
        postAnalysis: document.getElementById('post-analysis'),
        engagementScore: document.getElementById('engagement-score'),
        postRecommendations: document.getElementById('post-recommendations'),
        draftCount: document.getElementById('draft-count'),
        draftsList: document.getElementById('drafts-list'),

        // Automation
        autoQuota: document.getElementById('auto-quota'),
        autoPostAge: document.getElementById('auto-post-age'),
        startPageAutopilot: document.getElementById('start-page-autopilot'),
        automationError: document.getElementById('automation-error'),
        autoLikeQuota: document.getElementById('auto-like-quota'),
        startAutoLike: document.getElementById('start-auto-like'),
        autoShareQuota: document.getElementById('auto-share-quota'),
        startAutoShare: document.getElementById('start-auto-share'),
        autoFollowQuota: document.getElementById('auto-follow-quota'),
        startAutoFollow: document.getElementById('start-auto-follow'),
        // AI Keyword Generation
        keywordIntent: document.getElementById('keyword-intent'),
        keywordCountSlider: document.getElementById('keyword-count-slider'),
        keywordCountDisplay: document.getElementById('keyword-count-display'),
        generateKeywords: document.getElementById('generate-keywords'),
        clearKeywords: document.getElementById('clear-keywords'),

        // Bulk Processing
        bulkUrls: document.getElementById('bulk-urls'),
        stopBulkProcessing: document.getElementById('stop-bulk-processing'),
        bulkQuota: document.getElementById('bulk-quota'),
        bulkQuotaDisplay: document.getElementById('bulk-quota-display'),
        bulkMinLikes: document.getElementById('bulk-min-likes'),
        bulkMinLikesDisplay: document.getElementById('bulk-min-likes-display'),
        bulkMinComments: document.getElementById('bulk-min-comments'),
        bulkMinCommentsDisplay: document.getElementById('bulk-min-comments-display'),
        bulkLike: document.getElementById('bulk-like'),
        bulkComment: document.getElementById('bulk-comment'),
        bulkLikeOrComment: document.getElementById('bulk-like-or-comment'),
        bulkShare: document.getElementById('bulk-share'),
        bulkFollow: document.getElementById('bulk-follow'),
        ignoreKeywords: document.getElementById('ignore-keywords'),
        startBulkProcessing: document.getElementById('start-bulk-processing'),
        startBulkProcessingBottom: document.getElementById('start-bulk-processing-bottom'),
        stopBulkProcessingBottom: document.getElementById('stop-bulk-processing-bottom'),

        // Business Hours & Daily Schedule
        businessHoursEnabled: document.getElementById('business-hours-enabled'),
        businessStartHour: document.getElementById('business-start-hour'),
        businessEndHour: document.getElementById('business-end-hour'),
        allowWeekends: document.getElementById('allow-weekends'),
        businessHoursStatus: document.getElementById('business-hours-status'),
        dailyScheduleEnabled: document.getElementById('daily-schedule-enabled'),
        dailyScheduleInfo: document.getElementById('daily-schedule-info'),

        // People Search
        searchKeyword: document.getElementById('search-keyword'),
        connectQuota: document.getElementById('connect-quota'),
        connectQuotaDisplay: document.getElementById('connect-quota-display'),

        // System Status
        serviceWorkerStatus: document.getElementById('service-worker-status'),
        businessHoursIndicator: document.getElementById('business-hours-indicator'),
        openaiStatus: document.getElementById('openai-status'),
        statusTimestamp: document.getElementById('status-timestamp'),
        testSystems: document.getElementById('test-systems'),
        useBooleanSearch: document.getElementById('use-boolean-search'),
        filterNetwork: document.getElementById('filter-network'),
        sendWithNote: document.getElementById('send-with-note'),
        sendConnectionRequest: document.getElementById('send-connection-request'),
        extractContactInfo: document.getElementById('extract-contact-info'),
        excludeHeadlineTerms: document.getElementById('exclude-headline-terms'),
        connectionMessage: document.getElementById('connection-message'),
        startPeopleSearch: document.getElementById('start-people-search'),
        stopPeopleSearch: document.getElementById('stop-people-search'),
        startPeopleSearchBottom: document.getElementById('start-people-search-bottom'),
        stopPeopleSearchBottom: document.getElementById('stop-people-search-bottom'),
        peopleSearchStatus: document.getElementById('people-search-status'),

        // Trending Post
        dailyPostTime: document.getElementById('daily-post-time'),
        trendingTemplate: document.getElementById('trending-template'),
        trendingTone: document.getElementById('trending-tone'),
        includeHashtags: document.getElementById('include-hashtags'),
        testTrendingPost: document.getElementById('test-trending-post'),
        enableDailyPost: document.getElementById('enable-daily-post'),
        disableDailyPost: document.getElementById('disable-daily-post'),
        dailyPostStatus: document.getElementById('daily-post-status'),
        dailyPostEnabled: document.getElementById('daily-post-enabled'),

        // Account type and delay settings
        accountType: document.getElementById('account-type'),
        commentDelay: document.getElementById('comment-delay'),

        // New delay controls
        searchDelayMin: document.getElementById('search-delay-min'),
        searchDelayMax: document.getElementById('search-delay-max'),
        searchDelayMinDisplay: document.getElementById('search-delay-min-display'),
        searchDelayMaxDisplay: document.getElementById('search-delay-max-display'),
        commentDelayMin: document.getElementById('comment-delay-min'),
        commentDelayMax: document.getElementById('comment-delay-max'),
        commentDelayMinDisplay: document.getElementById('comment-delay-min-display'),
        commentDelayMaxDisplay: document.getElementById('comment-delay-max-display'),

        // Human simulation features
        humanMouseMovement: document.getElementById('human-mouse-movement'),
        humanScrolling: document.getElementById('human-scrolling'),
        humanReadingPause: document.getElementById('human-reading-pause'),

        // Daily limits display and inputs
        limitComments: document.getElementById('limit-comments'),
        limitLikes: document.getElementById('limit-likes'),
        limitShares: document.getElementById('limit-shares'),
        limitFollows: document.getElementById('limit-follows'),
        dailyCommentLimitInput: document.getElementById('daily-comment-limit-input'),
        dailyLikeLimitInput: document.getElementById('daily-like-limit-input'),
        dailyShareLimitInput: document.getElementById('daily-share-limit-input'),
        dailyFollowLimitInput: document.getElementById('daily-follow-limit-input'),

        // Analytics
        analyticsPeriod: document.getElementById('analytics-period'),
        refreshAnalytics: document.getElementById('refresh-analytics'),
        totalComments: document.getElementById('total-comments'),
        totalLikes: document.getElementById('total-likes'),
        totalShares: document.getElementById('total-shares'),
        totalPosts: document.getElementById('total-posts'),
        topHashtags: document.getElementById('top-hashtags'),
        topUsers: document.getElementById('top-users'),
        exportStats: document.getElementById('export-stats'),
        clearStats: document.getElementById('clear-stats'),

        // Content
        savedCount: document.getElementById('saved-count'),
        savedPostsList: document.getElementById('saved-posts-list'),
        newKeyword: document.getElementById('new-keyword'),
        addKeyword: document.getElementById('add-keyword'),
        keywordList: document.getElementById('keyword-list'),
        competitorUrl: document.getElementById('competitor-url'),
        addCompetitor: document.getElementById('add-competitor'),
        competitorList: document.getElementById('competitor-list'),

        // Settings
        commentGoal: document.getElementById('comment-goal'),
        commentTone: document.getElementById('comment-tone'),
        userExpertise: document.getElementById('user-expertise'),
        userBackground: document.getElementById('user-background'),
        useCheapModel: document.getElementById('use-cheap-model'),
        dailyCommentLimit: document.getElementById('daily-comment-limit'),
        dailyLikeLimit: document.getElementById('daily-like-limit'),
        respectBlacklist: document.getElementById('respect-blacklist'),
        prioritizeWhitelist: document.getElementById('prioritize-whitelist'),
        accountStatus: document.getElementById('account-status'),
        accountPlan: document.getElementById('account-plan'),
        accountEmail: document.getElementById('account-email'),
        headerPlanName: document.getElementById('header-plan-name'),

        // Authentication elements
        loginBtn: document.getElementById('login-btn'),
        logoutBtn: document.getElementById('logout-btn'),
        loginSection: document.getElementById('login-section'),
        logoutSection: document.getElementById('logout-section'),
        upgradePlanBtn: document.getElementById('upgrade-plan-btn'),

        // Plan limit elements
        planLimitComments: document.getElementById('plan-limit-comments'),
        planLimitLikes: document.getElementById('plan-limit-likes'),
        planLimitShares: document.getElementById('plan-limit-shares'),
        planLimitFollows: document.getElementById('plan-limit-follows'),
        planLimitConnections: document.getElementById('plan-limit-connections'),
        planLimitAiPosts: document.getElementById('plan-limit-ai-posts'),
        planLimitAiComments: document.getElementById('plan-limit-ai-comments'),
        planLimitAiTopics: document.getElementById('plan-limit-ai-topics'),

        // Plan modal elements
        planModal: document.getElementById('plan-modal'),
        closePlanModal: document.getElementById('close-plan-modal'),
        plansLoading: document.getElementById('plans-loading'),
        plansError: document.getElementById('plans-error'),
        plansContainer: document.getElementById('plans-container'),
        retryPlans: document.getElementById('retry-plans'),

        exportData: document.getElementById('export-data'),
        importData: document.getElementById('import-data'),
        importFile: document.getElementById('import-file'),

        // Import Tab Elements
        profileUrlsInput: document.getElementById('profile-urls-input'),
        importExtractContactInfo: document.getElementById('extract-contact-info'),
        enableLikes: document.getElementById('enable-likes'),
        enableComments: document.getElementById('enable-comments'),
        enableShares: document.getElementById('enable-shares'),
        enableFollows: document.getElementById('enable-follows'),
        enableRandomMode: document.getElementById('enable-random-mode'),
        postsPerProfile: document.getElementById('posts-per-profile'),
        combinedSendConnections: document.getElementById('combined-send-connections'),
        combinedExtractContactInfo: document.getElementById('combined-extract-contact-info'),
        combinedEnableLikes: document.getElementById('combined-enable-likes'),
        combinedEnableComments: document.getElementById('combined-enable-comments'),
        combinedEnableShares: document.getElementById('combined-enable-shares'),
        combinedEnableFollows: document.getElementById('combined-enable-follows'),
        combinedEnableRandomMode: document.getElementById('combined-enable-random-mode'),
        combinedPostsPerProfile: document.getElementById('combined-posts-per-profile'),

        // Automation Tab - Comment Settings
        commentLength: document.getElementById('comment-length'),
        aiAutoPost: document.getElementById('ai-auto-post'),
        openInWindow: document.getElementById('open-in-window'),
        bulkLikeOrComment: document.getElementById('bulk-like-or-comment'),

        // Limits Tab - Starting Delays
        automationStartDelay: document.getElementById('automation-start-delay'),
        networkingStartDelay: document.getElementById('networking-start-delay'),
        importStartDelay: document.getElementById('import-profiles-delay'),
        postWriterPageLoadDelay: document.getElementById('post-writer-page-load-delay'),
        postWriterClickDelay: document.getElementById('post-writer-click-delay'),
        postWriterTypingDelay: document.getElementById('post-writer-typing-delay'),
        postWriterSubmitDelay: document.getElementById('post-writer-submit-delay'),

        // Limits Tab - Post Action Delays
        beforeOpeningPostsDelay: document.getElementById('before-opening-posts-delay'),
        postPageLoadDelay: document.getElementById('post-page-load-delay'),
        beforeLikeDelay: document.getElementById('before-like-delay'),
        beforeCommentDelay: document.getElementById('before-comment-delay'),
        beforeShareDelay: document.getElementById('before-share-delay'),
        beforeFollowDelay: document.getElementById('before-follow-delay'),

        // Limits Tab - Networking Delays
        networkingDelayMin: document.getElementById('networking-delay-min'),
        networkingDelayMax: document.getElementById('networking-delay-max'),

        accordions: document.querySelectorAll('.accordion-header')
    });
}

async function initializeUI() {
    try {
        initializeElements();
        
        // CRITICAL: Always set up control buttons (Start/Stop) first
        setupCriticalControlListeners();
        
        // Set up dashboard stop buttons
        setupDashboardStopButtons();
        
        // Check if automation is running BEFORE setting up other event listeners
        const automationState = await chrome.storage.local.get(['bulkProcessingActive', 'peopleSearchActive']);
        const isAutomationRunning = automationState.bulkProcessingActive || automationState.peopleSearchActive;
        
        if (!isAutomationRunning) {
            setupEventListeners();
            console.log('🔧 All event listeners set up (normal mode)');
        } else {
            console.log('⏭️ SKIPPED: Non-critical event listeners (automation is running - lightweight mode)');
            console.log('✅ Control buttons (Start/Stop) remain active');
        }

        const [uiData, prefsData, accountData, statsData, limitsData] = await Promise.all([
            chrome.storage.local.get('ui'),
            chrome.storage.local.get('preferences'),
            chrome.storage.local.get('account'),
            chrome.storage.local.get('engagementStatistics'),
            chrome.storage.local.get('dailyCounts')
        ]);

        state.ui = uiData.ui || { activeTab: 'dashboard' };
        state.preferences = prefsData.preferences || {};
        state.account = accountData.account || {};
        state.statistics = statsData.engagementStatistics || {};
        state.dailyLimits = limitsData.dailyCounts || { likes: 0, comments: 0, shares: 0, follows: 0 };

        await renderUI();
        
        // Set up import progress listener EARLY so we can receive messages even when on other tabs
        setupImportProgressListener();
        
        console.log('🚀 Loading with intelligent caching...');
        
        // Try to load from cache first (INSTANT)
        const cachedDashboard = await getCachedData('dashboard');
        const cachedLimits = await getCachedData('limits');
        const cachedKeywords = await getCachedData('keywords');
        
        if (cachedDashboard) {
            // Use cached data immediately
            console.log('\u26a1 Using cached dashboard data');
            // Populate dashboard with cached data
            state.statistics = cachedDashboard.statistics || {};
            state.dailyLimits = cachedDashboard.dailyLimits || {};
        }
        
        // Critical: Load essential data (from cache or fresh)
        loadDashboard().then(data => {
            // Cache fresh data for next time
            setCachedData('dashboard', {
                statistics: state.statistics,
                dailyLimits: state.dailyLimits,
                timestamp: Date.now()
            });
        });
        
        loadDailyLimits();
        loadSavedKeywords();
        await loadAllFormValues();
        
        // Initialize comment settings (load saved values and set up auto-save listeners)
        initCommentSettings();
        updateSliderDisplays();
        
        // Initialize inspiration sources for post writer
        initializeInspirationSources();
        
        // Defer non-critical operations
        setTimeout(async () => {
            checkDailyPostStatus();
            
            // Skip business hours update if automation is running
            const automationState = await chrome.storage.local.get(['bulkProcessingActive', 'peopleSearchActive']);
            if (!automationState.bulkProcessingActive && !automationState.peopleSearchActive) {
                updateBusinessHoursStatus();
            } else {
                console.log('⏭️ SKIPPED: Business hours status (automation is running)');
            }
            
            // Load analytics with cache
            const cachedAnalytics = await getCachedData('analytics');
            if (cachedAnalytics) {
                console.log('\u26a1 Using cached analytics');
                // Use cached analytics if available
            }
            loadAnalytics().then(() => {
                setCachedData('analytics', { timestamp: Date.now() });
            });
            
            loadProgressAnalytics();
            updateSystemStatus();
            checkBulkProcessingState();
            checkPeopleSearchState();
            checkImportAutomationState();
        }, 100);
        
        // Defer heavy operations even more
        setTimeout(async () => {
            // Check automation state before loading leads
            const automationCheck = await chrome.storage.local.get(['bulkProcessingActive', 'peopleSearchActive']);
            const isAutomating = automationCheck.bulkProcessingActive || automationCheck.peopleSearchActive;
            
            if (!isAutomating) {
                // Load leads with cache
                const cachedLeads = await getCachedData('leads');
                if (!cachedLeads) {
                    loadLeads().then(() => {
                        setCachedData('leads', { timestamp: Date.now() });
                    });
                } else {
                    console.log('⚡ Skipping leads load (cached)');
                }
            } else {
                console.log('⏭️ SKIPPED: loadLeads (automation is running)');
            }
            
            // Only load scheduler status if automation is not running
            chrome.storage.local.get(['bulkProcessingActive', 'peopleSearchActive'], (state) => {
                const isAutomating = state.bulkProcessingActive || state.peopleSearchActive;
                if (!isAutomating) {
                    loadBulkSchedulerStatus();
                    loadPeopleSchedulerStatus();
                } else {
                    console.log('⏭️ SKIPPED: Scheduler status loads (automation is running)');
                }
            });
            
            loadDrafts();
        }, 500);
        
        // Load scheduled posts IMMEDIATELY (no delay) for instant display
        loadScheduledPosts();

        // Start live progress monitoring
        startProgressMonitoring$1();

        // Note: Progress tab initializes lazily when first clicked

        // Update system status every 2 minutes (reduced for performance)
        setInterval(() => {
            updateSystemStatus();
        }, 120000);

        // Check database status
        checkDatabaseStatus();
        
        // Initialize enhanced dashboard progress monitoring
        initializeDashboardProgress();
        
        // Initialize processing history tracking
        initializeProcessingHistory();
        
        // Initialize character counter for post writer
        initializeCharacterCounter();
        
        // Initialize tab switching (import will be initialized when tab is clicked)
        initializeTabSwitching();
        
        // Initialize walkthrough for new users
        initializeWalkthrough();
        
        // Initialize status logger for tab status updates
        initializeStatusLogger();
        
        // Initialize version checker UI and check for updates
        initializeVersionChecker();

        // Ping heartbeat to signal extension is connected to the website
        pingHeartbeat();
        setInterval(() => pingHeartbeat(), 15 * 1000); // Ping every 15 seconds to prevent disconnection

    } catch (e) {
        console.error("Error loading state:", e);
    }
}

// Send heartbeat ping to the backend so the website dashboard shows extension as connected
async function pingHeartbeat() {
    try {
        const storage = await chrome.storage.local.get(['authToken', 'apiBaseUrl']);
        const token = storage.authToken;
        if (!token) return;
        const apiUrl = storage.apiBaseUrl || 'https://kommentify.com';
        await fetch(`${apiUrl}/api/extension/heartbeat`, {
            method: 'POST',
            headers: { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json' },
            body: JSON.stringify({ ts: Date.now() }),
        });
    } catch (e) {
        // Silent - non-critical
    }
}

// --- VERSION CHECKER UI --- //
async function initializeVersionChecker() {
    try {
        // Get current version from manifest and display in header
        const manifest = chrome.runtime.getManifest();
        const currentVersion = manifest.version;
        
        const headerVersion = document.getElementById('header-version');
        if (headerVersion) {
            headerVersion.textContent = `v${currentVersion}`;
        }
        
        const currentVersionDisplay = document.getElementById('current-version-display');
        if (currentVersionDisplay) {
            currentVersionDisplay.textContent = `v${currentVersion}`;
        }
        
        // Check for stored update info
        const response = await chrome.runtime.sendMessage({ action: 'getStoredUpdateInfo' });
        if (response && response.success) {
            updateVersionUI(response.updateInfo, response.lastCheck, response.currentVersion);
        }
        
        // Set up check updates button
        const checkUpdatesBtn = document.getElementById('check-updates-btn');
        if (checkUpdatesBtn) {
            checkUpdatesBtn.addEventListener('click', async () => {
                checkUpdatesBtn.disabled = true;
                checkUpdatesBtn.innerHTML = '<span class="icon icon-refresh" style="animation: spin 1s linear infinite;"></span> Checking...';
                
                try {
                    const result = await chrome.runtime.sendMessage({ action: 'checkForUpdates' });
                    if (result && result.success) {
                        updateVersionUI(result.hasUpdate ? {
                            hasUpdate: true,
                            latestVersion: result.latestVersion,
                            downloadUrl: result.downloadUrl,
                            features: result.features,
                            bugFixes: result.bugFixes
                        } : null, Date.now(), result.currentVersion);
                        
                        if (!result.hasUpdate) {
                            showToast('✅ You have the latest version!', 'success');
                        }
                    }
                } catch (error) {
                    console.error('Error checking for updates:', error);
                    showToast('❌ Failed to check for updates', 'error');
                } finally {
                    checkUpdatesBtn.disabled = false;
                    checkUpdatesBtn.innerHTML = '<span class="icon icon-refresh"></span> Check for Updates';
                }
            });
        }
        
        // Set up download update button
        const downloadUpdateBtn = document.getElementById('download-update-btn');
        if (downloadUpdateBtn) {
            downloadUpdateBtn.addEventListener('click', async () => {
                const response = await chrome.runtime.sendMessage({ action: 'getStoredUpdateInfo' });
                if (response && response.updateInfo && response.updateInfo.downloadUrl) {
                    chrome.runtime.sendMessage({ action: 'openDownloadPage', downloadUrl: response.updateInfo.downloadUrl });
                } else {
                    chrome.runtime.sendMessage({ action: 'openDownloadPage' });
                }
            });
        }
        
        // Set up header update badge click
        const headerUpdateBadge = document.getElementById('header-update-badge');
        if (headerUpdateBadge) {
            headerUpdateBadge.addEventListener('click', async () => {
                const response = await chrome.runtime.sendMessage({ action: 'getStoredUpdateInfo' });
                if (response && response.updateInfo && response.updateInfo.downloadUrl) {
                    chrome.runtime.sendMessage({ action: 'openDownloadPage', downloadUrl: response.updateInfo.downloadUrl });
                } else {
                    chrome.runtime.sendMessage({ action: 'openDownloadPage' });
                }
            });
        }
        
        // Set up Connect to Dashboard button
        const connectDashboardBtn = document.getElementById('connect-to-dashboard-btn');
        if (connectDashboardBtn) {
            connectDashboardBtn.addEventListener('click', async () => {
                const originalText = connectDashboardBtn.innerHTML;
                connectDashboardBtn.innerHTML = '⏳ Connecting...';
                connectDashboardBtn.style.opacity = '0.7';
                connectDashboardBtn.disabled = true;
                try {
                    await pingHeartbeat();
                    connectDashboardBtn.innerHTML = '✓ Connected!';
                    connectDashboardBtn.style.background = 'rgba(16,185,129,0.35)';
                    connectDashboardBtn.style.borderColor = 'rgba(16,185,129,0.6)';
                    setTimeout(() => {
                        chrome.tabs.create({ url: 'https://kommentify.com/dashboard' });
                    }, 600);
                    setTimeout(() => {
                        connectDashboardBtn.innerHTML = originalText;
                        connectDashboardBtn.style.background = 'rgba(255,255,255,0.18)';
                        connectDashboardBtn.style.borderColor = 'rgba(255,255,255,0.35)';
                        connectDashboardBtn.style.opacity = '1';
                        connectDashboardBtn.disabled = false;
                    }, 2500);
                } catch {
                    connectDashboardBtn.innerHTML = originalText;
                    connectDashboardBtn.style.opacity = '1';
                    connectDashboardBtn.disabled = false;
                    chrome.tabs.create({ url: 'https://kommentify.com/dashboard' });
                }
            });
            connectDashboardBtn.addEventListener('mouseenter', () => {
                if (!connectDashboardBtn.disabled) connectDashboardBtn.style.background = 'rgba(255,255,255,0.28)';
            });
            connectDashboardBtn.addEventListener('mouseleave', () => {
                if (!connectDashboardBtn.disabled) connectDashboardBtn.style.background = 'rgba(255,255,255,0.18)';
            });
        }

        console.log('VERSION CHECKER UI: Initialized');
    } catch (error) {
        console.error('VERSION CHECKER UI: Error initializing:', error);
    }
}

function updateVersionUI(updateInfo, lastCheck, currentVersion) {
    const headerUpdateBadge = document.getElementById('header-update-badge');
    const versionStatusBadge = document.getElementById('version-status-badge');
    const lastCheckTime = document.getElementById('last-check-time');
    const updateAvailableSection = document.getElementById('update-available-section');
    const newVersionNumber = document.getElementById('new-version-number');
    const newFeaturesUl = document.getElementById('new-features-ul');
    
    // Update last check time
    if (lastCheckTime && lastCheck) {
        const checkDate = new Date(lastCheck);
        lastCheckTime.textContent = `Last checked: ${checkDate.toLocaleString()}`;
    }
    
    if (updateInfo && updateInfo.hasUpdate) {
        // Show update available UI
        if (headerUpdateBadge) {
            headerUpdateBadge.style.display = 'block';
        }
        
        if (versionStatusBadge) {
            versionStatusBadge.textContent = '🚀 Update Available';
            versionStatusBadge.style.background = 'rgba(245, 158, 11, 0.3)';
        }
        
        if (updateAvailableSection) {
            updateAvailableSection.style.display = 'block';
        }
        
        if (newVersionNumber) {
            newVersionNumber.textContent = `v${updateInfo.latestVersion}`;
        }
        
        // Populate features list
        if (newFeaturesUl) {
            newFeaturesUl.innerHTML = '';
            const allItems = [...(updateInfo.features || []), ...(updateInfo.bugFixes || [])];
            if (allItems.length > 0) {
                allItems.slice(0, 5).forEach(item => {
                    const li = document.createElement('li');
                    li.textContent = item;
                    newFeaturesUl.appendChild(li);
                });
                if (allItems.length > 5) {
                    const li = document.createElement('li');
                    li.textContent = `...and ${allItems.length - 5} more improvements`;
                    li.style.fontStyle = 'italic';
                    newFeaturesUl.appendChild(li);
                }
            } else {
                const li = document.createElement('li');
                li.textContent = 'Various improvements and bug fixes';
                newFeaturesUl.appendChild(li);
            }
        }
    } else {
        // No update available - show up to date UI
        if (headerUpdateBadge) {
            headerUpdateBadge.style.display = 'none';
        }
        
        if (versionStatusBadge) {
            versionStatusBadge.textContent = '✓ Up to date';
            versionStatusBadge.style.background = 'rgba(255,255,255,0.2)';
        }
        
        if (updateAvailableSection) {
            updateAvailableSection.style.display = 'none';
        }
    }
}

// --- UI RENDER FUNCTIONS --- //
async function renderUI() {
    // Master Switch
    if (elements.masterSwitch) {
        elements.masterSwitch.checked = state.ui.enabled !== false;
    }

    // Tabs
    const activeTab = state.ui.activeTab || 'dashboard';
    elements.tabs?.forEach(tab => {
        tab.classList.toggle('active', tab.dataset.tab === activeTab);
    });
    elements.tabContents?.forEach(content => {
        content.classList.toggle('active', content.id === `${activeTab}-content`);
    });

    // Preferences
    if (elements.commentTone) elements.commentTone.value = state.preferences.commentTone || 'Polite';
    if (elements.commentLength) elements.commentLength.value = state.preferences.commentLength || 'Brief';
    if (elements.useCheapModel) elements.useCheapModel.checked = state.preferences.useCheapModel || false;

    // Automation
    if (elements.autoQuota) elements.autoQuota.value = state.preferences.automationQuota || 25;
    if (elements.autoPostAge) elements.autoPostAge.value = state.preferences.automationPostAge || 'OneWeek';

    // Account Info & Authentication
    console.log('=== CALLING UPDATE AUTHENTICATION UI ===');
    await updateAuthenticationUI();
}

// Switch tab function
async function switchTab(tabId) {
    const newActiveTab = tabId;

    // Check feature permission for Import tab
    if (newActiveTab === 'import') {
        const canUseImport = await featureChecker.checkFeature('importProfiles');
        if (!canUseImport) {
            console.warn('🚫 Import tab access denied - feature not available in current plan');
            showNotification('⬆️ Import Profiles Auto Engagement requires a paid plan. Please upgrade!', 'warning');
            
            // Show plan modal for upgrade
            const planModal = document.getElementById('plan-modal');
            if (planModal) {
                planModal.style.display = 'flex';
                loadPlans();
            }
            
            // Don't switch to Import tab - stay on current tab
            return;
        }
    }
    
    // Check feature permission for Automation tab
    if (newActiveTab === 'automation') {
        const canUseAutomation = await featureChecker.checkFeature('autoLike');
        if (!canUseAutomation) {
            console.warn('🚫 Automation tab access denied - General Automation feature not available in current plan');
            showNotification('⬆️ General Automation requires a paid plan. Please upgrade to use bulk processing!', 'warning');
            
            // Show plan modal for upgrade
            const planModal = document.getElementById('plan-modal');
            if (planModal) {
                planModal.style.display = 'flex';
                loadPlans();
            }
            
            // Don't switch to Automation tab - stay on current tab
            return;
        }
    }

    // Update tab buttons - query DOM directly to ensure all tabs are found
    const allTabButtons = document.querySelectorAll('.tab-button');
    console.log(`🔍 Found ${allTabButtons.length} tab buttons`);
    allTabButtons.forEach(t => {
        t.classList.remove('active');
        if (t.getAttribute('data-tab') === newActiveTab) {
            t.classList.add('active');
            console.log(`✅ Activated tab button: ${newActiveTab}`);
        }
    });

    // Update tab contents - use direct style manipulation for reliability
    const allTabContents = document.querySelectorAll('.tab-content');
    console.log(`🔍 Found ${allTabContents.length} tab contents`);
    let foundContent = false;
    allTabContents.forEach(content => {
        const contentTabId = content.id.replace('-content', '');
        if (contentTabId === newActiveTab) {
            content.classList.add('active');
            content.style.display = 'block';
            foundContent = true;
            console.log(`👁️ SHOWING content: ${content.id}`);
        } else {
            content.classList.remove('active');
            content.style.display = 'none';
        }
    });
    
    if (!foundContent) {
        console.error(`❌ Could not find tab content for: ${newActiveTab}-content`);
    }
    
    console.log(`📑 Switched to tab: ${newActiveTab}`);

    state.ui.activeTab = newActiveTab;
    chrome.storage.local.set({ ui: state.ui });

    // Load data for specific tabs
    if (newActiveTab === 'dashboard') {
        loadDashboard();
        loadAnalytics();
        loadProgressAnalytics();
    }
    if (newActiveTab === 'analytics') {
        loadAnalytics();
        loadProgressAnalytics();
        loadLeads();
        loadAutomationHistory();
        loadNetworkingHistory();
    }
    if (newActiveTab === 'post-writer') loadDrafts();
    if (newActiveTab === 'limits') {
        loadLimitsSettings();
        // Plan validation disabled - users manage limits directly in Limits tab
        // setTimeout(() => {
        //     setupPlanLimitValidation();
        // }, 100);
    }
    if (newActiveTab === 'content') {
        loadSavedPosts();
        loadScheduledPosts();
        loadKeywordAlerts();
        loadCompetitors();
    }
    if (newActiveTab === 'import') {
        console.log('📥 TAB SWITCH: Initializing Import tab...');
        initializeImport();
    }
}

/**
 * CRITICAL: Setup control buttons that must ALWAYS work (Start/Stop)
 * These are set up regardless of automation state
 */
function setupCriticalControlListeners() {
    console.log('🎮 Setting up critical control listeners (Start/Stop buttons, tabs, accordions)...');
    
    // Tabs - MUST work during automation
    elements.tabs?.forEach(tab => {
        tab.addEventListener('click', (event) => {
            switchTab(event.currentTarget.dataset.tab);
        });
    });
    
    // Accordions - MUST work during automation
    elements.accordions?.forEach(header => {
        header.addEventListener('click', () => {
            const contentId = `${header.dataset.accordion}-content`;
            const content = document.getElementById(contentId);

            if (content) {
                content.style.display = ''; // Clear inline display style
                content.classList.toggle('open');
                header.querySelector('.arrow')?.classList.toggle('up');
            }
        });
    });
    
    // Automation Start/Stop
    elements.startBulkProcessing?.addEventListener('click', startBulkProcessing);
    elements.stopBulkProcessing?.addEventListener('click', stopBulkProcessing);
    // Bottom buttons for Automation (duplicate buttons at bottom of page)
    elements.startBulkProcessingBottom?.addEventListener('click', startBulkProcessing);
    elements.stopBulkProcessingBottom?.addEventListener('click', stopBulkProcessing);
    
    // Networking Start/Stop
    elements.startPeopleSearch?.addEventListener('click', startPeopleSearchAutomation);
    elements.stopPeopleSearch?.addEventListener('click', stopPeopleSearchAutomation);
    // Bottom buttons for Networking (duplicate buttons at bottom of page)
    elements.startPeopleSearchBottom?.addEventListener('click', startPeopleSearchAutomation);
    elements.stopPeopleSearchBottom?.addEventListener('click', stopPeopleSearchAutomation);
    
    console.log('✅ Critical control listeners ready (tabs, accordions, Start/Stop)');
}

function setupEventListeners() {
    console.log('🔧 Setting up event listeners...');

    // Tabs and Accordions are now in setupCriticalControlListeners
    
    // Dashboard quick actions - use direct DOM manipulation for reliability
    elements.quickPostWriter?.addEventListener('click', () => {
        console.log('🚀 Quick Action: AI Writer');
        switchTab('post-writer');
    });
    elements.quickAutomation?.addEventListener('click', () => {
        console.log('🚀 Quick Action: Automation');
        switchTab('automation');
    });
    elements.quickNetworking?.addEventListener('click', () => {
        console.log('🚀 Quick Action: Networking');
        switchTab('networking');
    });
    elements.quickContent?.addEventListener('click', () => {
        console.log('🚀 Quick Action: Content');
        switchTab('content');
    });
    elements.quickImport?.addEventListener('click', () => {
        console.log('🚀 Quick Action: Import');
        switchTab('import');
    });

    // Post Writer
    elements.generateTopicLines?.addEventListener('click', generateTopicLines);
    elements.generatePost?.addEventListener('click', generatePost);
    elements.analyzePost?.addEventListener('click', analyzePost);
    elements.copyPost?.addEventListener('click', copyPost);
    elements.saveDraft?.addEventListener('click', saveDraft);
    elements.schedulePost?.addEventListener('click', schedulePost);
    elements.postToLinkedIn?.addEventListener('click', postToLinkedIn);

    // Post Writer inputs with auto-save
    elements.postTemplate?.addEventListener('change', saveAllFormValues);
    elements.postTone?.addEventListener('change', saveAllFormValues);
    elements.postLength?.addEventListener('change', saveAllFormValues);
    elements.postIncludeHashtags?.addEventListener('change', saveAllFormValues);
    elements.postIncludeEmojis?.addEventListener('change', saveAllFormValues);

    // Post Writer tab switching (Drafts/Calendar)
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const targetTab = this.getAttribute('data-tab');
            
            // Update active state
            document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            
            // Show/hide content
            if (targetTab === 'drafts') {
                document.getElementById('drafts-tab-content').style.display = 'block';
                document.getElementById('calendar-tab-content').style.display = 'none';
            } else if (targetTab === 'calendar') {
                document.getElementById('drafts-tab-content').style.display = 'none';
                document.getElementById('calendar-tab-content').style.display = 'block';
            }
        });
    });

    // Character counter for post content
    const postContentTextarea = document.getElementById('post-content');
    const charCountDisplay = document.getElementById('char-count');
    if (postContentTextarea && charCountDisplay) {
        postContentTextarea.addEventListener('input', function() {
            const length = this.value.length;
            const maxLength = 3000;
            charCountDisplay.textContent = `${length.toLocaleString()} / ${maxLength.toLocaleString()} characters`;
            
            // Change color if approaching limit
            if (length > maxLength * 0.9) {
                charCountDisplay.style.color = '#dc3545';
                charCountDisplay.style.fontWeight = '600';
            } else if (length > maxLength * 0.75) {
                charCountDisplay.style.color = '#ff9800';
                charCountDisplay.style.fontWeight = '600';
            } else {
                charCountDisplay.style.color = '#999';
                charCountDisplay.style.fontWeight = 'normal';
            }
        });
    }

    // Automation (Start/Stop already set up in setupCriticalControlListeners)
    elements.startPageAutopilot?.addEventListener('click', startAutomationFromPage);
    elements.startAutoLike?.addEventListener('click', () => startAdvancedAutomation('like'));
    elements.startAutoShare?.addEventListener('click', () => startAdvancedAutomation('share'));
    elements.startAutoFollow?.addEventListener('click', () => startAdvancedAutomation('follow'));

    // AI Keyword Generation
    elements.generateKeywords?.addEventListener('click', generateKeywords);
    elements.clearKeywords?.addEventListener('click', clearKeywords);
    elements.keywordCountSlider?.addEventListener('input', () => {
        updateKeywordCountDisplay();
        saveAllFormValues();
    });
    elements.bulkUrls?.addEventListener('input', () => {
        onKeywordsChange();
        saveAllFormValues();
    });

    // Action checkboxes with auto-save
    elements.bulkLike?.addEventListener('change', saveAllFormValues);
    elements.bulkComment?.addEventListener('change', saveAllFormValues);
    elements.bulkShare?.addEventListener('change', saveAllFormValues);
    elements.bulkFollow?.addEventListener('change', saveAllFormValues);
    elements.bulkQuota?.addEventListener('change', saveAllFormValues);
    elements.bulkMinLikes?.addEventListener('change', saveAllFormValues);
    elements.bulkMinComments?.addEventListener('change', saveAllFormValues);
    elements.accountType?.addEventListener('change', saveAllFormValues);
    elements.commentDelay?.addEventListener('change', saveAllFormValues);

    // Slider input events for real-time display updates
    elements.bulkQuota?.addEventListener('input', updateSliderDisplays);
    elements.bulkMinLikes?.addEventListener('input', updateSliderDisplays);
    elements.bulkMinComments?.addEventListener('input', updateSliderDisplays);

    // Networking (Start/Stop already set up in setupCriticalControlListeners)
    // Networking inputs with auto-save
    elements.searchKeyword?.addEventListener('change', saveAllFormValues);
    elements.connectQuota?.addEventListener('change', saveAllFormValues);
    elements.useBooleanSearch?.addEventListener('change', saveAllFormValues);
    elements.filterNetwork?.addEventListener('change', saveAllFormValues);
    elements.sendWithNote?.addEventListener('change', saveAllFormValues);
    elements.sendConnectionRequest?.addEventListener('change', saveAllFormValues);
    elements.extractContactInfo?.addEventListener('change', saveAllFormValues);
    elements.excludeHeadlineTerms?.addEventListener('change', saveAllFormValues);
    elements.connectionMessage?.addEventListener('change', saveAllFormValues);

    // All slider input events for real-time display updates
    elements.connectQuota?.addEventListener('input', updateSliderDisplays);
    
    // Daily limits sliders
    elements.dailyCommentLimitInput?.addEventListener('input', updateSliderDisplays);
    elements.dailyLikeLimitInput?.addEventListener('input', updateSliderDisplays);
    elements.dailyShareLimitInput?.addEventListener('input', updateSliderDisplays);
    elements.dailyFollowLimitInput?.addEventListener('input', updateSliderDisplays);
    
    // Start delay sliders  
    elements.automationStartDelay?.addEventListener('input', updateSliderDisplays);
    elements.networkingStartDelay?.addEventListener('input', updateSliderDisplays);
    elements.importStartDelay?.addEventListener('input', updateSliderDisplays);
    
    // Post writer delay sliders
    elements.postWriterPageLoadDelay?.addEventListener('input', updateSliderDisplays);
    elements.postWriterClickDelay?.addEventListener('input', updateSliderDisplays);
    elements.postWriterTypingDelay?.addEventListener('input', updateSliderDisplays);
    elements.postWriterSubmitDelay?.addEventListener('input', updateSliderDisplays);
    
    // Search and automation delay sliders
    elements.searchDelayMin?.addEventListener('input', updateSliderDisplays);
    elements.searchDelayMax?.addEventListener('input', updateSliderDisplays);
    elements.commentDelayMin?.addEventListener('input', updateSliderDisplays);
    elements.commentDelayMax?.addEventListener('input', updateSliderDisplays);
    elements.networkingDelayMin?.addEventListener('input', updateSliderDisplays);
    elements.networkingDelayMax?.addEventListener('input', updateSliderDisplays);
    
    // Post action delay sliders
    elements.beforeOpeningPostsDelay?.addEventListener('input', updateSliderDisplays);
    elements.postPageLoadDelay?.addEventListener('input', updateSliderDisplays);
    elements.beforeLikeDelay?.addEventListener('input', updateSliderDisplays);
    elements.beforeCommentDelay?.addEventListener('input', updateSliderDisplays);
    elements.beforeShareDelay?.addEventListener('input', updateSliderDisplays);
    elements.beforeFollowDelay?.addEventListener('input', updateSliderDisplays);

    // Mutual exclusion for Send with Note and Send Connection Request checkboxes
    elements.sendWithNote?.addEventListener('change', function() {
        if (this.checked && elements.sendConnectionRequest?.checked) {
            elements.sendConnectionRequest.checked = false;
            console.log('UI: Unchecked "Send Connection Request" because "Send with Note" was selected');
            saveAllFormValues(); // Save the change
        }
        if (!this.checked && !elements.sendConnectionRequest?.checked) {
            // If unchecking and the other is also unchecked, default to Send Connection Request
            elements.sendConnectionRequest.checked = true;
            console.log('UI: Auto-checked "Send Connection Request" to prevent both being unchecked');
            saveAllFormValues(); // Save the change
        }
    });

    elements.sendConnectionRequest?.addEventListener('change', function() {
        if (this.checked && elements.sendWithNote?.checked) {
            elements.sendWithNote.checked = false;
            console.log('UI: Unchecked "Send with Note" because "Send Connection Request" was selected');
            saveAllFormValues(); // Save the change
        }
        if (!this.checked && !elements.sendWithNote?.checked) {
            // If unchecking and the other is also unchecked, default to Send with Note
            elements.sendWithNote.checked = true;
            console.log('UI: Auto-checked "Send with Note" to prevent both being unchecked');
            saveAllFormValues(); // Save the change
        }
    });

    // Plan limit enforcement for daily limits inputs - DISABLED (users manage limits directly)
    // setupPlanLimitValidation();

    // Schedulers
    elements.addBulkSchedule?.addEventListener('click', addBulkSchedule);
    elements.addPeopleSchedule?.addEventListener('click', addPeopleSchedule);
    elements.bulkSchedulerEnabled?.addEventListener('change', toggleBulkScheduler);
    elements.peopleSchedulerEnabled?.addEventListener('change', togglePeopleScheduler);

    // Authentication & Plans
    elements.loginBtn?.addEventListener('click', handleLogin);
    elements.logoutBtn?.addEventListener('click', handleLogout);
    elements.upgradePlanBtn?.addEventListener('click', () => {
        console.log('🔥 Upgrade Plan button clicked!');
        if (elements.planModal) {
            elements.planModal.style.display = 'flex';
            console.log('✅ Plan modal opened');
        } else {
            console.error('❌ Plan modal element not found');
        }
        loadPlans();
    });
    elements.closePlanModal?.addEventListener('click', () => {
        if (elements.planModal) elements.planModal.style.display = 'none';
    });
    elements.retryPlans?.addEventListener('click', loadPlans);
    elements.planModal?.addEventListener('click', (e) => {
        if (e.target === elements.planModal) {
            elements.planModal.style.display = 'none';
        }
    });

    // Walkthrough
    document.getElementById('start-walkthrough-btn')?.addEventListener('click', () => {
        console.log('🎓 Starting walkthrough from Settings...');
        resetWalkthrough();
    });

    // Analytics
    elements.refreshAnalytics?.addEventListener('click', loadAnalytics);
    elements.analyticsPeriod?.addEventListener('change', loadAnalytics);
    elements.exportStats?.addEventListener('click', exportStatistics);
    elements.clearStats?.addEventListener('click', clearStatistics);
    
    // Automation History
    document.getElementById('refresh-automation-history')?.addEventListener('click', loadAutomationHistory);
    document.getElementById('export-automation-history')?.addEventListener('click', exportAutomationHistory);
    document.getElementById('clear-automation-history')?.addEventListener('click', clearAutomationHistory);
    document.getElementById('automation-history-filter-status')?.addEventListener('change', loadAutomationHistory);
    document.getElementById('automation-search')?.addEventListener('input', loadAutomationHistory);
    
    // Networking History
    document.getElementById('refresh-networking-history')?.addEventListener('click', loadNetworkingHistory);
    document.getElementById('export-networking-history')?.addEventListener('click', exportNetworkingHistory);
    document.getElementById('clear-networking-history')?.addEventListener('click', clearNetworkingHistory);
    document.getElementById('networking-history-filter-status')?.addEventListener('change', loadNetworkingHistory);
    document.getElementById('networking-search')?.addEventListener('input', loadNetworkingHistory);

    // Leads
    document.getElementById('leads-search')?.addEventListener('input', filterLeads);
    document.getElementById('leads-filter-query')?.addEventListener('change', filterLeads);
    document.getElementById('refresh-leads')?.addEventListener('click', loadLeads);
    document.getElementById('export-leads')?.addEventListener('click', exportLeadsToCSV);
    document.getElementById('show-contact-info')?.addEventListener('change', toggleContactColumns);
    document.getElementById('clear-all-leads')?.addEventListener('click', clearAllLeads);

    // Content
    elements.addKeyword?.addEventListener('click', addKeywordAlert);
    elements.addCompetitor?.addEventListener('click', addCompetitor);
    elements.schedulePostBtn?.addEventListener('click', schedulePost);

    // Settings & Limits
    document.getElementById('save-limits-settings')?.addEventListener('click', saveLimitsSettings);
    elements.testSystems?.addEventListener('click', testAllSystems);

    // Delay sliders
    ['search-delay-min', 'search-delay-max', 'comment-delay-min', 'comment-delay-max',
        'networking-delay-min', 'networking-delay-max',
        'automation-start-delay', 'networking-start-delay',
        'post-writer-page-load-delay', 'post-writer-click-delay', 'post-writer-typing-delay', 'post-writer-submit-delay',
        'before-opening-posts-delay', 'post-page-load-delay', 'before-like-delay', 
        'before-comment-delay', 'before-share-delay', 'before-follow-delay'].forEach(id => {
            const slider = document.getElementById(id);
            if (slider) {
                slider.addEventListener('input', () => updateDelayDisplay(id));
                slider.addEventListener('change', saveLimitsSettings);
            }
        });
    
    // Daily limit sliders
    ['daily-comment-limit-input', 'daily-like-limit-input', 'daily-share-limit-input', 'daily-follow-limit-input'].forEach(id => {
        const slider = document.getElementById(id);
        const displayId = id.replace('-input', '-display');
        if (slider) {
            slider.addEventListener('input', () => {
                const display = document.getElementById(displayId);
                if (display) display.textContent = slider.value;
            });
            slider.addEventListener('change', saveLimitsSettings);
        }
    });

    // Preferences
    const settingsElements = [elements.commentTone, elements.commentLength, elements.useCheapModel, elements.autoQuota, elements.autoPostAge];
    settingsElements.forEach(el => {
        el?.addEventListener('change', savePreferences);
    });

    // Business Hours
    elements.businessHoursEnabled?.addEventListener('change', () => {
        updateBusinessHours();
        saveAllFormValues();
    });
    
    // Daily Schedule - Auto-save
    elements.dailyScheduleEnabled?.addEventListener('change', () => {
        saveDailyScheduleSettings();
    });
    
    // Auto-save on business hours changes
    elements.businessStartHour?.addEventListener('change', saveAllFormValues);
    elements.businessEndHour?.addEventListener('change', saveAllFormValues);
    elements.allowWeekends?.addEventListener('change', saveAllFormValues);
    
    // Missed Post Behavior Setting
    const missedPostBehaviorSelect = document.getElementById('missed-post-behavior');
    if (missedPostBehaviorSelect) {
        // Load saved value
        chrome.storage.local.get('missedPostBehavior').then(result => {
            missedPostBehaviorSelect.value = result.missedPostBehavior || 'wait_manual';
        });
        
        // Save on change
        missedPostBehaviorSelect.addEventListener('change', async function() {
            await chrome.storage.local.set({ missedPostBehavior: this.value });
            console.log('✅ Missed post behavior saved:', this.value);
        });
    }
    
    // Scheduler Logs View Button
    const viewSchedulerLogsBtn = document.getElementById('view-scheduler-logs');
    const schedulerLogsContainer = document.getElementById('scheduler-logs-container');
    if (viewSchedulerLogsBtn && schedulerLogsContainer) {
        viewSchedulerLogsBtn.addEventListener('click', async function() {
            const isVisible = schedulerLogsContainer.style.display !== 'none';
            
            if (isVisible) {
                schedulerLogsContainer.style.display = 'none';
                this.textContent = 'View Logs';
            } else {
                // Fetch logs from background
                try {
                    const response = await chrome.runtime.sendMessage({ action: 'getSchedulerLogs' });
                    if (response && response.success && response.logs) {
                        const logs = response.logs;
                        if (logs.length === 0) {
                            schedulerLogsContainer.innerHTML = '<div style="color: #999;">No scheduler logs yet.</div>';
                        } else {
                            schedulerLogsContainer.innerHTML = logs.map(log => {
                                const color = log.level === 'error' ? '#ff6b6b' : 
                                             log.level === 'warn' ? '#ffc107' : '#00ff00';
                                return `<div style="color: ${color}; margin-bottom: 4px;">[${log.timestamp}] ${log.message}</div>`;
                            }).join('');
                        }
                    }
                } catch (error) {
                    schedulerLogsContainer.innerHTML = `<div style="color: #ff6b6b;">Error loading logs: ${error.message}</div>`;
                }
                
                schedulerLogsContainer.style.display = 'block';
                this.textContent = 'Hide Logs';
            }
        });
    }

    // --- Post Writer Tab Auto-save ---
    elements.postTopic?.addEventListener('change', saveAllFormValues);
    elements.postTopic?.addEventListener('input', saveAllFormValues);
    elements.postTemplate?.addEventListener('change', saveAllFormValues);
    elements.postTone?.addEventListener('change', saveAllFormValues);
    elements.postLength?.addEventListener('change', saveAllFormValues);
    elements.postIncludeHashtags?.addEventListener('change', saveAllFormValues);
    elements.postIncludeEmojis?.addEventListener('change', saveAllFormValues);
    elements.postContent?.addEventListener('change', saveAllFormValues);
    elements.scheduleDate?.addEventListener('change', saveAllFormValues);
    elements.scheduleTime?.addEventListener('change', saveAllFormValues);

    // --- Automation Tab Comment Settings Auto-save ---
    elements.commentGoal?.addEventListener('change', saveAllFormValues);
    elements.commentTone?.addEventListener('change', saveAllFormValues);
    elements.commentLength?.addEventListener('change', saveAllFormValues);
    elements.userExpertise?.addEventListener('change', saveAllFormValues);
    elements.userExpertise?.addEventListener('input', saveAllFormValues);
    elements.userBackground?.addEventListener('change', saveAllFormValues);
    elements.userBackground?.addEventListener('input', saveAllFormValues);
    elements.aiAutoPost?.addEventListener('change', saveAllFormValues);
    elements.openInWindow?.addEventListener('change', saveAllFormValues);
    elements.keywordIntent?.addEventListener('change', saveAllFormValues);
    elements.keywordIntent?.addEventListener('input', saveAllFormValues);
    elements.bulkLikeOrComment?.addEventListener('change', saveAllFormValues);

    // --- Import Tab Auto-save ---
    elements.profileUrlsInput?.addEventListener('change', saveAllFormValues);
    elements.importExtractContactInfo?.addEventListener('change', saveAllFormValues);
    elements.enableLikes?.addEventListener('change', saveAllFormValues);
    elements.enableComments?.addEventListener('change', saveAllFormValues);
    elements.enableShares?.addEventListener('change', saveAllFormValues);
    elements.enableFollows?.addEventListener('change', saveAllFormValues);
    elements.enableRandomMode?.addEventListener('change', saveAllFormValues);
    elements.postsPerProfile?.addEventListener('change', saveAllFormValues);
    elements.combinedSendConnections?.addEventListener('change', saveAllFormValues);
    elements.combinedExtractContactInfo?.addEventListener('change', saveAllFormValues);
    elements.combinedEnableLikes?.addEventListener('change', saveAllFormValues);
    elements.combinedEnableComments?.addEventListener('change', saveAllFormValues);
    elements.combinedEnableShares?.addEventListener('change', saveAllFormValues);
    elements.combinedEnableFollows?.addEventListener('change', saveAllFormValues);
    elements.combinedEnableRandomMode?.addEventListener('change', saveAllFormValues);
    elements.combinedPostsPerProfile?.addEventListener('change', saveAllFormValues);

    // Character counter for networking connection message
    const connectionMessage = document.getElementById('connection-message');
    const messageCharCount = document.getElementById('message-char-count');
    if (connectionMessage && messageCharCount) {
        connectionMessage.addEventListener('input', () => {
            const length = connectionMessage.value.length;
            messageCharCount.textContent = `${length}/300`;
            if (length > 300) {
                messageCharCount.style.color = '#e74c3c';
            } else {
                messageCharCount.style.color = '#693fe9';
            }
        });
        // Initialize count on load
        const initialLength = connectionMessage.value.length;
        messageCharCount.textContent = `${initialLength}/300`;
    }

    // Account type preset selector
    const accountTypeSelect = document.getElementById('account-type');
    if (accountTypeSelect) {
        accountTypeSelect.addEventListener('change', (e) => {
            applyAccountPreset(e.target.value);
        });
    }

    // Random interval min/max selectors
    const randomIntervalMin = document.getElementById('random-interval-min');
    if (randomIntervalMin) {
        randomIntervalMin.addEventListener('change', () => {
            updateRandomIntervalDisplay('random-interval-min');
            saveLimitsSettings();
        });
    }

    const randomIntervalMax = document.getElementById('random-interval-max');
    if (randomIntervalMax) {
        randomIntervalMax.addEventListener('change', () => {
            updateRandomIntervalDisplay('random-interval-max');
            saveLimitsSettings();
        });
    }

    // Import start delay slider
    const importStartDelaySlider = document.getElementById('import-start-delay');
    if (importStartDelaySlider) {
        importStartDelaySlider.addEventListener('input', () => updateDelayDisplay('import-start-delay'));
        importStartDelaySlider.addEventListener('change', saveLimitsSettings);
    }

    // Post Source Toggle (Commenter tab - Keywords vs Feed)
    const sourceKeywords = document.getElementById('source-keywords');
    const sourceFeed = document.getElementById('source-feed');
    const keywordSection = document.getElementById('keyword-section');
    const sourceKeywordsLabel = document.getElementById('source-keywords-label');
    const sourceFeedLabel = document.getElementById('source-feed-label');
    
    if (sourceKeywords && sourceFeed) {
        const updateSourceUI = () => {
            if (sourceKeywords.checked) {
                if (sourceKeywordsLabel) {
                    sourceKeywordsLabel.style.background = '#f0f8ff';
                    sourceKeywordsLabel.style.borderColor = '#693fe9';
                    sourceKeywordsLabel.querySelector('span').style.color = '#693fe9';
                }
                if (sourceFeedLabel) {
                    sourceFeedLabel.style.background = '#f8f9fa';
                    sourceFeedLabel.style.borderColor = '#e0e0e0';
                    sourceFeedLabel.querySelector('span').style.color = '#666';
                }
                if (keywordSection) keywordSection.style.display = 'block';
            } else {
                if (sourceKeywordsLabel) {
                    sourceKeywordsLabel.style.background = '#f8f9fa';
                    sourceKeywordsLabel.style.borderColor = '#e0e0e0';
                    sourceKeywordsLabel.querySelector('span').style.color = '#666';
                }
                if (sourceFeedLabel) {
                    sourceFeedLabel.style.background = '#f0f8ff';
                    sourceFeedLabel.style.borderColor = '#693fe9';
                    sourceFeedLabel.querySelector('span').style.color = '#693fe9';
                }
                if (keywordSection) keywordSection.style.display = 'none';
            }
            // Save preference
            chrome.storage.local.set({ postSource: sourceKeywords.checked ? 'keywords' : 'feed' });
        };
        
        sourceKeywords.addEventListener('change', updateSourceUI);
        sourceFeed.addEventListener('change', updateSourceUI);
        
        // Load saved preference - default to feed if not set
        chrome.storage.local.get('postSource').then(result => {
            if (result.postSource === 'keywords') {
                sourceKeywords.checked = true;
            } else {
                // Default to feed
                sourceFeed.checked = true;
            }
            updateSourceUI();
        });
    }

    // Network Search Source Toggle (Keyword vs URL)
    const searchByKeyword = document.getElementById('search-by-keyword');
    const searchByUrl = document.getElementById('search-by-url');
    const keywordInputSection = document.getElementById('keyword-input-section');
    const urlInputSection = document.getElementById('url-input-section');
    const searchByUrlLabel = document.getElementById('search-by-url-label');
    
    if (searchByKeyword && searchByUrl) {
        const updateSearchSourceUI = () => {
            const keywordLabel = searchByKeyword.closest('label');
            if (searchByKeyword.checked) {
                if (keywordLabel) {
                    keywordLabel.style.background = '#f0f8ff';
                    keywordLabel.style.borderColor = '#693fe9';
                    keywordLabel.querySelector('span').style.color = '#693fe9';
                }
                if (searchByUrlLabel) {
                    searchByUrlLabel.style.background = '#f8f9fa';
                    searchByUrlLabel.style.borderColor = '#e0e0e0';
                    searchByUrlLabel.querySelector('span').style.color = '#666';
                }
                if (keywordInputSection) keywordInputSection.style.display = 'block';
                if (urlInputSection) urlInputSection.style.display = 'none';
            } else {
                if (keywordLabel) {
                    keywordLabel.style.background = '#f8f9fa';
                    keywordLabel.style.borderColor = '#e0e0e0';
                    keywordLabel.querySelector('span').style.color = '#666';
                }
                if (searchByUrlLabel) {
                    searchByUrlLabel.style.background = '#f0f8ff';
                    searchByUrlLabel.style.borderColor = '#693fe9';
                    searchByUrlLabel.querySelector('span').style.color = '#693fe9';
                }
                if (keywordInputSection) keywordInputSection.style.display = 'none';
                if (urlInputSection) urlInputSection.style.display = 'block';
            }
            // Save preference
            chrome.storage.local.set({ searchSource: searchByKeyword.checked ? 'keyword' : 'url' });
        };
        
        searchByKeyword.addEventListener('change', updateSearchSourceUI);
        searchByUrl.addEventListener('change', updateSearchSourceUI);
        
        // Load saved preference
        chrome.storage.local.get('searchSource').then(result => {
            if (result.searchSource === 'url') {
                searchByUrl.checked = true;
                updateSearchSourceUI();
            }
        });
    }

    console.log('✅ Event listeners setup complete');
}

/**
 * Initialize tab switching functionality
 */
function initializeTabSwitching() {
    console.log('🔧 Initializing tab switching...');
    
    const tabButtons = document.querySelectorAll('.tab-button');
    const tabContents = document.querySelectorAll('.tab-content');
    
    if (tabButtons.length === 0) {
        console.warn('⚠️ No tab buttons found');
        return;
    }
    
    console.log(`📋 Found ${tabButtons.length} tab buttons and ${tabContents.length} tab contents`);
    
    // Add click listeners to tab buttons
    tabButtons.forEach(button => {
        button.addEventListener('click', (e) => {
            e.preventDefault();
            const targetTab = button.getAttribute('data-tab');
            console.log(`🔄 Switching to tab: ${targetTab}`);
            switchToTab(targetTab);
        });
    });
    
    // Show the default tab (dashboard) or the active tab from state
    const activeTab = state.ui?.activeTab || 'dashboard';
    switchToTab(activeTab);
    
    console.log('✅ Tab switching initialized');
}

/**
 * Switch to a specific tab
 */
function switchToTab(tabName) {
    console.log(`🎯 Switching to tab: ${tabName}`);
    
    // Update tab buttons
    const tabButtons = document.querySelectorAll('.tab-button');
    tabButtons.forEach(button => {
        if (button.getAttribute('data-tab') === tabName) {
            button.classList.add('active');
        } else {
            button.classList.remove('active');
        }
    });
    
    // Update tab contents
    const tabContents = document.querySelectorAll('.tab-content');
    tabContents.forEach(content => {
        const contentId = content.id.replace('-content', '');
        if (contentId === tabName) {
            content.style.display = 'block';
            console.log(`👁️ Showing content: ${content.id}`);
        } else {
            content.style.display = 'none';
        }
    });
    
    // Update state
    if (state.ui) {
        state.ui.activeTab = tabName;
        chrome.storage.local.set({ ui: state.ui });
    }
    
    // Load tab-specific data
    loadTabData(tabName);
}

/**
 * Load data for specific tab
 */
function loadTabData(tabName) {
    switch (tabName) {
        case 'dashboard':
            loadDashboard();
            break;
        case 'analytics':
            loadAnalytics();
            break;
        case 'networking':
            // Networking data is loaded on demand
            break;
        case 'import':
            console.log('📥 TAB DATA: Initializing Import tab...');
            initializeImport();
            break;
    }
}

async function initializePopup() {
    console.log('=== INITIALIZING POPUP ===');
    console.log('Chrome storage available:', typeof chrome !== 'undefined' && chrome.storage);

    const startTime = Date.now();
    const minLoadingTime = 1500; // Minimum 1.5 seconds loading
    
    // Update loading status
    updateLoadingStatus('Checking authentication...', 20);

    try {
        // CLEAR ANY OLD TEST DATA FIRST  
        const storage = await chrome.storage.local.get(['authToken']);
        console.log('Initial storage check:', storage);

        if (storage.authToken && storage.authToken.includes('test-signature')) {
            console.log('Clearing old test data');
            await chrome.storage.local.remove(['authToken', 'userData', 'refreshToken']);
        }

        // Check authentication - MANDATORY now
        const authData = await chrome.storage.local.get(['authToken', 'userData', 'apiBaseUrl']);
        console.log('Auth data from storage:', {
            hasToken: !!authData.authToken,
            tokenLength: authData.authToken ? authData.authToken.length : 0,
            hasUserData: !!authData.userData,
            userData: authData.userData,
            apiBaseUrl: authData.apiBaseUrl
        });

        // Also log the full token for debugging (first 50 chars)
        if (authData.authToken) {
            console.log('Token preview:', authData.authToken.substring(0, 50) + '...');
        }

        // Ensure apiBaseUrl is set to production backend
        if (!authData.apiBaseUrl) {
            await chrome.storage.local.set({
                apiBaseUrl: API_CONFIG.BASE_URL
            });
            console.log('Set default API base URL');
        }

        updateLoadingStatus('Validating credentials...', 40);
        // Validate JWT token if exists
        const isValidToken = await validateJWTToken(authData.authToken);
        console.log('Token validation result:', isValidToken);

        // Update global state
        state.isAuthenticated = isValidToken;
        state.userData = authData.userData || {};

        // If not authenticated, show login screen - STRICT ENFORCEMENT
        if (!isValidToken) {
            console.log('User not authenticated, showing login screen');
            showLoginScreen();
            return;
        }

        console.log('User authenticated, loading main UI');
        
        updateLoadingStatus('Loading components...', 60);
        // Initialize the main UI since user is authenticated
        await loadComponents();
        
        updateLoadingStatus('Initializing interface...', 80);
        await initializeUI();
        
        updateLoadingStatus('Almost ready...', 95);
        
        // Ensure minimum loading time
        const elapsedTime = Date.now() - startTime;
        const remainingTime = Math.max(0, minLoadingTime - elapsedTime);
        
        if (remainingTime > 0) {
            await new Promise(resolve => setTimeout(resolve, remainingTime));
        }
        
        updateLoadingStatus('Ready!', 100);
        
        // Hide loading overlay with fade effect
        setTimeout(() => {
            const loadingOverlay = document.getElementById('loading-overlay');
            if (loadingOverlay) {
                loadingOverlay.style.opacity = '0';
                loadingOverlay.style.transition = 'opacity 0.3s ease';
                setTimeout(() => {
                    loadingOverlay.style.display = 'none';
                }, 300);
            }
        }, 200);

    } catch (storageError) {
        console.error('Storage access error:', storageError);
        console.log('Showing login screen due to error');
        showLoginScreen();
        return;
    }
}

async function loadComponents() {
    console.log('Loading HTML components...');
    const components = [
        { id: 'header-container', path: 'components/html/header.html' },
        { id: 'tabs-container', path: 'components/html/tabs.html' },
        { id: 'dashboard-container', path: 'components/html/dashboard.html' },
        { id: 'post-writer-container', path: 'components/html/post_writer.html' },
        { id: 'automation-container', path: 'components/html/automation.html' },
        { id: 'networking-container', path: 'components/html/networking.html' },
        { id: 'import-container', path: 'components/html/import.html' },
        { id: 'analytics-container', path: 'components/html/analytics.html' },
        { id: 'limits-container', path: 'components/html/limits.html' },
        { id: 'settings-container', path: 'components/html/settings.html' },
        { id: 'footer-container', path: 'components/html/footer.html' },
        { id: 'plan-modal-container', path: 'components/html/plan_modal.html' }
    ];

    await Promise.all(components.map(async (component) => {
        try {
            const response = await fetch(chrome.runtime.getURL(component.path));
            const html = await response.text();
            const container = document.getElementById(component.id);
            if (container) {
                container.innerHTML = html;
            } else {
                console.error(`Container not found: ${component.id}`);
            }
        } catch (error) {
            console.error(`Failed to load component: ${component.path}`, error);
        }
    }));
    console.log('All components loaded');
}

// Update loading status and progress
function updateLoadingStatus(status, progress) {
    const statusElement = document.getElementById('loading-status');
    const progressElement = document.getElementById('loading-progress');
    
    if (statusElement) {
        statusElement.textContent = status;
    }
    
    if (progressElement) {
        progressElement.style.width = `${progress}%`;
    }
    
    console.log(`Loading: ${status} (${progress}%)`);
}

// Start initialization when DOM is ready
document.addEventListener('DOMContentLoaded', initializePopup);

export { initializePopup };
