import { clicker } from './clicker.js';
import { DataAttribute } from '../shared/storage/constants.js';
import '../shared/dom/waitUntil.js';
import '../shared/api/api.js';
import '../shared/dom/feedScraper.js';
import '../shared/utils/logger.js';
import '../shared/dom/feedActions.js';
import '../shared/dom/domium.js';
import '../shared/utils/appConfig.js';
import '../shared/storage/storage.js';

class IFrameDetector {
    constructor() {
        this.DETECTION_INTERVAL = 2000; // Check for new iframes every 2 seconds
    }

    /**
     * Starts a recurring interval to detect and register click listeners on new iframes.
     */
    constantlyDetectAndRegisterClicks() {
        setInterval(() => this.detectAndRegister(), this.DETECTION_INTERVAL);
    }

    /**
     * Finds all iframes on the page that haven't been registered yet and adds the click listener.
     */
    detectAndRegister() {
        const iframes = document.querySelectorAll("iframe");
        for (const iframe of iframes) {
            // Skip iframes that are already processed or are internal tools of the extension.
            if (iframe.hasAttribute(DataAttribute.AlreadyRegistered) || iframe.hasAttribute(DataAttribute.DynamicHiddenIFrame)) {
                continue;
            }

            iframe.addEventListener("load", () => {
                try {
                    const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
                    iframeDoc.body.addEventListener("click", clicker.click);
                } catch (error) {
                    // This can fail due to cross-origin policies on some iframes, which is expected.
                }
            });

            iframe.setAttribute(DataAttribute.AlreadyRegistered, "true");
        }
    }
}

const iFrameDetector = new IFrameDetector();

export { iFrameDetector };
