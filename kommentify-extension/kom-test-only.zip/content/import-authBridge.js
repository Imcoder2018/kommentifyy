(function () {

	const importPath = /*@__PURE__*/ JSON.parse('"content/authBridge.js"');

	import(chrome.runtime.getURL(importPath));

})();
