(function () {

	const importPath = /*@__PURE__*/ JSON.parse('"content/bridge.js"');

	import(chrome.runtime.getURL(importPath));

})();
