(function () {

	const importPath = /*@__PURE__*/ JSON.parse('"content/loader.js"');

	import(chrome.runtime.getURL(importPath));

})();
