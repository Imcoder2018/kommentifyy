/**
 * LINKEDIN PEOPLE SEARCH AUTOMATION
 * Automated user acquisition through keyword-driven search
 * Supports Boolean logic, network filtering, pagination, and profile qualification
 */

import { browser } from '/shared/utils/browser.js';
import { storage } from '/shared/storage/storage.background.js';
import { backgroundStatistics } from './statisticsManager.js';
import { randomDelay } from '/shared/utils/helpers.js';

class PeopleSearchAutomation {
    constructor() {
        this.searchState = {
            currentPage: 1,
            lastSearchKeyword: '',
            processedProfiles: [],
            totalConnected: 0
        };
        this.stopFlag = false;
    }
    
    /**
     * Stop the current processing
     */
    async stopProcessing() {
        console.log("PEOPLE SEARCH: Stop signal received");
        this.stopFlag = true;
        
        // Immediately clear processing state
        await chrome.storage.local.set({ 
            peopleSearchActive: false,
            liveProgress: { active: false }
        });
        console.log("PEOPLE SEARCH: State cleared immediately");
        
        return { success: true, message: "Stop signal sent" };
    }

    /**
     * Build Boolean search query from user input
     * Example: "VP of Sales" -> ("VP" OR "Vice President") AND "Sales" NOT "Intern"
     */
    buildBooleanQuery(keyword, options = {}) {
        let query = keyword;

        // Apply title variations for common roles
        const titleVariations = {
            'VP': ['VP', 'Vice President'],
            'CEO': ['CEO', 'Chief Executive Officer'],
            'CTO': ['CTO', 'Chief Technology Officer'],
            'CFO': ['CFO', 'Chief Financial Officer'],
            'Director': ['Director', 'Head of'],
            'Manager': ['Manager', 'Lead']
        };

        // Apply variations if keyword contains known titles
        for (const [short, variations] of Object.entries(titleVariations)) {
            if (keyword.includes(short)) {
                const orClause = variations.map(v => `"${v}"`).join(' OR ');
                query = query.replace(short, `(${orClause})`);
            }
        }

        // Exclude unwanted terms (configurable)
        if (options.excludeTerms && options.excludeTerms.length > 0) {
            const notClause = options.excludeTerms.map(term => `NOT "${term}"`).join(' ');
            query = `${query} ${notClause}`;
        }

        return query;
    }

    /**
     * Construct LinkedIn people search URL with filters
     * @param {string} keyword - Search keyword/query
     * @param {object} options - Search options
     * @returns {string} Complete search URL
     */
    buildPeopleSearchUrl(keyword, options = {}) {
        const baseUrl = 'https://www.linkedin.com/search/results/people/';
        
        // Add keyword
        const query = options.useBooleanLogic 
            ? this.buildBooleanQuery(keyword, options)
            : keyword;
        
        let url = `${baseUrl}?keywords=${encodeURIComponent(query)}`;

        // Network filter: Target 2nd and 3rd degree connections
        // Using exact filter format: &network=%5B"S"%2C"O"%5D
        if (options.filterNetwork !== false) {
            url += '&network=%5B"S"%2C"O"%5D';
        }

        // Location filter (if provided)
        if (options.location) {
            url += `&geoUrn=${encodeURIComponent(options.location)}`;
        }

        // Current company filter (if provided)
        if (options.currentCompany) {
            url += `&currentCompany=${encodeURIComponent('["' + options.currentCompany + '"]')}`;
        }

        // Page number for pagination
        if (options.page && options.page > 1) {
            url += `&page=${options.page}`;
        }

        return url;
    }

    /**
     * Extract profile data from search result card
     * Injected function that runs in page context
     */
    extractProfileFromCard(cardElement) {
        try {
            // Get profile URL
            const linkElement = cardElement.querySelector('a.app-aware-link[href*="/in/"]');
            const profileUrl = linkElement ? linkElement.href : null;

            // Get name
            const nameElement = cardElement.querySelector('.entity-result__title-text a span[aria-hidden="true"]');
            const name = nameElement ? nameElement.textContent.trim() : 'Unknown';

            // Get headline - using updated selector .t-black
            const headlineElement = cardElement.querySelector('.t-black');
            const headline = headlineElement ? headlineElement.textContent.trim() : '';

            // Get location
            const locationElement = cardElement.querySelector('.entity-result__secondary-subtitle');
            const location = locationElement ? locationElement.textContent.trim() : '';

            // Check if already connected - using updated selectors
            const connectButton = cardElement.querySelector('button[aria-label*="Invite"], button[aria-label*="Follow"]');
            const messageButton = cardElement.querySelector('button[aria-label*="Message"]');
            const followButton = cardElement.querySelector('button[aria-label*="Follow"]');

            let connectionStatus = 'unknown';
            if (messageButton) connectionStatus = 'connected';
            else if (followButton) connectionStatus = 'following';
            else if (connectButton) connectionStatus = 'not_connected';

            return {
                success: true,
                profileUrl,
                name,
                headline,
                location,
                connectionStatus,
                hasConnectButton: !!connectButton
            };
        } catch (error) {
            return {
                success: false,
                error: error.message
            };
        }
    }

    /**
     * Qualify profile based on headline filtering
     * @param {object} profile - Profile data
     * @param {object} filters - Qualification filters
     * @returns {boolean} Whether profile qualifies
     */
    qualifyProfile(profile, filters = {}) {
        if (!profile.success || !profile.headline) return false;

        // Must have connect button
        if (!profile.hasConnectButton) return false;

        // Already connected/following
        if (profile.connectionStatus !== 'not_connected') return false;

        // Headline filtering
        if (filters.requiredTerms && filters.requiredTerms.length > 0) {
            const headlineLower = profile.headline.toLowerCase();
            const hasRequired = filters.requiredTerms.some(term => 
                headlineLower.includes(term.toLowerCase())
            );
            if (!hasRequired) return false;
        }

        // Exclude terms in headline
        if (filters.excludeHeadlineTerms && filters.excludeHeadlineTerms.length > 0) {
            const headlineLower = profile.headline.toLowerCase();
            const hasExcluded = filters.excludeHeadlineTerms.some(term => 
                headlineLower.includes(term.toLowerCase())
            );
            if (hasExcluded) return false;
        }

        return true;
    }

    /**
     * Save lead to storage
     * @param {object} lead - Lead data
     */
    async saveLead(lead) {
        try {
            console.log('💾 SAVE LEAD: Starting to save lead:', lead.name);
            console.log('💾 SAVE LEAD: Lead data:', JSON.stringify(lead, null, 2));
            
            // Generate unique ID
            lead.id = `lead_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
            lead.collectedAt = new Date().toISOString();
            
            console.log('💾 SAVE LEAD: Generated ID:', lead.id);
            
            // Get existing leads
            const allLeads = await storage.getArray('leads', []);
            const leadsByQuery = await storage.getObject('leadsByQuery', {});
            
            console.log(`💾 SAVE LEAD: Current total leads: ${allLeads.length}`);
            console.log(`💾 SAVE LEAD: Current queries:`, Object.keys(leadsByQuery));
            
            // Check if lead already exists
            const existingIndex = allLeads.findIndex(l => l.profileUrl === lead.profileUrl);
            if (existingIndex >= 0) {
                // Update existing lead
                console.log('💾 SAVE LEAD: Updating existing lead at index:', existingIndex);
                allLeads[existingIndex] = { ...allLeads[existingIndex], ...lead, collectedAt: allLeads[existingIndex].collectedAt };
            } else {
                // Add new lead at the beginning (newest first)
                console.log('💾 SAVE LEAD: Adding new lead at top');
                allLeads.unshift(lead);
            }
            
            // Index by query
            if (!leadsByQuery[lead.searchQuery]) {
                console.log(`💾 SAVE LEAD: Creating new query index for "${lead.searchQuery}"`);
                leadsByQuery[lead.searchQuery] = [];
            }
            if (!leadsByQuery[lead.searchQuery].includes(lead.id)) {
                leadsByQuery[lead.searchQuery].push(lead.id);
                console.log(`💾 SAVE LEAD: Added lead to query "${lead.searchQuery}"`);
            }
            
            console.log(`💾 SAVE LEAD: Leads for query "${lead.searchQuery}": ${leadsByQuery[lead.searchQuery].length}`);
            
            // Save to storage
            console.log('💾 SAVE LEAD: Writing to storage...');
            await storage.setArray('leads', allLeads);
            await storage.setObject('leadsByQuery', leadsByQuery);
            
            // Verify save
            const verifyLeads = await storage.getArray('leads', []);
            console.log(`✅ SAVE LEAD: Successfully saved! Total leads now: ${verifyLeads.length}`);
            console.log(`✅ SAVE LEAD: Verified in storage: ${verifyLeads.length} leads`);
        } catch (error) {
            console.error('❌ SAVE LEAD: Error saving lead:', error);
            console.error('❌ SAVE LEAD: Lead data:', lead);
            throw error;
        }
    }

    /**
     * Update lead connection status
     * @param {string} profileUrl - Profile URL
     * @param {string} status - Connection status
     */
    async updateLeadConnectionStatus(profileUrl, status) {
        console.log(`📝 UPDATE STATUS: Updating connection status for ${profileUrl} to ${status}`);
        
        const allLeads = await storage.getArray('leads', []);
        const lead = allLeads.find(l => l.profileUrl === profileUrl);
        
        if (lead) {
            console.log(`📝 UPDATE STATUS: Found lead: ${lead.name}`);
            lead.connectionStatus = status;
            if (status === 'connected' || status === 'pending') {
                lead.connectedAt = new Date().toISOString();
                console.log(`📝 UPDATE STATUS: Set connectedAt: ${lead.connectedAt}`);
            }
            await storage.setArray('leads', allLeads);
            console.log(`✅ UPDATE STATUS: Successfully updated lead status`);
            
            // Record statistics and track backend usage
            try {
                await backgroundStatistics.recordConnectionRequest(lead.name, lead.headline);
                console.log(`📊 UPDATE STATUS: Recorded connection statistics`);
            } catch (statError) {
                console.error(`⚠️ UPDATE STATUS: Failed to record statistics:`, statError.message);
                if (statError.message.includes('limit reached')) {
                    console.error(`🚫 UPDATE STATUS: ${statError.message}`);
                    throw statError; // Propagate error to stop automation
                }
            }
        } else {
            console.warn(`⚠️ UPDATE STATUS: Lead not found for ${profileUrl}`);
        }
    }

    /**
     * Extract contact information from profile
     * @param {string} profileUrl - Profile URL
     */
    async extractContactInfo(profileUrl) {
        const contactUrl = profileUrl.includes('/overlay/contact-info/') 
            ? profileUrl 
            : `${profileUrl}/overlay/contact-info/`;
        
        const tabId = await browser.openTab(contactUrl, false);
        if (!tabId) return { email: null, phone: null };
        
        await new Promise(resolve => setTimeout(resolve, 3000));
        
        const result = await chrome.scripting.executeScript({
            target: { tabId },
            func: () => {
                try {
                    const sectionInfo = document.querySelector('.section-info, .pv-contact-info__contact-type');
                    if (!sectionInfo) {
                        return { email: null, phone: null };
                    }
                    
                    let email = null;
                    let phone = null;
                    
                    // Extract email
                    const emailLinks = document.querySelectorAll('a[href^="mailto:"]');
                    if (emailLinks.length > 0) {
                        email = emailLinks[0].href.replace('mailto:', '').trim();
                    }
                    
                    // Extract phone
                    const phoneLinks = document.querySelectorAll('a[href^="tel:"]');
                    if (phoneLinks.length > 0) {
                        phone = phoneLinks[0].href.replace('tel:', '').trim();
                    }
                    
                    // Alternative: look in section-info text
                    if (!phone) {
                        const phoneMatch = sectionInfo.textContent.match(/[\+]?[(]?[0-9]{1,4}[)]?[-\s\.]?[(]?[0-9]{1,4}[)]?[-\s\.]?[0-9]{1,9}/);
                        if (phoneMatch) {
                            phone = phoneMatch[0].trim();
                        }
                    }
                    
                    return { email, phone };
                } catch (error) {
                    return { email: null, phone: null };
                }
            }
        });
        
        chrome.tabs.remove(tabId).catch(() => {});
        
        return result[0]?.result || { email: null, phone: null };
    }

    /**
     * Send connection request directly from search result card
     * @param {number} tabId - Tab ID of search results page
     * @param {object} profile - Profile data
     * @param {string} message - Optional connection message
     */
    async sendConnectionRequestFromCard(tabId, profile, message = '') {
        console.log(`PEOPLE SEARCH: Attempting to connect with ${profile.name}`);
        console.log(`PEOPLE SEARCH: Profile URL: ${profile.profileUrl}`);
        
        try {
            // Extract vanity name from profile URL
            const vanityMatch = profile.profileUrl.match(/\/in\/([^\/]+)/);
            if (!vanityMatch) {
                return { success: false, reason: 'Invalid LinkedIn profile URL' };
            }
            const vanityName = vanityMatch[1];
            
            // Open direct invitation URL in a new tab
            const inviteUrl = `https://www.linkedin.com/preload/custom-invite/?vanityName=${vanityName}`;
            console.log(`PEOPLE SEARCH: Opening direct invite URL: ${inviteUrl}`);
            
            const inviteTabId = await browser.openTab(inviteUrl, false);
            if (!inviteTabId) {
                return { success: false, reason: 'Failed to open invite tab' };
            }
            
            // Wait for invitation modal to load
            console.log('⏳ PEOPLE SEARCH: Waiting for invitation modal to load...');
            await new Promise(resolve => setTimeout(resolve, 3000));
            
            // Execute script to send invitation
            const result = await chrome.scripting.executeScript({
                target: { tabId: inviteTabId },
                func: (msg) => {
                    try {
                        console.log('🔗 SCRIPT: Looking for send invitation button...');
                        
                        // Check if user wants to add a note
                        if (msg && msg.trim() !== '') {
                            console.log('💬 SCRIPT: User wants to send with note');
                            
                            // Look for "Add a note" button
                            const addNoteBtn = document.querySelector('button[aria-label*="Add a note"]');
                            if (addNoteBtn) {
                                console.log('🔘 SCRIPT: Clicking "Add a note" button...');
                                addNoteBtn.click();
                                
                                // Wait for textarea to appear
                                setTimeout(() => {
                                    const textarea = document.querySelector('textarea[name="message"], textarea');
                                    if (textarea) {
                                        console.log('✍️ SCRIPT: Writing personalized message...');
                                        textarea.focus();
                                        textarea.value = msg;
                                        textarea.dispatchEvent(new Event('input', { bubbles: true }));
                                        textarea.dispatchEvent(new Event('change', { bubbles: true }));
                                        
                                        setTimeout(() => {
                                            // Click send invitation button
                                            const sendBtn = document.querySelector('button[aria-label="Send invitation"]');
                                            if (sendBtn) {
                                                console.log('🔘 SCRIPT: Clicking send invitation button...');
                                                sendBtn.click();
                                                console.log('✅ SCRIPT: Connection sent with note!');
                                                return { success: true, withNote: true };
                                            }
                                        }, 500);
                                    }
                                }, 500);
                            }
                        } else {
                            // Send without note
                            console.log('💬 SCRIPT: Sending without note...');
                            const sendWithoutBtn = document.querySelector('button[aria-label="Send without a note"]');
                            if (sendWithoutBtn) {
                                console.log('🔘 SCRIPT: Clicking "Send without a note" button...');
                                sendWithoutBtn.click();
                                console.log('✅ SCRIPT: Connection sent without note!');
                                return { success: true, withNote: false };
                            } else {
                                console.error('❌ SCRIPT: Send button not found');
                                return { success: false, reason: 'Send button not found' };
                            }
                        }

                    } catch (error) {
                        console.error('❌ SCRIPT: Error sending connection:', error);
                        return { success: false, error: error.message };
                    }
                },
                args: [message]
            });
            
            // Wait 7 seconds before closing tab
            console.log('⏳ PEOPLE SEARCH: Waiting 7 seconds before closing tab...');
            await new Promise(resolve => setTimeout(resolve, 7000));
            
            // Close the invite tab
            await chrome.tabs.remove(inviteTabId);

            return result[0]?.result || { success: false, reason: 'No result returned' };
        } catch (error) {
            console.error('PEOPLE SEARCH: Error sending connection:', error);
            return { success: false, reason: error.message };
        }
    }

    /**
     * Scrape profiles from current search results page
     * @param {number} tabId - Tab ID of search page
     * @returns {Array} Array of profile objects
     */
    async scrapeSearchResults(tabId) {
        const result = await chrome.scripting.executeScript({
            target: { tabId },
            func: () => {
                const profiles = [];
                // Using updated selector: .linked-area
                const cards = document.querySelectorAll('.linked-area');
                
                cards.forEach(card => {
                    try {
                        // Extract profile data inline (updated selectors)
                        const linkElement = card.querySelector('a[href*="/in/"]:not([aria-hidden])');
                        const profileUrl = linkElement ? linkElement.href : null;

                        const nameElement = card.querySelector('a[href*="/in/"]:not([aria-hidden]) span span:nth-child(1)');
                        const name = nameElement ? nameElement.textContent.trim() : 'Unknown';

                        const headlineElement = card.querySelector('.t-black');
                        const headline = headlineElement ? headlineElement.textContent.trim() : '';

                        const locationElement = card.querySelector('.t-14:nth-child(3)');
                        const location = locationElement ? locationElement.textContent.trim() : '';

                        // Try multiple Connect button selectors
                        let connectButton = card.querySelector('button[aria-label*="Invite"], button[aria-label*="Follow"]');
                        if (!connectButton) {
                            connectButton = card.querySelector('button[aria-label*="Invite"], button[aria-label*="Connect"]');
                        }
                        
                        const messageButton = card.querySelector('button[aria-label*="Message"]');
                        const followButton = card.querySelector('button[aria-label*="Follow"]');

                        let connectionStatus = 'unknown';
                        if (messageButton) connectionStatus = 'connected';
                        else if (followButton) connectionStatus = 'following';
                        else if (connectButton) connectionStatus = 'not_connected';

                        if (profileUrl) {
                            profiles.push({
                                success: true,
                                profileUrl,
                                name,
                                headline,
                                location,
                                connectionStatus,
                                hasConnectButton: !!connectButton
                            });
                        }
                    } catch (error) {
                        console.error('Error extracting profile:', error);
                    }
                });

                return profiles;
            }
        });

        return result[0].result || [];
    }

    /**
     * Navigate to next page in search results
     * @param {number} tabId - Tab ID of search page
     * @returns {boolean} Whether next page exists
     */
    async goToNextPage(tabId) {
        const result = await chrome.scripting.executeScript({
            target: { tabId },
            func: () => {
                // Using updated selector: button.artdeco-pagination__button--next
                const nextBtn = document.querySelector('button.artdeco-pagination__button--next');
                if (nextBtn && !nextBtn.disabled) {
                    nextBtn.click();
                    return { success: true };
                }
                return { success: false, reason: 'Next button not found or disabled' };
            }
        });

        return result[0].result.success;
    }

    /**
     * Save search state for resume capability
     */
    async saveSearchState() {
        await storage.setObject('peopleSearchState', this.searchState);
    }

    /**
     * Load saved search state
     */
    async loadSearchState() {
        const saved = await storage.getObject('peopleSearchState');
        if (saved) {
            this.searchState = { ...this.searchState, ...saved };
        }
    }

    /**
     * Main automation loop for people search and connect
     * @param {string} keyword - Search keyword
     * @param {number} targetConnections - Number of connections to send
     * @param {object} options - Configuration options
     */
    async autoConnectFromSearch(keyword, targetConnections = 10, options = {}) {
        // Reset stop flag
        this.stopFlag = false;
        
        // Set active flag for dashboard monitoring
        await chrome.storage.local.set({ peopleSearchActive: true });
        
        // Record session start
        const sessionStartTime = Date.now();
        let sessionData = {
            type: 'networking',
            query: keyword,
            target: targetConnections,
            startTime: sessionStartTime,
            options: options
        };
        
        // Record session start immediately for accountability
        const recordSessionStart = async () => {
            console.log('📝 DEBUG: Recording networking session START immediately');
            sessionData.id = Date.now().toString() + Math.random().toString(36).substr(2, 9);
            sessionData.status = 'started';
            sessionData.processed = 0;
            sessionData.successful = 0;
            sessionData.endTime = sessionData.startTime;
            sessionData.duration = 0;
            
            try {
                const { processingHistory = [] } = await chrome.storage.local.get('processingHistory');
                processingHistory.unshift({...sessionData});
                if (processingHistory.length > 100) {
                    processingHistory.splice(100);
                }
                await chrome.storage.local.set({ processingHistory });
                console.log('📝 DEBUG: Networking session START recorded to storage');
            } catch (error) {
                console.warn('Failed to record networking session start:', error);
            }
        };
        
        // Helper function to record/update session
        const recordSession = async (status, processed = 0, successful = 0, error = null) => {
            console.log(`📝 DEBUG: Recording networking session - status: ${status}, processed: ${processed}, successful: ${successful}`);
            
            sessionData.endTime = Date.now();
            sessionData.duration = sessionData.endTime - sessionData.startTime;
            sessionData.processed = successful; // For networking, show connections sent, not qualified profiles found
            sessionData.successful = successful;
            sessionData.status = status;
            sessionData.successRate = successful > 0 ? 100 : 0; // For networking, success rate is 100% if any connections sent, 0% if none
            if (error) sessionData.error = error;
            
            try {
                const { processingHistory = [] } = await chrome.storage.local.get('processingHistory');
                
                // Find existing session by ID and update it
                const existingIndex = processingHistory.findIndex(s => s.id === sessionData.id);
                if (existingIndex >= 0) {
                    console.log('📝 DEBUG: Updating existing networking session');
                    processingHistory[existingIndex] = {...sessionData};
                } else {
                    console.log('📝 DEBUG: Adding new networking session');
                    processingHistory.unshift({...sessionData});
                }
                
                if (processingHistory.length > 100) {
                    processingHistory.splice(100);
                }
                await chrome.storage.local.set({ processingHistory });
                console.log(`📝 ${status} networking session recorded to history`);
            } catch (historyError) {
                console.warn('Failed to record networking session:', historyError);
            }
        };
        
        // Record session start immediately
        await recordSessionStart();
        
        console.log('PEOPLE SEARCH: Starting automation');
        console.log('PEOPLE SEARCH: Keyword:', keyword);
        console.log('PEOPLE SEARCH: Target:', targetConnections);

        // Load delay settings
        const delayResult = await chrome.storage.local.get('delaySettings');
        const delaySettings = delayResult.delaySettings || {};
        const startDelay = delaySettings.networkingStartDelay || 0;
        
        if (startDelay > 0) {
            console.log(`⏰ PEOPLE SEARCH: Waiting ${startDelay} seconds before starting...`);
            await new Promise(resolve => setTimeout(resolve, startDelay * 1000));
            console.log('✅ PEOPLE SEARCH: Start delay complete, beginning automation');
        }

        // Load previous state if resuming
        await this.loadSearchState();

        // Reset if new keyword
        if (this.searchState.lastSearchKeyword !== keyword) {
            this.searchState = {
                currentPage: 1,
                lastSearchKeyword: keyword,
                processedProfiles: [],
                totalConnected: 0
            };
        }

        let connected = 0;
        const filters = {
            requiredTerms: options.requiredTerms || [],
            excludeHeadlineTerms: options.excludeHeadlineTerms || ['Aspiring', 'Former', 'Seeking', 'Student']
        };

        while (connected < targetConnections) {
            // Check stop flag
            if (this.stopFlag) {
                console.log('PEOPLE SEARCH: Stopped by user');
                // Clear live progress
                await chrome.storage.local.set({ liveProgress: { active: false } });
                await recordSession('stopped', this.searchState.processedProfiles.length, connected);
                return {
                    success: true,
                    stopped: true,
                    connected,
                    target: targetConnections,
                    pagesProcessed: this.searchState.currentPage - 1,
                    message: 'Processing stopped by user'
                };
            }
            
            // Build search URL for current page
            const searchUrl = this.buildPeopleSearchUrl(keyword, {
                ...options,
                page: this.searchState.currentPage
            });

            console.log(`PEOPLE SEARCH: Opening page ${this.searchState.currentPage}`);
            
            // Open search page with retries
            let searchTabId = null;
            let openAttempts = 0;
            const maxOpenRetries = 5;
            
            while (!searchTabId && openAttempts < maxOpenRetries) {
                openAttempts++;
                console.log(`PEOPLE SEARCH: Attempt ${openAttempts}/${maxOpenRetries} to open search page`);
                
                try {
                    searchTabId = await browser.openTab(searchUrl, false);
                    
                    if (!searchTabId) {
                        console.warn(`PEOPLE SEARCH: Failed to open tab on attempt ${openAttempts}`);
                        if (openAttempts < maxOpenRetries) {
                            // Wait before retry (exponential backoff)
                            const retryDelay = 20000 * openAttempts;
                            console.log(`PEOPLE SEARCH: Waiting ${retryDelay}ms before retry`);
                            await new Promise(resolve => setTimeout(resolve, retryDelay));
                        }
                    } else {
                        console.log(`PEOPLE SEARCH: Successfully opened tab ${searchTabId} on attempt ${openAttempts}`);
                    }
                } catch (error) {
                    console.error(`PEOPLE SEARCH: Error opening tab on attempt ${openAttempts}:`, error);
                    if (openAttempts < maxOpenRetries) {
                        await new Promise(resolve => setTimeout(resolve, 2000 * openAttempts));
                    }
                }
            }
            
            if (!searchTabId) {
                console.error('PEOPLE SEARCH: Failed to open search page after all retries');
                break;
            }

            // Wait for page load with verification
            console.log('PEOPLE SEARCH: Waiting for page to load...');
            let pageLoadAttempts = 0;
            const maxLoadRetries = 10;
            let pageLoaded = false;
            
            while (!pageLoaded && pageLoadAttempts < maxLoadRetries) {
                // Check stop flag during page load wait
                if (this.stopFlag) {
                    console.log('PEOPLE SEARCH: Stopped by user during page load');
                    try { await chrome.tabs.remove(searchTabId); } catch (e) {}
                    await chrome.storage.local.set({ liveProgress: { active: false }, peopleSearchActive: false });
                    await recordSession('stopped', this.searchState.processedProfiles.length, connected);
                    return { success: true, stopped: true, connected, target: targetConnections, message: 'Processing stopped by user' };
                }
                
                pageLoadAttempts++;
                await new Promise(resolve => setTimeout(resolve, 10000)); // Wait 10 seconds
                
                // Verify page is loaded by checking for content
                try {
                    const verification = await chrome.scripting.executeScript({
                        target: { tabId: searchTabId },
                        func: () => {
                            const hasProfiles = document.querySelectorAll('li.reusable-search__result-container').length > 0;
                            const isLoaded = document.readyState === 'complete';
                            return { hasProfiles, isLoaded, readyState: document.readyState };
                        }
                    });
                    
                    if (verification && verification[0]?.result) {
                        const result = verification[0].result;
                        console.log(`PEOPLE SEARCH: Page load check ${pageLoadAttempts}: readyState=${result.readyState}, hasProfiles=${result.hasProfiles}`);
                        
                        if (result.isLoaded || result.hasProfiles) {
                            pageLoaded = true;
                            console.log('PEOPLE SEARCH: Page verified as loaded');
                        } else if (pageLoadAttempts < maxLoadRetries) {
                            console.log(`PEOPLE SEARCH: Page not ready yet, waiting... (attempt ${pageLoadAttempts}/${maxLoadRetries})`);
                        }
                    }
                } catch (error) {
                    console.warn(`PEOPLE SEARCH: Error verifying page load on attempt ${pageLoadAttempts}:`, error);
                }
            }
            
            if (!pageLoaded) {
                console.warn('PEOPLE SEARCH: Page may not be fully loaded, continuing anyway...');
            }
            
            // Additional wait for dynamic content
            await new Promise(resolve => setTimeout(resolve, 2000));

            // Scrape profiles from page
            const profiles = await this.scrapeSearchResults(searchTabId);
            console.log(`PEOPLE SEARCH: Found ${profiles.length} profiles on page`);

            // Process each profile
            for (const profile of profiles) {
                // Check stop flag before processing each profile
                if (this.stopFlag) {
                    console.log('PEOPLE SEARCH: Stopped by user during profile processing');
                    try { await chrome.tabs.remove(searchTabId); } catch (e) {}
                    await chrome.storage.local.set({ liveProgress: { active: false }, peopleSearchActive: false });
                    await recordSession('stopped', this.searchState.processedProfiles.length, connected);
                    return { success: true, stopped: true, connected, target: targetConnections, message: 'Processing stopped by user' };
                }
                
                // Skip if already processed
                if (this.searchState.processedProfiles.includes(profile.profileUrl)) {
                    continue;
                }

                // Qualify profile
                if (!this.qualifyProfile(profile, filters)) {
                    console.log(`PEOPLE SEARCH: Skipped "${profile.name}" - Did not qualify`);
                    this.searchState.processedProfiles.push(profile.profileUrl);
                    continue;
                }

                console.log(`PEOPLE SEARCH: Processing "${profile.name}" (${profile.headline})`);

                // Create lead object
                const lead = {
                    profileUrl: profile.profileUrl,
                    name: profile.name,
                    headline: profile.headline,
                    location: profile.location,
                    connectionStatus: 'not_connected',
                    email: null,
                    phone: null,
                    searchQuery: keyword,
                };

                // Extract email/phone if enabled
                if (options.extractContactInfo) {
                    console.log(`PEOPLE SEARCH: Extracting contact info for ${profile.name}...`);
                    const contactInfo = await this.extractContactInfo(profile.profileUrl);
                    lead.email = contactInfo.email;
                    lead.phone = contactInfo.phone;
                    console.log(`PEOPLE SEARCH: Email: ${lead.email || 'N/A'}, Phone: ${lead.phone || 'N/A'}`);
                }

                // Save lead to storage (even if connection fails)
                await this.saveLead(lead);

                // Send connection request directly from search results
                console.log(`PEOPLE SEARCH: Sending connection request to ${profile.name}...`);
                
                // Prepare message based on sendWithNote option
                let message = '';
                if (options.sendWithNote && options.connectionMessage) {
                    message = options.connectionMessage;
                    // Replace [Name] placeholder with actual name
                    if (message.includes('[Name]')) {
                        message = message.replace(/\[Name\]/g, profile.name);
                        console.log(`PEOPLE SEARCH: Personalized message: "${message.substring(0, 50)}..."`);
                    }
                } else {
                    console.log(`PEOPLE SEARCH: Sending without personalized note (sendWithNote: ${options.sendWithNote})`);
                }
                
                const sendResult = await this.sendConnectionRequestFromCard(searchTabId, profile, message);

                if (sendResult.success) {
                    connected++;
                    this.searchState.totalConnected++;
                    this.searchState.processedProfiles.push(profile.profileUrl);
                    
                    // Update lead status to pending
                    await this.updateLeadConnectionStatus(profile.profileUrl, 'pending');
                    
                    // Record statistics and track backend usage
                    try {
                        await backgroundStatistics.recordConnectionRequest(profile.name, profile.headline);
                    } catch (statError) {
                        console.error(`⚠️ PEOPLE SEARCH: Failed to record statistics:`, statError.message);
                        if (statError.message.includes('limit reached')) {
                            console.error(`🚫 PEOPLE SEARCH: ${statError.message} - Stopping automation`);
                            throw statError; // Stop processing if limit reached
                        }
                    }
                    
                    console.log(`PEOPLE SEARCH: Connected ${connected}/${targetConnections}`);
                    
                    // Update live progress
                    const percentage = Math.round((connected / targetConnections) * 100);
                    await chrome.storage.local.set({
                        liveProgress: {
                            active: true,
                            type: 'people_search',
                            current: connected,
                            total: targetConnections,
                            currentStep: `Connected ${connected}/${targetConnections} people`,
                            percentage: percentage
                        }
                    });

                    // Save state
                    await this.saveSearchState();

                    // Check if quota reached
                    if (connected >= targetConnections) {
                        chrome.tabs.remove(searchTabId);
                        break;
                    }

                    // Random delay between connections using settings
                    const minDelay = (delaySettings.networkingMinDelay || 30) * 1000;
                    const maxDelay = (delaySettings.networkingMaxDelay || 60) * 1000;
                    const delayTime = Math.floor(Math.random() * (maxDelay - minDelay + 1)) + minDelay;
                    console.log(`⏱️ PEOPLE SEARCH: Waiting ${Math.floor(delayTime/1000)}s before next connection...`);
                    await new Promise(resolve => setTimeout(resolve, delayTime));
                } else {
                    console.log(`PEOPLE SEARCH: Failed to connect: ${sendResult.reason}`);
                    this.searchState.processedProfiles.push(profile.profileUrl);
                }
            }

            // If quota reached, exit
            if (connected >= targetConnections) {
                break;
            }

            // Try to go to next page
            const hasNext = await this.goToNextPage(searchTabId);
            
            if (hasNext) {
                this.searchState.currentPage++;
                await this.saveSearchState();
                await new Promise(resolve => setTimeout(resolve, 3000));
            } else {
                console.log('PEOPLE SEARCH: No more pages available');
                chrome.tabs.remove(searchTabId);
                break;
            }
        }

        console.log(`PEOPLE SEARCH: Automation complete! Connected: ${connected}/${targetConnections}`);
        
        // Clear live progress and active flag
        await chrome.storage.local.set({ 
            liveProgress: { active: false },
            peopleSearchActive: false
        });
        console.log("✅ PEOPLE SEARCH: Live progress cleared");
        
        // Record successful session using the helper function
        await recordSession('completed', this.searchState.processedProfiles.length, connected);
        
        return {
            success: true,
            connected,
            target: targetConnections,
            profilesProcessed: this.searchState.processedProfiles.length
        };
    }
    
    /**
     * Main entry point for people search automation
     * Wrapper around autoConnectFromSearch with better error handling
     */
    async searchAndConnect(keyword, quota, options = {}, message = '') {
        try {
            console.log('PEOPLE SEARCH: searchAndConnect called');
            console.log('PEOPLE SEARCH: Keyword:', keyword);
            console.log('PEOPLE SEARCH: Quota:', quota);
            console.log('PEOPLE SEARCH: Options:', options);
            
            const result = await this.autoConnectFromSearch(keyword, quota, {
                ...options,
                connectionMessage: message
            });
            
            return result;
        } catch (error) {
            console.error('PEOPLE SEARCH: Error in searchAndConnect:', error);
            // Clear active flag on error
            await chrome.storage.local.set({ peopleSearchActive: false });
            
            // Record failed session if sessionData is available
            try {
                const sessionData = {
                    type: 'networking',
                    query: keyword,
                    target: quota,
                    startTime: Date.now() - 60000, // Approximate start time
                    endTime: Date.now(),
                    duration: 60000, // Approximate duration
                    processed: 0,
                    successful: 0,
                    status: 'failed',
                    error: error.message
                };
                
                const { processingHistory = [] } = await chrome.storage.local.get('processingHistory');
                processingHistory.unshift(sessionData);
                if (processingHistory.length > 100) {
                    processingHistory.splice(100);
                }
                await chrome.storage.local.set({ processingHistory });
                console.log('📝 Failed networking session recorded to history');
            } catch (historyError) {
                console.warn('Failed to record failed networking session to history:', historyError);
            }
            
            throw error;
        }
    }
}

export const peopleSearchAutomation = new PeopleSearchAutomation();
export default PeopleSearchAutomation;
