import nodemailer from 'nodemailer';

// Email configuration
const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST || 'smtp.gmail.com',
  port: parseInt(process.env.SMTP_PORT || '587'),
  secure: false, // true for 465, false for other ports
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS,
  },
});

// Store OTPs in memory (for production, use Redis or database)
const otpStore: Map<string, { otp: string; expires: number }> = new Map();

/**
 * Generate a 6-digit OTP
 */
function generateOTP(): string {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

/**
 * Send OTP to email for verification
 */
export async function sendVerificationOTP(email: string): Promise<{ success: boolean; message: string }> {
  try {
    // Check if SMTP credentials are configured
    if (!process.env.SMTP_USER || !process.env.SMTP_PASS) {
      console.warn('SMTP credentials not configured, skipping email verification');
      return { success: true, message: 'Email verification skipped (SMTP not configured)' };
    }

    const otp = generateOTP();
    const expires = Date.now() + 10 * 60 * 1000; // 10 minutes expiry

    // Store OTP
    otpStore.set(email.toLowerCase(), { otp, expires });

    // Send email
    const mailOptions = {
      from: `"LinkedIn Automation" <${process.env.SMTP_USER}>`,
      to: email,
      subject: '🔐 Verify Your Email - LinkedIn Automation',
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
          <div style="background: linear-gradient(135deg, #693fe9 0%, #1a2340 100%); padding: 30px; border-radius: 10px; text-align: center;">
            <h1 style="color: white; margin: 0;">🚀 LinkedIn Automation</h1>
          </div>
          
          <div style="padding: 30px; background: #f8f9fa; border-radius: 0 0 10px 10px;">
            <h2 style="color: #333;">Verify Your Email Address</h2>
            <p style="color: #666; font-size: 16px;">
              Thank you for signing up! Please use the following OTP to verify your email address:
            </p>
            
            <div style="background: white; padding: 20px; border-radius: 8px; text-align: center; margin: 20px 0; border: 2px solid #693fe9;">
              <span style="font-size: 32px; font-weight: bold; color: #693fe9; letter-spacing: 8px;">${otp}</span>
            </div>
            
            <p style="color: #999; font-size: 14px;">
              This code will expire in <strong>10 minutes</strong>.
            </p>
            
            <p style="color: #999; font-size: 12px; margin-top: 30px;">
              If you didn't request this verification, please ignore this email.
            </p>
          </div>
          
          <div style="text-align: center; padding: 20px; color: #999; font-size: 12px;">
            © ${new Date().getFullYear()} LinkedIn Automation. All rights reserved.
          </div>
        </div>
      `,
    };

    await transporter.sendMail(mailOptions);
    console.log(`✅ OTP sent to ${email}`);

    return { success: true, message: 'Verification code sent to your email' };
  } catch (error) {
    console.error('Failed to send OTP:', error);
    return { success: false, message: 'Failed to send verification email. Please try again.' };
  }
}

/**
 * Verify OTP for email
 */
export function verifyOTP(email: string, otp: string): { success: boolean; message: string } {
  const stored = otpStore.get(email.toLowerCase());

  if (!stored) {
    return { success: false, message: 'No verification code found. Please request a new one.' };
  }

  if (Date.now() > stored.expires) {
    otpStore.delete(email.toLowerCase());
    return { success: false, message: 'Verification code expired. Please request a new one.' };
  }

  if (stored.otp !== otp) {
    return { success: false, message: 'Invalid verification code. Please try again.' };
  }

  // OTP is valid, remove it
  otpStore.delete(email.toLowerCase());
  return { success: true, message: 'Email verified successfully' };
}

/**
 * Check if email needs verification (has pending OTP)
 */
export function hasPendingOTP(email: string): boolean {
  const stored = otpStore.get(email.toLowerCase());
  if (!stored) return false;
  if (Date.now() > stored.expires) {
    otpStore.delete(email.toLowerCase());
    return false;
  }
  return true;
}
